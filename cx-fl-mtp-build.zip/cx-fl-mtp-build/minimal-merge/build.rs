pub(crate) mod encoding {
	//! Float encodings shared by the Rust runtime and LLVM template generator.
	//! Cargo.toml owns the bit layouts and FP8 special codes.

	const MANIFEST: &[u8] = include_bytes!("Cargo.toml");

	const fn equal(bytes: &[u8], start: usize, end: usize, wanted: &[u8]) -> bool {
		if end - start != wanted.len() { return false; }
		let mut i = 0;
		while i < wanted.len() {
			if bytes[start + i] != wanted[i] { return false; }
			i += 1;
		}
		true
	}

	/// Read one three-integer encoding row at compile time in both crates.
	pub(crate) const fn fields(name: &str) -> [u8; 3] {
		let mut start = 0;
		let mut section = false;
		let mut found = false;
		let mut result = [0; 3];
		while start < MANIFEST.len() {
			let mut end = start;
			while end < MANIFEST.len() && MANIFEST[end] != b'\n' { end += 1; }
			let next = end + 1;
			while start < end && MANIFEST[start].is_ascii_whitespace() { start += 1; }
			let mut comment = start;
			while comment < end && MANIFEST[comment] != b'#' { comment += 1; }
			end = comment;
			while end > start && MANIFEST[end - 1].is_ascii_whitespace() { end -= 1; }
			if start < end && MANIFEST[start] == b'[' {
				section = equal(MANIFEST, start, end, b"[encoding]");
			} else if section {
				let mut key_end = start;
				while key_end < end && MANIFEST[key_end] != b'=' { key_end += 1; }
				let mut trimmed = key_end;
				while trimmed > start && MANIFEST[trimmed - 1].is_ascii_whitespace() { trimmed -= 1; }
				if equal(MANIFEST, start, trimmed, name.as_bytes()) {
					assert!(!found, "duplicate Cargo.toml encoding");
					found = true;
					let mut at = key_end + 1;
					while at < end && MANIFEST[at].is_ascii_whitespace() { at += 1; }
					assert!(at < end && MANIFEST[at] == b'[', "encoding must be an integer array");
					at += 1;
					let mut field = 0;
					while field < 3 {
						while at < end && MANIFEST[at].is_ascii_whitespace() { at += 1; }
						assert!(at < end && MANIFEST[at].is_ascii_digit(), "encoding requires three integers");
						let mut value = 0u16;
						while at < end && MANIFEST[at].is_ascii_digit() {
							value = value * 10 + (MANIFEST[at] - b'0') as u16;
							assert!(value <= 255, "encoding field exceeds a byte");
							at += 1;
						}
						result[field] = value as u8;
						while at < end && MANIFEST[at].is_ascii_whitespace() { at += 1; }
						assert!(at < end && MANIFEST[at] == if field == 2 { b']' } else { b',' }, "encoding requires three integers");
						at += 1;
						field += 1;
					}
					while at < end && MANIFEST[at].is_ascii_whitespace() { at += 1; }
					assert!(at == end, "unexpected text after encoding");
				}
			}
			start = next;
		}
		assert!(found, "missing Cargo.toml encoding");
		result
	}
}
pub(crate) mod fp8 {
	//! FP8 storage codecs shared by the runtime and template generator.

	#[derive(Clone, Copy, Debug, PartialEq, Eq)]
	pub(crate) enum Encoding {
		E4M3,
		E5M2,
	}

	impl Encoding {
		fn layout(self) -> (u32, i32, u64, u64, u64) {
			const E4M3: ([u8; 3], [u8; 3]) = (crate::encoding::fields("fp8-e4m3"), crate::encoding::fields("fp8-e4m3-special"));
			const E5M2: ([u8; 3], [u8; 3]) = (crate::encoding::fields("fp8-e5m2"), crate::encoding::fields("fp8-e5m2-special"));
			let ([sign, exponent, fraction], [largest, nan, infinity]) = match self {
				Self::E4M3 => E4M3,
				Self::E5M2 => E5M2,
			};
			assert!(sign == 1 && exponent + fraction == 7, "FP8 encoding must occupy eight bits");
			(u32::from(fraction), (1 << (exponent - 1)) - 1, u64::from(largest), u64::from(nan), u64::from(infinity))
		}
		pub(crate) fn pack(self, value: f64) -> u64 {
			let sign = (value.to_bits() >> 63) << 7;
			let (man, bias, largest, nan, infinity) = self.layout();
			if value.is_nan() { return sign | nan; }
			if value.is_infinite() {
				return sign | infinity;
			}
			let magnitude = value.abs();
			if magnitude == 0.0 { return sign; }
			if magnitude >= self.unpack(largest) { return sign | largest; }
			let exponent = ((magnitude.to_bits() >> 52) & 2047) as i32 - 1023;
			let target = exponent + bias;
			let bits = if target <= 0 {
				(magnitude * 2.0_f64.powi(bias + man as i32 - 1)).round_ties_even() as u64
			} else {
				let significand = (magnitude * 2.0_f64.powi(man as i32 - exponent)).round_ties_even() as u64;
				(((target - 1) as u64) << man) + significand
			};
			sign | bits.min(largest)
		}

		pub(crate) fn unpack(self, bits: u64) -> f64 {
			let (man, bias, largest, _, infinity) = self.layout();
			let mask = (1 << (7 - man)) - 1;
			let magnitude = bits & 127;
			if magnitude > largest && magnitude != infinity { return f64::NAN; }
			let exponent = ((bits >> man) & mask) as i32;
			let fraction = bits & ((1 << man) - 1);
			let value = if infinity > largest && magnitude == infinity {
				f64::INFINITY
			} else if exponent == 0 {
				fraction as f64 * 2.0_f64.powi(1 - bias - man as i32)
			} else {
				((1 << man) + fraction) as f64 * 2.0_f64.powi(exponent - bias - man as i32)
			};
			if bits & 128 != 0 { -value } else { value }
		}
	}
}
use std::{
	env,
	error::Error,
	fs, io,
	path::{Path, PathBuf},
};
#[derive(Clone, Copy, PartialEq, Eq)]
struct FloatLayout {
	sign: u8,
	exp: u8,
	man: u8,
}
impl FloatLayout {
	const fn new(sign: u8, exp: u8, man: u8) -> Self {
		Self { sign, exp, man }
	}
	const fn bits(self) -> u8 {
		self.sign + self.exp + self.man
	}
	fn unpack(self, bits: u64) -> f64 {
		let exponent_limit = (1u64 << self.exp) - 1;
		let mantissa_limit = 1u64 << self.man;
		let exponent = bits >> self.man & exponent_limit;
		let mantissa = bits & (mantissa_limit - 1);
		let magnitude = match (exponent, mantissa) {
			(value, 0) if value == exponent_limit => f64::INFINITY,
			(value, _) if value == exponent_limit => f64::NAN,
			(0, 0) => 0.0,
			(0, value) => 2.0f64.powi(1 - ((1i32 << (self.exp - 1)) - 1)) * value as f64 / mantissa_limit as f64,
			(value, man) => 2.0f64.powi(value as i32 - ((1i32 << (self.exp - 1)) - 1)) * (1.0 + man as f64 / mantissa_limit as f64),
		};
		if bits >> (self.exp + self.man) != 0 { -magnitude } else { magnitude }
	}
}
#[derive(Clone, Copy, PartialEq, Eq)]
struct FloatFormat {
	arithmetic: FloatLayout,
	storage: FloatLayout,
}
impl FloatFormat {
	const FP8: Self = Self::configured("fp8-e4m3", "fp8-e4m3");
	const FP8_E5M2: Self = Self::configured("fp8-e5m2", "fp8-e5m2");
	const FP16: Self = Self::configured("fp16", "fp16");
	const FP32: Self = Self::configured("fp32", "fp32");
	const FP64: Self = Self::configured("fp64", "fp64");
	const BF16: Self = Self::configured("bf16", "bf16");
	const TF32: Self = Self::configured("tf32", "tf32-storage");
	const fn configured(arithmetic: &str, storage: &str) -> Self {
		let [s, e, m] = encoding::fields(arithmetic);
		let [ss, se, sm] = encoding::fields(storage);
		Self { arithmetic: FloatLayout::new(s, e, m), storage: FloatLayout::new(ss, se, sm) }
	}
	const fn bytes(self) -> usize {
		self.storage.bits().div_ceil(8) as usize
	}
	fn pack(self, value: f64) -> u64 {
		if self == Self::FP8 { return fp8::Encoding::E4M3.pack(value); }
		if self == Self::FP8_E5M2 { return fp8::Encoding::E5M2.pack(value); }
		let rounded = self.arithmetic.unpack(self.arithmetic.pack_from(value));
		let bits = match self.storage.bits() {
			64 => rounded.to_bits(),
			32 => u64::from((rounded as f32).to_bits()),
			16 if self == Self::FP16 => self.storage.pack_from(rounded),
			16 => u64::from((rounded as f32).to_bits() >> 16),
			8 => self.storage.pack_from(rounded),
			_ => unreachable!(),
		};
		bits
	}
	fn unpack(self, bits: u64) -> f64 {
		if self == Self::FP8 { return fp8::Encoding::E4M3.unpack(bits); }
		if self == Self::FP8_E5M2 { return fp8::Encoding::E5M2.unpack(bits); }
		match self.storage.bits() {
			64 => f64::from_bits(bits),
			32 => f64::from(f32::from_bits(bits as u32)),
			16 if self == Self::FP16 => self.arithmetic.unpack(bits),
			16 => f64::from(f32::from_bits((bits as u32) << 16)),
			8 => self.arithmetic.unpack(bits),
			_ => unreachable!(),
		}
	}
}
impl FloatLayout {
	fn pack_from(self, value: f64) -> u64 {
		let sign = value.to_bits() >> 63 << (self.exp + self.man);
		let exponent_limit = (1u64 << self.exp) - 1;
		let mantissa_limit = 1u64 << self.man;
		if value.is_nan() {
			return sign | exponent_limit << self.man | 1u64 << (self.man - 1);
		}
		if value.is_infinite() {
			return sign | exponent_limit << self.man;
		}
		if value == 0.0 {
			return sign;
		}
		let bias = (1i32 << (self.exp - 1)) - 1;
		let magnitude = value.abs();
		let mut exponent = magnitude.log2().floor() as i32;
		if exponent < 1 - bias {
			let mantissa = (magnitude / 2.0f64.powi(1 - bias) * mantissa_limit as f64).round_ties_even() as u64;
			return if mantissa == mantissa_limit { sign | 1u64 << self.man } else { sign | mantissa };
		}
		let mut mantissa = ((magnitude / 2.0f64.powi(exponent) - 1.0) * mantissa_limit as f64).round_ties_even() as u64;
		if mantissa == mantissa_limit {
			mantissa = 0;
			exponent += 1
		}
		let stored = exponent + bias;
		if stored >= exponent_limit as i32 { sign | exponent_limit << self.man } else { sign | (stored as u64) << self.man | mantissa }
	}
}
#[derive(Clone, Copy)]
struct IntFormat {
	bits: u8,
}
impl IntFormat {
	const INT4: Self = Self { bits: 4 };
	const INT8: Self = Self { bits: 8 };
	const fn bytes(self) -> usize {
		self.bits.div_ceil(8) as usize
	}
	fn pack(self, value: f64) -> u64 {
		(value.round_ties_even() as i64).clamp(-(1i64 << (self.bits - 1)), (1i64 << (self.bits - 1)) - 1) as u64 & ((1u64 << self.bits) - 1)
	}
}
type BuildResult<T> = Result<T, Box<dyn Error>>;
const PARALLEL: &str = r#"declare i32 @llvm.amdgcn.workgroup.id.x()
declare i32 @recipe.workgroup.size.x()
define internal i32 @global_id() #1 { entry:
%lane = call i32 @llvm.amdgcn.workitem.id.x() %group = call i32 @llvm.amdgcn.workgroup.id.x()
%width = call i32 @recipe.workgroup.size.x() %base = mul i32 %group, %width %id = add i32 %base, %lane ret i32 %id }
@RECIPE_GRID_BARRIER@"#;
const AMD_GRID_BARRIER: &str = r#"declare void @__ockl_grid_sync()
define internal void @grid_barrier(i32 %threads) #1 { entry: call void @__ockl_grid_sync() ret void }"#;
// PTX only accepts ordered atomics on sm_70 and newer, so the counting barrier uses
// device-scoped monotonic atomics with acquire/release fences. A release fence
// publishes each block's arrival; the last arriver acquires and republishes
// them before flipping the phase. Each waiter acquires after the flip.
// The counters and cooperating blocks belong to one GPU. Driver synchronization
// orders transfers outside the invocation; this barrier needs no system fence.
// Every thread reads the phase before the block barrier; then one lane per warp spins
// on it and the warp reconverges behind that lane (bar.warp.sync), so no bar.sync
// follows a divergent spin (bar.sync is per warp before sm_70 and would count the
// leader's warp as arrived on the lanes that skipped the spin) and only one lane in
// thirty-two loads the phase while the grid drains. The acquire fence is the spinner's
<<<<<<< HEAD
// alone: before sm_70 a device fence is membar.gl;
=======
// alone: before sm_70 a system fence is membar.sys, and one per thread cost a millisecond a
// node; the fences are device scope (membar.gl), as every block of the grid shares the device;
>>>>>>> 73cf82209379471c3cdaefd6275bbd2f5a70ce13
// the warp's other lanes issue their loads after the spinner's fence by program order.
const NVIDIA_GRID_BARRIER: &str = r#"@grid.count = internal addrspace(1) global i32 0, align 4
@grid.phase = internal addrspace(1) global i32 0, align 4
define internal void @grid_barrier(i32 %threads) #1 { entry:
; Every writer releases its own global-memory operations before the block arrives.
fence syncscope("device") release
%phase = load atomic i32, ptr addrspace(1) @grid.phase syncscope("device") monotonic, align 4
call void @llvm.amdgcn.s.barrier() %tid = call i32 @llvm.amdgcn.workitem.id.x()
%leader = icmp eq i32 %tid, 0 br i1 %leader, label %arrive, label %check arrive:
%width = call i32 @recipe.workgroup.size.x() %groups = udiv i32 %threads, %width
fence syncscope("device") release
<<<<<<< HEAD
%prior = atomicrmw add ptr addrspace(1) @grid.count, i32 1 syncscope("device") monotonic %limit = sub i32 %groups, 1
%last = icmp eq i32 %prior, %limit br i1 %last, label %release, label %wait release:
fence syncscope("device") acquire
store atomic i32 0, ptr addrspace(1) @grid.count syncscope("device") monotonic, align 4 %next = xor i32 %phase, 1
fence syncscope("device") release
store atomic i32 %next, ptr addrspace(1) @grid.phase syncscope("device") monotonic, align 4 br label %wait check:
br i1 %spinner, label %wait, label %waited wait:
%seen = load atomic i32, ptr addrspace(1) @grid.phase syncscope("device") monotonic, align 4 %ready = icmp ne i32 %seen, %phase
br i1 %ready, label %acquired, label %wait acquired:
fence syncscope("device") acquire br label %waited waited:
call void @llvm.amdgcn.s.barrier()
fence syncscope("device") acquire
=======
%prior = atomicrmw add ptr addrspace(1) @grid.count, i32 1 monotonic %limit = sub i32 %groups, 1
%last = icmp eq i32 %prior, %limit br i1 %last, label %release, label %wait release:
fence syncscope("device") acquire
store atomic i32 0, ptr addrspace(1) @grid.count monotonic, align 4 %next = xor i32 %phase, 1
fence syncscope("device") release
store atomic i32 %next, ptr addrspace(1) @grid.phase monotonic, align 4 br label %wait check:
br label %waited wait:
%seen = load atomic i32, ptr addrspace(1) @grid.phase monotonic, align 4 %ready = icmp ne i32 %seen, %phase
br i1 %ready, label %acquired, label %wait acquired:
fence syncscope("device") acquire br label %waited waited:
call void @llvm.amdgcn.s.barrier()
>>>>>>> 73cf82209379471c3cdaefd6275bbd2f5a70ce13
ret void }"#;
// A workgroup barrier on AMD is s_barrier between two workgroup-scope
// fences: s_barrier alone neither waits for in-flight LDS stores nor keeps
// the compiler from moving LDS accesses across it, and two waves sharing the
// int8 activation records read each other's half-written records (2026-09-18).
// NVIDIA's bar.sync and the CPU's single wave never had the gap.
const AMD_WORKGROUP_BARRIER: &str = r#"define internal void @recipe.workgroup.barrier() #1 { entry: fence syncscope("workgroup") release call void @llvm.amdgcn.s.barrier() fence syncscope("workgroup") acquire ret void }"#;
const AMD_WIDTH: &str = r#"declare ptr addrspace(4) @llvm.amdgcn.dispatch.ptr()
define internal i32 @recipe.workgroup.size.x() #1 { entry: %args = call ptr addrspace(4) @llvm.amdgcn.dispatch.ptr()
%address = getelementptr i8, ptr addrspace(4) %args, i32 4 %value = load i16, ptr addrspace(4) %address, align 2
%width = zext i16 %value to i32 ret i32 %width }"#;
const AMD_WAVE_HELPERS: &str = r#"declare i32 @llvm.amdgcn.ds.bpermute(i32, i32)
declare i32 @llvm.amdgcn.wavefrontsize()
define internal i32 @recipe.wavefront.width() #1 { entry: %width = call i32 @llvm.amdgcn.wavefrontsize() ret i32 %width }
define internal i1 @recipe.int8.dots() #1 { entry: ret i1 true }
define internal i64 @recipe.clock() #1 { entry: %now = call i64 @__ockl_steadyctr_u64() ret i64 %now }
define internal float @recipe.wave.partner(float %value, i32 %index) #1 { entry: %bits = bitcast float %value to i32 %partner.bits = call i32 @llvm.amdgcn.ds.bpermute(i32 %index, i32 %bits) %partner = bitcast i32 %partner.bits to float ret float %partner }
define internal float @recipe.wave.partner.f32(float %value, i32 %index) #1 { entry: %bits = bitcast float %value to i32 %partner.bits = call i32 @llvm.amdgcn.ds.bpermute(i32 %index, i32 %bits) %partner = bitcast i32 %partner.bits to float ret float %partner }"#;
const AMD_WAVE_HELPERS_DOUBLE: &str = r#"declare i32 @llvm.amdgcn.ds.bpermute(i32, i32)
declare i32 @llvm.amdgcn.wavefrontsize()
define internal i32 @recipe.wavefront.width() #1 { entry: %width = call i32 @llvm.amdgcn.wavefrontsize() ret i32 %width }
define internal i1 @recipe.int8.dots() #1 { entry: ret i1 true }
define internal i64 @recipe.clock() #1 { entry: %now = call i64 @__ockl_steadyctr_u64() ret i64 %now }
define internal double @recipe.wave.partner(double %value, i32 %index) #1 { entry: %bits = bitcast double %value to i64 %low.bits = trunc i64 %bits to i32 %high.shift = lshr i64 %bits, 32 %high.bits = trunc i64 %high.shift to i32 %partner.low = call i32 @llvm.amdgcn.ds.bpermute(i32 %index, i32 %low.bits) %partner.high = call i32 @llvm.amdgcn.ds.bpermute(i32 %index, i32 %high.bits) %partner.high.wide = zext i32 %partner.high to i64 %partner.high.shift = shl i64 %partner.high.wide, 32 %partner.low.wide = zext i32 %partner.low to i64 %partner.bits = or i64 %partner.high.shift, %partner.low.wide %partner = bitcast i64 %partner.bits to double ret double %partner }
define internal float @recipe.wave.partner.f32(float %value, i32 %index) #1 { entry: %bits = bitcast float %value to i32 %partner.bits = call i32 @llvm.amdgcn.ds.bpermute(i32 %index, i32 %bits) %partner = bitcast i32 %partner.bits to float ret float %partner }"#;
const IDENTITY_WAVE_HELPERS: &str = r#"define internal i32 @recipe.wavefront.width() #1 { entry: ret i32 1 }
define internal i64 @recipe.clock() #1 { entry: %now = call i64 @recipe.cpu.clock() ret i64 %now }
define internal RECIPE_STATE @recipe.wave.partner(RECIPE_STATE %value, i32 %index) #1 { entry: ret RECIPE_STATE %value }
define internal float @recipe.wave.partner.f32(float %value, i32 %index) #1 { entry: ret float %value }"#;
/// The CPU's int8 dots, per state: the generic byte arithmetic under a float
/// state, none under a double one.
/// The int8 activation record of one 32-input step: the step's scale in the
/// state, then the 32 codes. 36 bytes under a float state, 40 under double.
fn q8_record(state: &str) -> usize {
	32 + q8_scale_bytes(state)
}
fn q8_scale_bytes(state: &str) -> usize {
	if state == "double" { 8 } else { 4 }
}
/// Whether a state carries the int8 dots: float and double both do, including
/// an integer dot with `acc = "fp64"` in the precision table.
fn int_state(state: &str) -> bool {
	state == "float" || state == "double"
}
/// glibc 2.44's binary32 `expf`, `sinf`, `cosf` and `tanhf` as LLVM IR, so a
/// `math = "libm"` step prints the bits the x86-64 libm prints on every
/// backend. `expf`, `sinf` and `cosf` are the ARM optimized-routines
/// algorithms as GCC contracts them for the FMA variants glibc dispatches to
/// (`__expf_fma`, `__sinf_fma`, `__cosf_fma`): every product-sum the
/// disassembly fuses is an `llvm.fma`, every other step a separate IEEE
/// operation. `tanhf` is the CORE-MATH correctly rounded rational
/// approximation, which glibc builds without contraction. Verified against the
/// installed libm over every binary32 input.
fn glibc_float_math() -> String {
	// The exp2f table: 2^(i/32) doubles, the low bits of the exponent word later
	// shifted in from the integer part.
	const EXP2F_TAB: [u64; 32] = [
		0x3ff0000000000000, 0x3fefd9b0d3158574, 0x3fefb5586cf9890f, 0x3fef9301d0125b51, 0x3fef72b83c7d517b, 0x3fef54873168b9aa, 0x3fef387a6e756238, 0x3fef1e9df51fdee1,
		0x3fef06fe0a31b715, 0x3feef1a7373aa9cb, 0x3feedea64c123422, 0x3feece086061892d, 0x3feebfdad5362a27, 0x3feeb42b569d4f82, 0x3feeab07dd485429, 0x3feea47eb03a5585,
		0x3feea09e667f3bcd, 0x3fee9f75e8ec5f74, 0x3feea11473eb0187, 0x3feea589994cce13, 0x3feeace5422aa0db, 0x3feeb737b0cdc5e5, 0x3feec49182a3f090, 0x3feed503b23e255d,
		0x3feee89f995ad3ad, 0x3feeff76f2fb5e47, 0x3fef199bdd85529c, 0x3fef3720dcef9069, 0x3fef5818dcfba487, 0x3fef7c97337b9b5f, 0x3fefa4afa2a490da, 0x3fefd0765b6e4540,
	];
	// 4/pi in 192 bits, eight bits per entry, for the large-argument reduction.
	const INV_PIO4: [u32; 24] = [
		0xa2, 0xa2f9, 0xa2f983, 0xa2f9836e, 0xf9836e4e, 0x836e4e44, 0x6e4e4415, 0x4e441529, 0x441529fc, 0x1529fc27, 0x29fc2757, 0xfc2757d1, 0x2757d1f5, 0x57d1f534, 0xd1f534dd,
		0xf534ddc0, 0x34ddc0db, 0xddc0db62, 0xc0db6295, 0xdb629599, 0x6295993c, 0x95993c43, 0x993c4390, 0x3c439041,
	];
	let d = |bits: u64| format!("0x{bits:016X}");
	let f = |bits: u32| format!("0x{:016X}", (f32::from_bits(bits) as f64).to_bits());
	// expf: InvLn2N = 0x1.71547652b82fep+0 * 32, SHIFT = 0x1.8p52, the poly scaled by 1/N^k.
	let (inv_ln2_n, shift, c0, c1, c2) = (d(0x40471547652b82fe), d(0x4338000000000000), d(0x3ebc6af84b912394), d(0x3f2ebfce50fac4f3), d(0x3f962e42ff0c52d6));
	// sincosf: 2/pi scaled by 2^24, pi/2, the cosine and sine polynomials, pi/2^63.
	let (hpi_inv, hpi, pi63) = (d(0x41645f306dc9c883), d(0x3ff921fb54442d18), d(0x3c1921fb54442d18));
	let (cos1, cos2, cos3, cos4) = (d(0xbfdffffffd0c621c), d(0x3fa55553e1068f19), d(0xbf56c087e89a359d), d(0x3ef99343027bf8c3));
	let (sin1, sin2, sin3) = (d(0xbfc555545995a603), d(0x3f81107605230bc4), d(0xbf2994eb3774cf24));
	let (ncos1, ncos2, ncos3, ncos4) = (d(0x3fdffffffd0c621c), d(0xbfa55553e1068f19), d(0x3f56c087e89a359d), d(0xbef99343027bf8c3));
	// tanhf: the CORE-MATH numerator and denominator.
	let cn = [d(0x3ff0000000000000), d(0x3fc30877b8b72d33), d(0x3f7694aa09ae9e5e), d(0x3f14101377abb729), d(0x3e9e0392b1db0018), d(0x3e12533756e546f7), d(0x3d6d62e5abe6ae8a), d(0x3c9b06be534182de)];
	let cd = [d(0x3ff0000000000000), d(0x3fded99131b0ebea), d(0x3fa0d27ed6c95a69), d(0x3f47cbdaca0e9fcc), d(0x3edb4e60b892578e), d(0x3e5a6f707c5c71ab), d(0x3dc35a8b6e2cd94c), d(0x3d0ca8230677aa01)];
	let (over, under, third, quarter_ulp) = (f(0x42b17217), f(0xc2cff1b4), f(0xbeaaaaab), f(0x33000000));
	let tab = EXP2F_TAB.iter().map(|word| format!("i64 {}", *word as i64)).collect::<Vec<_>>().join(", ");
	let pio4 = INV_PIO4.iter().map(|word| format!("i32 {}", *word as i32)).collect::<Vec<_>>().join(", ");
	format!(
		"; GLIBC BEGIN
@recipe_glibc_exp2f_tab = private unnamed_addr constant [32 x i64] [{tab}]
@recipe_glibc_inv_pio4 = private unnamed_addr constant [24 x i32] [{pio4}]
@recipe_glibc_sign = private unnamed_addr constant [4 x double] [double 1.0, double -1.0, double -1.0, double 1.0]
define internal float @recipe.glibc.expf(float %x) #1 {{
entry:
%bits = bitcast float %x to i32
%top = lshr i32 %bits, 20
%abstop = and i32 %top, 2047
%special = icmp uge i32 %abstop, 1067
br i1 %special, label %special.check, label %main
special.check:
%minus.inf = icmp eq i32 %bits, -8388608
br i1 %minus.inf, label %zero, label %special.nan
zero:
ret float 0.0
special.nan:
%nonfinite = icmp uge i32 %abstop, 2040
br i1 %nonfinite, label %nan, label %special.range
nan:
%doubled = fadd float %x, %x
ret float %doubled
special.range:
%over = fcmp ogt float %x, {over}
br i1 %over, label %overflow, label %under.check
overflow:
ret float 0x7FF0000000000000
under.check:
%under = fcmp olt float %x, {under}
br i1 %under, label %zero, label %main
main:
%xd = fpext float %x to double
%kd.shifted = call double @llvm.fma.f64(double {inv_ln2_n}, double %xd, double {shift})
%ki = bitcast double %kd.shifted to i64
%kd = fsub double %kd.shifted, {shift}
%neg.kd = fneg double %kd
%r = call double @llvm.fma.f64(double {inv_ln2_n}, double %xd, double %neg.kd)
%index = and i64 %ki, 31
%tab.ptr = getelementptr inbounds [32 x i64], ptr @recipe_glibc_exp2f_tab, i64 0, i64 %index
%tab = load i64, ptr %tab.ptr, align 8
%scaled = shl i64 %ki, 47
%t = add i64 %tab, %scaled
%s = bitcast i64 %t to double
%z = call double @llvm.fma.f64(double {c0}, double %r, double {c1})
%r2 = fmul double %r, %r
%y0 = call double @llvm.fma.f64(double {c2}, double %r, double 1.0)
%y1 = call double @llvm.fma.f64(double %z, double %r2, double %y0)
%y = fmul double %y1, %s
%result = fptrunc double %y to float
ret float %result
}}
define internal float @recipe.glibc.sincosf(float %y, i1 %want.cos) #1 {{
entry:
%bits = bitcast float %y to i32
%top = lshr i32 %bits, 20
%abstop = and i32 %top, 2047
%x = fpext float %y to double
%small = icmp ult i32 %abstop, 1012
br i1 %small, label %small.check, label %mid.check
small.check:
%tiny = icmp ult i32 %abstop, 920
br i1 %tiny, label %tiny.exit, label %small.poly
tiny.exit:
%tiny.value = select i1 %want.cos, float 1.0, float %y
ret float %tiny.value
small.poly:
%x2.small = fmul double %x, %x
br i1 %want.cos, label %cos.poly, label %sin.poly
mid.check:
%mid = icmp ult i32 %abstop, 1071
br i1 %mid, label %mid.reduce, label %large.check
mid.reduce:
%r.mid = fmul double %x, {hpi_inv}
%r.int = fptosi double %r.mid to i32
%r.biased = add i32 %r.int, 8388608
%n.mid = ashr i32 %r.biased, 24
%n.mid.d = sitofp i32 %n.mid to double
%n.mid.neg = fneg double %n.mid.d
%xr.mid = call double @llvm.fma.f64(double %n.mid.neg, double {hpi}, double %x)
%table.mid = and i32 %n.mid, 2
%parity.mid = and i32 %n.mid, 1
%sign.mid = and i32 %n.mid, 3
br label %reduced
large.check:
%finite = icmp ult i32 %abstop, 2040
br i1 %finite, label %large.reduce, label %invalid
invalid:
%difference = fsub float %y, %y
%nan = fdiv float %difference, %difference
ret float %nan
large.reduce:
%arr.shift = lshr i32 %bits, 26
%arr.index = and i32 %arr.shift, 15
%shift.raw = lshr i32 %bits, 23
%shift = and i32 %shift.raw, 7
%mantissa.raw = and i32 %bits, 16777215
%mantissa = or i32 %mantissa.raw, 8388608
%xi = shl i32 %mantissa, %shift
%arr.index.wide = zext i32 %arr.index to i64
%arr.index.4 = add i64 %arr.index.wide, 4
%arr.index.8 = add i64 %arr.index.wide, 8
%a0.ptr = getelementptr inbounds [24 x i32], ptr @recipe_glibc_inv_pio4, i64 0, i64 %arr.index.wide
%a4.ptr = getelementptr inbounds [24 x i32], ptr @recipe_glibc_inv_pio4, i64 0, i64 %arr.index.4
%a8.ptr = getelementptr inbounds [24 x i32], ptr @recipe_glibc_inv_pio4, i64 0, i64 %arr.index.8
%a0 = load i32, ptr %a0.ptr, align 4
%a4 = load i32, ptr %a4.ptr, align 4
%a8 = load i32, ptr %a8.ptr, align 4
%res0.narrow = mul i32 %xi, %a0
%res0 = zext i32 %res0.narrow to i64
%xi.wide = zext i32 %xi to i64
%a4.wide = zext i32 %a4 to i64
%a8.wide = zext i32 %a8 to i64
%res1 = mul i64 %xi.wide, %a4.wide
%res2 = mul i64 %xi.wide, %a8.wide
%res2.high = lshr i64 %res2, 32
%res0.high = shl i64 %res0, 32
%res0.joined = or i64 %res2.high, %res0.high
%res0.sum = add i64 %res0.joined, %res1
%biased = add i64 %res0.sum, 2305843009213693952
%n.large.wide = lshr i64 %biased, 62
%n.large.shifted = shl i64 %n.large.wide, 62
%remainder = sub i64 %res0.sum, %n.large.shifted
%remainder.d = sitofp i64 %remainder to double
%xr.large = fmul double %remainder.d, {pi63}
%n.large = trunc i64 %n.large.wide to i32
%sign.bit = lshr i32 %bits, 31
%quadrant.large = add i32 %n.large, %sign.bit
%table.large = and i32 %quadrant.large, 2
%parity.large = and i32 %n.large, 1
%sign.large = and i32 %quadrant.large, 3
br label %reduced
reduced:
%xr = phi double [ %xr.mid, %mid.reduce ], [ %xr.large, %large.reduce ]
%table = phi i32 [ %table.mid, %mid.reduce ], [ %table.large, %large.reduce ]
%parity = phi i32 [ %parity.mid, %mid.reduce ], [ %parity.large, %large.reduce ]
%sign.index = phi i32 [ %sign.mid, %mid.reduce ], [ %sign.large, %large.reduce ]
%x2.reduced = fmul double %xr, %xr
%odd = icmp ne i32 %parity, 0
%use.cos = xor i1 %odd, %want.cos
%second = icmp ne i32 %table, 0
br i1 %use.cos, label %cos.poly, label %sin.signed
sin.signed:
%sign.index.wide = zext i32 %sign.index to i64
%sign.ptr = getelementptr inbounds [4 x double], ptr @recipe_glibc_sign, i64 0, i64 %sign.index.wide
%sign = load double, ptr %sign.ptr, align 8
%xs.signed = fmul double %xr, %sign
br label %sin.poly
sin.poly:
%xs = phi double [ %x, %small.poly ], [ %xs.signed, %sin.signed ]
%x2.sin = phi double [ %x2.small, %small.poly ], [ %x2.reduced, %sin.signed ]
%s1v = call double @llvm.fma.f64(double %x2.sin, double {sin3}, double {sin2})
%x3 = fmul double %x2.sin, %xs
%x5 = fmul double %x2.sin, %x3
%s = call double @llvm.fma.f64(double %x3, double {sin1}, double %xs)
%sin.result = call double @llvm.fma.f64(double %s1v, double %x5, double %s)
%sin.narrow = fptrunc double %sin.result to float
ret float %sin.narrow
cos.poly:
%x2.cos = phi double [ %x2.small, %small.poly ], [ %x2.reduced, %reduced ]
%negated = phi i1 [ false, %small.poly ], [ %second, %reduced ]
%c0 = select i1 %negated, double -1.0, double 1.0
%c1 = select i1 %negated, double {ncos1}, double {cos1}
%c2 = select i1 %negated, double {ncos2}, double {cos2}
%c3 = select i1 %negated, double {ncos3}, double {cos3}
%c4 = select i1 %negated, double {ncos4}, double {cos4}
%x4 = fmul double %x2.cos, %x2.cos
%c2v = call double @llvm.fma.f64(double %x2.cos, double %c4, double %c3)
%x6 = fmul double %x2.cos, %x4
%c1v = call double @llvm.fma.f64(double %x2.cos, double %c1, double %c0)
%c = call double @llvm.fma.f64(double %x4, double %c2, double %c1v)
%cos.result = call double @llvm.fma.f64(double %c2v, double %x6, double %c)
%cos.narrow = fptrunc double %cos.result to float
ret float %cos.narrow
}}
define internal float @recipe.glibc.sinf(float %y) #1 {{ entry: %result = call float @recipe.glibc.sincosf(float %y, i1 false) ret float %result }}
define internal float @recipe.glibc.cosf(float %y) #1 {{ entry: %result = call float @recipe.glibc.sincosf(float %y, i1 true) ret float %result }}
define internal float @recipe.glibc.tanhf(float %x) #1 {{
entry:
%bits = bitcast float %x to i32
%exponent.raw = lshr i32 %bits, 23
%magnitude = shl i32 %bits, 1
%exponent = and i32 %exponent.raw, 255
%nonfinite = icmp eq i32 %exponent, 255
br i1 %nonfinite, label %nonfinite.check, label %finite
nonfinite.check:
%payload = shl i32 %bits, 9
%is.nan = icmp ne i32 %payload, 0
br i1 %is.nan, label %nan, label %infinite
nan:
%doubled = fadd float %x, %x
ret float %doubled
infinite:
%negative = icmp slt i32 %bits, 0
%unit = select i1 %negative, float -1.0, float 1.0
ret float %unit
finite:
%small = icmp ult i32 %exponent, 115
br i1 %small, label %small.check, label %range
small.check:
%tiny = icmp ult i32 %exponent, 102
br i1 %tiny, label %tiny.check, label %cubic
tiny.check:
%zero = icmp eq i32 %magnitude, 0
br i1 %zero, label %identity, label %linear
identity:
ret float %x
linear:
%neg.x = fneg float %x
%abs.x = call float @llvm.fabs.f32(float %x)
%linear.value = call float @llvm.fma.f32(float %neg.x, float %abs.x, float %x)
ret float %linear.value
cubic:
%x2 = fmul float %x, %x
%cubic.scale = fmul float {third}, %x2
%cubic.value = call float @llvm.fma.f32(float %x, float %cubic.scale, float %x)
ret float %cubic.value
range:
%saturated = icmp ugt i32 %magnitude, 2183158118
br i1 %saturated, label %saturate, label %rational
saturate:
%one = call float @llvm.copysign.f32(float 1.0, float %x)
%step = call float @llvm.copysign.f32(float {quarter_ulp}, float %x)
%saturated.value = fsub float %one, %step
ret float %saturated.value
rational:
%z = fpext float %x to double
%z2 = fmul double %z, %z
%z4 = fmul double %z2, %z2
%z8 = fmul double %z4, %z4
%n0.product = fmul double %z2, {cn1}
%n0 = fadd double {cn0}, %n0.product
%n2.product = fmul double %z2, {cn3}
%n2 = fadd double {cn2}, %n2.product
%n4.product = fmul double %z2, {cn5}
%n4 = fadd double {cn4}, %n4.product
%n6.product = fmul double %z2, {cn7}
%n6 = fadd double {cn6}, %n6.product
%n0.z4 = fmul double %z4, %n2
%n0.b = fadd double %n0, %n0.z4
%n4.z4 = fmul double %z4, %n6
%n4.b = fadd double %n4, %n4.z4
%n0.z8 = fmul double %z8, %n4.b
%n0.c = fadd double %n0.b, %n0.z8
%d0.product = fmul double %z2, {cd1}
%d0 = fadd double {cd0}, %d0.product
%d2.product = fmul double %z2, {cd3}
%d2 = fadd double {cd2}, %d2.product
%d4.product = fmul double %z2, {cd5}
%d4 = fadd double {cd4}, %d4.product
%d6.product = fmul double %z2, {cd7}
%d6 = fadd double {cd6}, %d6.product
%d0.z4 = fmul double %z4, %d2
%d0.b = fadd double %d0, %d0.z4
%d4.z4 = fmul double %z4, %d6
%d4.b = fadd double %d4, %d4.z4
%d0.z8 = fmul double %z8, %d4.b
%d0.c = fadd double %d0.b, %d0.z8
%numerator = fmul double %z, %n0.c
%ratio = fdiv double %numerator, %d0.c
%result = fptrunc double %ratio to float
ret float %result
}}
; GLIBC END
",
		cn0 = cn[0], cn1 = cn[1], cn2 = cn[2], cn3 = cn[3], cn4 = cn[4], cn5 = cn[5], cn6 = cn[6], cn7 = cn[7],
		cd0 = cd[0], cd1 = cd[1], cd2 = cd[2], cd3 = cd[3], cd4 = cd[4], cd5 = cd[5], cd6 = cd[6], cd7 = cd[7],
	)
}
/// The intrinsic declarations the glibc block needs, added once each.
fn with_glibc_declares(mut ir: String) -> String {
	for declaration in ["declare double @llvm.fma.f64(double, double, double)", "declare float @llvm.fma.f32(float, float, float)", "declare float @llvm.fabs.f32(float)", "declare float @llvm.copysign.f32(float, float)"] {
		if !ir.contains(declaration) {
			ir.push('\n');
			ir.push_str(declaration);
			ir.push('\n');
		}
	}
	ir
}
/// The transcendental steps a `math = "libm"` block takes. Under a float
/// state exp, cos, sin and tanh are glibc's binary32 routines on every
/// backend (`glibc_float_math`), so a libm step prints the same bits on the
/// CPU and on the GPUs; log and pow take the platform libm on the CPU and the
/// portable evaluations elsewhere. Under a double state the CPU calls the
/// platform libm and the GPUs evaluate portably.
fn rope_math_helpers(state: &str, cpu: bool) -> String {
	let portable = |name: &str| format!("define internal {state} @recipe.libm.{name}({state} %value) #1 {{ entry: %result = call {state} @recipe.state.{name}({state} %value) ret {state} %result }}\n");
	let portable_pow = format!("define internal {state} @recipe.libm.pow({state} %base, {state} %exponent) #1 {{ entry: %log = call {state} @recipe.state.log({state} %base) %scaled = call {state} @recipe.state.mul({state} %log, {state} %exponent) %result = call {state} @recipe.state.exp({state} %scaled) ret {state} %result }}\n");
	let (intrinsic, tanh_suffix) = match state {
		"float" => ("f32", "f"),
		"double" => ("f64", ""),
		_ => return format!("{}{}{}{}{}{portable_pow}", portable("cos"), portable("sin"), portable("exp"), portable("tanh"), portable("log")),
	};
	if state == "float" {
		let mut ir = glibc_float_math();
		for (name, port) in [("exp", "expf"), ("cos", "cosf"), ("sin", "sinf"), ("tanh", "tanhf")] {
			ir.push_str(&format!("define internal float @recipe.libm.{name}(float %value) #1 {{ entry: %result = call float @recipe.glibc.{port}(float %value) ret float %result }}\n"));
		}
		if cpu {
			ir.push_str("declare float @llvm.log.f32(float)\ndeclare float @llvm.pow.f32(float, float)\ndefine internal float @recipe.libm.log(float %value) #1 { entry: %result = call float @llvm.log.f32(float %value) ret float %result }\ndefine internal float @recipe.libm.pow(float %base, float %exponent) #1 { entry: %result = call float @llvm.pow.f32(float %base, float %exponent) ret float %result }\n");
		} else {
			ir.push_str(&portable("log"));
			ir.push_str(&portable_pow);
		}
		return ir;
	}
	if !cpu {
		return format!("{}{}{}{}{}{portable_pow}", portable("cos"), portable("sin"), portable("exp"), portable("tanh"), portable("log"));
	}
	format!("declare {state} @llvm.cos.{intrinsic}({state})\ndeclare {state} @llvm.sin.{intrinsic}({state})\ndeclare {state} @llvm.exp.{intrinsic}({state})\ndeclare {state} @llvm.log.{intrinsic}({state})\ndeclare {state} @tanh{tanh_suffix}({state})\ndeclare {state} @llvm.pow.{intrinsic}({state}, {state})\ndefine internal {state} @recipe.libm.exp({state} %value) #1 {{ entry: %result = call {state} @llvm.exp.{intrinsic}({state} %value) ret {state} %result }}\ndefine internal {state} @recipe.libm.log({state} %value) #1 {{ entry: %result = call {state} @llvm.log.{intrinsic}({state} %value) ret {state} %result }}\ndefine internal {state} @recipe.libm.tanh({state} %value) #1 {{ entry: %result = call {state} @tanh{tanh_suffix}({state} %value) ret {state} %result }}\ndefine internal {state} @recipe.libm.cos({state} %value) #1 {{ entry: %result = call {state} @llvm.cos.{intrinsic}({state} %value) ret {state} %result }}\ndefine internal {state} @recipe.libm.sin({state} %value) #1 {{ entry: %result = call {state} @llvm.sin.{intrinsic}({state} %value) ret {state} %result }}\ndefine internal {state} @recipe.libm.pow({state} %base, {state} %exponent) #1 {{ entry: %result = call {state} @llvm.pow.{intrinsic}({state} %base, {state} %exponent) ret {state} %result }}\n")
}
/// The int partial helpers of one template: the Q4_K slice ints and the Q6_K
/// word parts.
fn int_partial_helpers(state: &str) -> String {
	format!("{}{}", q4_ints_helper(state), q6_part_helper(state))
}
fn cpu_int8_helpers(state: &str) -> String {
	format!(
		"define internal i1 @recipe.int8.dots() #1 {{ entry: ret i1 {} }}\n{}{}{}{}{}{}",
		int_state(state),
		if int_state(state) { generic_dot4_helpers() } else { String::new() },
		amd_q4_slice_helper(state, int_state(state)),
		amd_q6_slice_helper(state, int_state(state)),
		amd_block32_slice_helper(state, int_state(state)),
		int_partial_helpers(state),
		rope_math_helpers(state, true)
	)
}
/// A CUDA warp of 32 lanes is the wave; a partner is read through
/// shfl.sync with every lane of the warp named, so each lane of a wave runs
/// every reduction step. The `index` is the partner lane times four, as the
/// AMD bpermute takes it. The int8 dots are the byte arithmetic of the generic helpers.
fn nvidia_wave_helpers(state: &str) -> String {
	let partner = if state == "double" {
		"%bits = bitcast double %value to i64 %low.bits = trunc i64 %bits to i32 %high.shift = lshr i64 %bits, 32 %high.bits = trunc i64 %high.shift to i32 %partner.low = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %low.bits, i32 %lane, i32 31) %partner.high = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %high.bits, i32 %lane, i32 31) %partner.high.wide = zext i32 %partner.high to i64 %partner.high.shift = shl i64 %partner.high.wide, 32 %partner.low.wide = zext i32 %partner.low to i64 %partner.bits = or i64 %partner.high.shift, %partner.low.wide %partner = bitcast i64 %partner.bits to double ret double %partner"
	} else {
		"%bits = bitcast float %value to i32 %partner.bits = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %bits, i32 %lane, i32 31) %partner = bitcast i32 %partner.bits to float ret float %partner"
	};
	format!(
		"declare i32 @llvm.nvvm.shfl.sync.idx.i32(i32, i32, i32, i32)
declare i64 @llvm.nvvm.read.ptx.sreg.globaltimer()
define internal i32 @recipe.wavefront.width() #1 {{ entry: ret i32 32 }}
define internal i1 @recipe.int8.dots() #1 {{ entry: ret i1 {int8} }}
define internal i64 @recipe.clock() #1 {{ entry: %now = call i64 @llvm.nvvm.read.ptx.sreg.globaltimer() ret i64 %now }}
define internal {state} @recipe.wave.partner({state} %value, i32 %index) #1 {{ entry: %lane = lshr i32 %index, 2 {partner} }}
define internal float @recipe.wave.partner.f32(float %value, i32 %index) #1 {{ entry: %lane = lshr i32 %index, 2 %bits = bitcast float %value to i32 %partner.bits = call i32 @llvm.nvvm.shfl.sync.idx.i32(i32 -1, i32 %bits, i32 %lane, i32 31) %partner = bitcast i32 %partner.bits to float ret float %partner }}
{dot4}{q4}{q6}{b32}{ints}{rope}",
		rope = rope_math_helpers(state, false),
		int8 = int_state(state),
		dot4 = if int_state(state) { generic_dot4_helpers() } else { String::new() },
		ints = int_partial_helpers(state),
		q4 = amd_q4_slice_helper(state, int_state(state)),
		q6 = amd_q6_slice_helper(state, int_state(state)),
		b32 = amd_block32_slice_helper(state, int_state(state)),
	)
}
/// The four-byte dot products and the byte permute the int8 dots use, as
/// the backend has them: AMD's sudot4 and perm, and on every other backend
/// the same arithmetic on the bytes. dot4.su takes unsigned bytes in `a`
/// against signed bytes in `b`; dot4.ss signed against signed. perm takes
/// one selector byte per lane, 0-3 a byte of `lo`, 4-7 a byte of `hi`.
const AMD_DOT4_HELPERS: &str = r#"declare i32 @llvm.amdgcn.sudot4(i1, i32, i1, i32, i32, i1)
declare i32 @llvm.amdgcn.perm(i32, i32, i32)
define internal i32 @recipe.dot4.su(i32 %a, i32 %b) #1 { entry: %r = call i32 @llvm.amdgcn.sudot4(i1 false, i32 %a, i1 true, i32 %b, i32 0, i1 false) ret i32 %r }
define internal i32 @recipe.dot4.ss(i32 %a, i32 %b) #1 { entry: %r = call i32 @llvm.amdgcn.sudot4(i1 true, i32 %a, i1 true, i32 %b, i32 0, i1 false) ret i32 %r }
define internal i32 @recipe.perm(i32 %hi, i32 %lo, i32 %sel) #1 { entry: %r = call i32 @llvm.amdgcn.perm(i32 %hi, i32 %lo, i32 %sel) ret i32 %r }
"#;
fn generic_dot4_helpers() -> String {
	let mut ir = String::new();
	for (name, signed) in [("su", false), ("ss", true)] {
		ir.push_str(&format!("define internal i32 @recipe.dot4.{name}(i32 %a, i32 %b) #1 {{ entry:\n"));
		let mut sum = "0".to_owned();
		for byte in 0..4 {
			let shift = 24 - byte * 8;
			let a = if signed { format!("%a{byte}.s = shl i32 %a, {shift}\n%a{byte} = ashr i32 %a{byte}.s, 24\n") } else { format!("%a{byte}.s = lshr i32 %a, {}\n%a{byte} = and i32 %a{byte}.s, 255\n", byte * 8) };
			ir.push_str(&a);
			ir.push_str(&format!("%b{byte}.s = shl i32 %b, {shift}\n%b{byte} = ashr i32 %b{byte}.s, 24\n%p{byte} = mul i32 %a{byte}, %b{byte}\n%s{byte} = add i32 {sum}, %p{byte}\n"));
			sum = format!("%s{byte}");
		}
		ir.push_str(&format!("ret i32 {sum}\n}}\n"));
	}
	ir.push_str("define internal i32 @recipe.perm(i32 %hi, i32 %lo, i32 %sel) #1 { entry:\n");
	let mut out = "0".to_owned();
	for byte in 0..4 {
		ir.push_str(&format!("%s{byte}.raw = lshr i32 %sel, {}\n%s{byte} = and i32 %s{byte}.raw, 7\n%s{byte}.high = icmp uge i32 %s{byte}, 4\n%s{byte}.low.shift = mul i32 %s{byte}, 8\n%s{byte}.high.index = sub i32 %s{byte}, 4\n%s{byte}.high.shift = mul i32 %s{byte}.high.index, 8\n%s{byte}.from.lo = lshr i32 %lo, %s{byte}.low.shift\n%s{byte}.from.hi = lshr i32 %hi, %s{byte}.high.shift\n%s{byte}.picked = select i1 %s{byte}.high, i32 %s{byte}.from.hi, i32 %s{byte}.from.lo\n%s{byte}.byte = and i32 %s{byte}.picked, 255\n%s{byte}.placed = shl i32 %s{byte}.byte, {}\n%o{byte} = or i32 {out}, %s{byte}.placed\n", byte * 8, byte * 8));
		out = format!("%o{byte}");
	}
	ir.push_str(&format!("ret i32 {out}\n}}\n"));
	ir
}
/// The IQ4_NL levels, the table every IQ4 code indexes.
const IQ4_LEVELS: [i8; 16] = [-127, -104, -83, -65, -49, -35, -22, -10, 1, 13, 25, 38, 53, 69, 89, 113];
/// One 16-value slice of a 32-value block: IQ4_NL (kind 1), Q4_0 (2), Q4_1 (3)
/// or Q8_0 (4), against one Q8_1 activation block. Slice 0 takes the low
/// nibbles (or the first 16 bytes), slice 1 the high ones.
fn amd_block32_slice_helper(state: &str, full: bool) -> String {
	let signature = format!("define internal {state} @recipe.block32.slice(i32 %kind, ptr addrspace(1) %weights, i64 %offset, ptr addrspace(3) %q8, i32 %slice) #1 {{ entry:\n");
	if !full {
		return format!("{signature}call void @llvm.trap()\nunreachable\n}}\n");
	}
	let word = |at: usize| u32::from_le_bytes([IQ4_LEVELS[at] as u8, IQ4_LEVELS[at + 1] as u8, IQ4_LEVELS[at + 2] as u8, IQ4_LEVELS[at + 3] as u8]);
	let (t0, t1, t2, t3) = (word(0), word(4), word(8), word(12));
	let mut ir = signature;
	ir.push_str(&format!("%block = getelementptr i8, ptr addrspace(1) %weights, i64 %offset\n%d.bits = load half, ptr addrspace(1) %block, align 2\n%d = call {state} @recipe.state.from.f16(half %d.bits)\n%half.wide = zext i32 %slice to i64\n%q8.half.offset = mul i64 %half.wide, 16\n%q8.d.state = load {state}, ptr addrspace(3) %q8, align {q8_align}\n%nibble.shift = mul i32 %slice, 4\n%byte.half = mul i64 %half.wide, 16\n%is.iq4 = icmp eq i32 %kind, 1\n%is.q41 = icmp eq i32 %kind, 3\n%is.q80 = icmp eq i32 %kind, 4\n%data.q41 = select i1 %is.q41, i64 4, i64 2\n%data.base = select i1 %is.q80, i64 %byte.half, i64 0\n%data = add i64 %data.q41, %data.base\n%m.ptr = getelementptr i8, ptr addrspace(1) %block, i64 2\n%m.bits = load half, ptr addrspace(1) %m.ptr, align 2\n%m.loaded = call {state} @recipe.state.from.f16(half %m.bits)\n%zero = call {state} @recipe.state.from.u1(i1 false)\n%m = select i1 %is.q41, {state} %m.loaded, {state} %zero\n%dot.zero = add i32 0, 0\n%q8.zero = add i32 0, 0\n", q8_align = q8_scale_bytes(state)));
	let (mut dot_sum, mut q8_sum) = ("%dot.zero".to_owned(), "%q8.zero".to_owned());
	for w in 0..4 {
		ir.push_str(&format!("%w{w}.offset = add i64 %data, {at}\n%w{w}.ptr = getelementptr i8, ptr addrspace(1) %block, i64 %w{w}.offset\n%w{w}.word = load i32, ptr addrspace(1) %w{w}.ptr, align 2\n%w{w}.shifted = lshr i32 %w{w}.word, %nibble.shift\n%w{w}.codes = and i32 %w{w}.shifted, 252645135\n%w{w}.sel = and i32 %w{w}.codes, 117901063\n%w{w}.lo = call i32 @recipe.perm(i32 {t1}, i32 {t0}, i32 %w{w}.sel)\n%w{w}.hi = call i32 @recipe.perm(i32 {t3}, i32 {t2}, i32 %w{w}.sel)\n%w{w}.top = lshr i32 %w{w}.codes, 3\n%w{w}.top.bits = and i32 %w{w}.top, 16843009\n%w{w}.mask = mul i32 %w{w}.top.bits, 255\n%w{w}.mask.not = xor i32 %w{w}.mask, -1\n%w{w}.hi.masked = and i32 %w{w}.hi, %w{w}.mask\n%w{w}.lo.masked = and i32 %w{w}.lo, %w{w}.mask.not\n%w{w}.levels = or i32 %w{w}.hi.masked, %w{w}.lo.masked\n%w{w}.q8.offset = add i64 %q8.half.offset, {q8at}\n%w{w}.q8.ptr = getelementptr i8, ptr addrspace(3) %q8, i64 %w{w}.q8.offset\n%w{w}.q8 = load i32, ptr addrspace(3) %w{w}.q8.ptr, align 4\n%w{w}.dot.iq4 = call i32 @recipe.dot4.ss(i32 %w{w}.levels, i32 %w{w}.q8)\n%w{w}.dot.q80 = call i32 @recipe.dot4.ss(i32 %w{w}.word, i32 %w{w}.q8)\n%w{w}.dot.q4 = call i32 @recipe.dot4.su(i32 %w{w}.codes, i32 %w{w}.q8)\n%w{w}.dot.signed = select i1 %is.q80, i32 %w{w}.dot.q80, i32 %w{w}.dot.q4\n%w{w}.dot = select i1 %is.iq4, i32 %w{w}.dot.iq4, i32 %w{w}.dot.signed\n%w{w}.sum = call i32 @recipe.dot4.su(i32 16843009, i32 %w{w}.q8)\n%w{w}.dot.acc = add i32 {dot_sum}, %w{w}.dot\n%w{w}.q8.acc = add i32 {q8_sum}, %w{w}.sum\n", at = w * 4, q8at = q8_scale_bytes(state) + w * 4));
		dot_sum = format!("%w{w}.dot.acc");
		q8_sum = format!("%w{w}.q8.acc");
	}
	// Q4_0 codes carry an offset of eight; Q4_1 adds its minimum times the
	// activation sum; IQ4_NL and Q8_0 are signed already.
	ir.push_str(&format!("%is.q40 = icmp eq i32 %kind, 2\n%q8.eight = mul i32 {q8_sum}, 8\n%dot.q40 = sub i32 {dot_sum}, %q8.eight\n%dot.final = select i1 %is.q40, i32 %dot.q40, i32 {dot_sum}\n%dot.value = call {state} @recipe.state.from.s32(i32 %dot.final)\n%q8.value = call {state} @recipe.state.from.s32(i32 {q8_sum})\n%dot.scaled = call {state} @recipe.state.mul({state} %d, {state} %dot.value)\n%minimum.scaled = call {state} @recipe.state.mul({state} %m, {state} %q8.value)\n%value = call {state} @recipe.state.add({state} %dot.scaled, {state} %minimum.scaled)\n%result = call {state} @recipe.state.mul({state} %q8.d.state, {state} %value)\nret {state} %result\n}}\n"));
	ir
}
/// One 16-value Q4_K slice. The caller assigns adjacent slices to the lanes
/// of a wave, so this helper keeps only four dot4 words live at once.
fn amd_q4_slice_helper(state: &str, full: bool) -> String {
	if !full {
		return format!("define internal {state} @recipe.q4k.slice(ptr addrspace(1) %weights, i64 %offset, ptr addrspace(3) %q8, i32 %slice) #1 {{ entry: call void @llvm.trap() unreachable }}\n");
	}
	let mut ir = String::new();
	ir.push_str(&format!("define internal {state} @recipe.q4k.slice(ptr addrspace(1) %weights, i64 %offset, ptr addrspace(3) %q8, i32 %slice) #1 {{ entry:\n"));
	ir.push_str("%block = getelementptr i8, ptr addrspace(1) %weights, i64 %offset\n%d.ptr = getelementptr i8, ptr addrspace(1) %block, i64 0\n%d.bits = load half, ptr addrspace(1) %d.ptr, align 2\n%d = call ");
	ir.push_str(state);
	ir.push_str(" @recipe.state.from.f16(half %d.bits)\n%dmin.ptr = getelementptr i8, ptr addrspace(1) %block, i64 2\n%dmin.bits = load half, ptr addrspace(1) %dmin.ptr, align 2\n%dmin = call ");
	ir.push_str(state);
	ir.push_str(" @recipe.state.from.f16(half %dmin.bits)\n%group = udiv i32 %slice, 2\n%group.wide = zext i32 %group to i64\n%half = and i32 %slice, 1\n%group.low = icmp ult i32 %group, 4\n%group.plus = add i32 %group, 4\n%group.minus = sub i32 %group, 4\n%scale.index = select i1 %group.low, i32 %group, i32 %group.plus\n%other.index = select i1 %group.low, i32 %group.plus, i32 %group.minus\n%scale.index.wide = zext i32 %scale.index to i64\n%other.index.wide = zext i32 %other.index to i64\n%scale.offset = add i64 4, %scale.index.wide\n%other.offset = add i64 4, %other.index.wide\n%scale.ptr = getelementptr i8, ptr addrspace(1) %block, i64 %scale.offset\n%scale.byte = load i8, ptr addrspace(1) %scale.ptr, align 1\n%other.ptr = getelementptr i8, ptr addrspace(1) %block, i64 %other.offset\n%other.byte = load i8, ptr addrspace(1) %other.ptr, align 1\n%scale.raw = zext i8 %scale.byte to i32\n%other.raw = zext i8 %other.byte to i32\n%scale.low = and i32 %scale.raw, 63\n%minimum.low = and i32 %other.raw, 63\n%scale.high.low = and i32 %scale.raw, 15\n%minimum.high.low = lshr i32 %scale.raw, 4\n%high.bits = and i32 %other.raw, 192\n%high = lshr i32 %high.bits, 2\n%scale.high = or i32 %scale.high.low, %high\n%minimum.high.offset = add i64 4, %group.wide\n%minimum.high.ptr = getelementptr i8, ptr addrspace(1) %block, i64 %minimum.high.offset\n%minimum.high.byte = load i8, ptr addrspace(1) %minimum.high.ptr, align 1\n%minimum.high.raw = zext i8 %minimum.high.byte to i32\n%minimum.high.bits = and i32 %minimum.high.raw, 192\n%minimum.high.top = lshr i32 %minimum.high.bits, 2\n%minimum.high = or i32 %minimum.high.low, %minimum.high.top\n%minimum = select i1 %group.low, i32 %minimum.low, i32 %minimum.high\n%scale.code = select i1 %group.low, i32 %scale.low, i32 %scale.high\n%scale.value = call ");
	ir.push_str(state);
	ir.push_str(" @recipe.state.from.u32(i32 %scale.code)\n%minimum.value = call ");
	ir.push_str(state);
	ir.push_str(" @recipe.state.from.u32(i32 %minimum)\n%group.d = call ");
	ir.push_str(state);
	ir.push_str(" @recipe.state.mul(");
	ir.push_str(state);
	ir.push_str(" %d, ");
	ir.push_str(state);
	ir.push_str(" %scale.value)\n%group.dmin = call ");
	ir.push_str(state);
	ir.push_str(" @recipe.state.mul(");
	ir.push_str(state);
	ir.push_str(" %dmin, ");
	ir.push_str(state);
	ir.push_str(" %minimum.value)\n%pair = udiv i32 %group, 2\n%pair.wide = zext i32 %pair to i64\n%q4.base.part = mul i64 %pair.wide, 32\n%q4.base = add i64 %q4.base.part, 16\n%group.shift = and i32 %group, 1\n%q4.shift = mul i32 %group.shift, 4\n%half.wide = zext i32 %half to i64\n%q4.half.offset = mul i64 %half.wide, 16\n%q4.base.half = add i64 %q4.base, %q4.half.offset\n%q8.half.offset = mul i64 %half.wide, 16\n%q8.group = zext i32 %group to i64\n");
	ir.push_str(&format!("%q8.offset = mul i64 %q8.group, {q8_record}\n%q8.block = getelementptr i8, ptr addrspace(3) %q8, i64 %q8.offset\n%q8.d.state = load {state}, ptr addrspace(3) %q8.block, align {q8_align}\n", q8_record = q8_record(state), q8_align = q8_scale_bytes(state)));
	let mut dot_sum = "%dot.zero".to_owned();
	let mut q8_sum = "%q8.zero".to_owned();
	ir.push_str("%dot.zero = add i32 0, 0\n%q8.zero = add i32 0, 0\n");
	for word in 0..4 {
		let q8_offset = q8_scale_bytes(state) + word * 4;
		let word_offset = word * 4;
		ir.push_str(&format!(
			"%w{word}.q4.offset = add i64 %q4.base.half, {word_offset}\n%w{word}.q4.ptr = getelementptr i8, ptr addrspace(1) %block, i64 %w{word}.q4.offset\n%w{word}.q4.word = load i32, ptr addrspace(1) %w{word}.q4.ptr, align 2\n%w{word}.q4.shifted = lshr i32 %w{word}.q4.word, %q4.shift\n%w{word}.q4.codes = and i32 %w{word}.q4.shifted, 252645135\n%w{word}.q8.offset = add i64 %q8.half.offset, {q8_offset}\n%w{word}.q8.ptr = getelementptr i8, ptr addrspace(3) %q8.block, i64 %w{word}.q8.offset\n%w{word}.q8.word = load i32, ptr addrspace(3) %w{word}.q8.ptr, align 4\n%w{word}.dot = call i32 @recipe.dot4.su(i32 %w{word}.q4.codes, i32 %w{word}.q8.word)\n%w{word}.sum = call i32 @recipe.dot4.su(i32 16843009, i32 %w{word}.q8.word)\n",
			q8_offset = q8_offset,
			word_offset = word_offset,
		));
		let next_dot = format!("%w{word}.dot.sum");
		let next_q8 = format!("%w{word}.q8.sum");
		ir.push_str(&format!("{next_dot} = add i32 {dot_sum}, %w{word}.dot\n{next_q8} = add i32 {q8_sum}, %w{word}.sum\n", next_dot = next_dot, next_q8 = next_q8));
		dot_sum = next_dot;
		q8_sum = next_q8;
	}
	ir.push_str(&format!("%dot.value = call {state} @recipe.state.from.s32(i32 {dot_sum})\n%q8.value = call {state} @recipe.state.from.s32(i32 {q8_sum})\n%dot.scaled = call {state} @recipe.state.mul({state} %group.d, {state} %dot.value)\n%minimum.scaled = call {state} @recipe.state.mul({state} %group.dmin, {state} %q8.value)\n%value = call {state} @recipe.state.sub({state} %dot.scaled, {state} %minimum.scaled)\n%result = call {state} @recipe.state.mul({state} %q8.d.state, {state} %value)\nret {state} %result\n}}\n", state = state, dot_sum = dot_sum, q8_sum = q8_sum));
	ir
}
/// The int partials of one Q4_K slice under a 256-value step: the slice's
/// codes times its Q8 codes, times the group's 6-bit scale, and the group's
/// 6-bit minimum times the Q8 codes' sum — both exact in i32, so a block's
/// 16 slices add in any order and the block's float math happens once, in
/// the order llama.cpp's Q4_K kernels use.
fn q4_ints_helper(state: &str) -> String {
	if !int_state(state) {
		return "define internal i64 @recipe.q4k.ints(ptr addrspace(1) %weights, i64 %offset, ptr addrspace(3) %q8, i32 %slice) #1 { entry: call void @llvm.trap() unreachable }\n".to_owned();
	}
	let full = amd_q4_slice_helper(state, true);
	let head = full.split("%dot.value = call").next().expect("the slice helper computes its int sums before its float tail");
	// The two partials come back in one i64 (the dot in the high word, the
	// minimum sum in the low): the variant linker reads a definition's name
	// up to its first brace, so an aggregate return type is not for it.
	let head = head.replacen(&format!("define internal {state} @recipe.q4k.slice("), "define internal i64 @recipe.q4k.ints(", 1);
	format!("{head}%ints.dot = mul i32 %scale.code, %w3.dot.sum\n%ints.min = mul i32 %minimum, %w3.q8.sum\n%ints.dot.wide = sext i32 %ints.dot to i64\n%ints.dot.high = shl i64 %ints.dot.wide, 32\n%ints.min.wide = zext i32 %ints.min to i64\n%ints = or i64 %ints.dot.high, %ints.min.wide\nret i64 %ints\n}}\n")
}
/// The int partials of one four-value word of a Q6_K slice under a 256-value
/// step: the word's codes times its Q8 codes, times the slice's 8-bit scale
/// (high word), and the scale times the Q8 codes' sum (low word). llama.cpp's
/// Q6_K kernel keeps eight int lanes per block, lane l holding the words at
/// 4l..4l+4 of every 32-value group, less 32 times the scaled Q8 sums of
/// group l; each lane meets its own float accumulator once per block and the
/// eight accumulators add in a fixed tree at the end.
fn q6_part_helper(state: &str) -> String {
	if !int_state(state) {
		return "define internal i64 @recipe.q6k.part(ptr addrspace(1) %weights, i64 %offset, ptr addrspace(3) %q8, i32 %slice, i32 %word) #1 { entry: call void @llvm.trap() unreachable }\n".to_owned();
	}
	let full = amd_q6_slice_helper(state, true);
	let head = full.split("%dot.zero = add i32 0, 0").next().expect("the slice helper computes its prelude before its words");
	let head = head.replacen(&format!("define internal {state} @recipe.q6k.slice(ptr addrspace(1) %weights, i64 %offset, ptr addrspace(3) %q8, i32 %slice) #1 {{ entry:"), "define internal i64 @recipe.q6k.part(ptr addrspace(1) %weights, i64 %offset, ptr addrspace(3) %q8, i32 %slice, i32 %word) #1 { entry:", 1);
	format!("{head}%word.wide = zext i32 %word to i64\n%word.offset = mul i64 %word.wide, 4\n%p.ql.offset = add i64 %half.ql.base, %word.offset\n%p.ql.ptr = getelementptr i8, ptr addrspace(1) %block, i64 %p.ql.offset\n%p.ql = load i32, ptr addrspace(1) %p.ql.ptr, align 2\n%p.ql.shifted = lshr i32 %p.ql, %ql.shift\n%p.ql.codes = and i32 %p.ql.shifted, 252645135\n%p.qh.offset = add i64 %half.qh.base, %word.offset\n%p.qh.ptr = getelementptr i8, ptr addrspace(1) %block, i64 %p.qh.offset\n%p.qh = load i32, ptr addrspace(1) %p.qh.ptr, align 2\n%p.qh.shifted = lshr i32 %p.qh, %qh.shift\n%p.qh.codes = and i32 %p.qh.shifted, 50529027\n%p.qh.bits = shl i32 %p.qh.codes, 4\n%p.codes = or i32 %p.ql.codes, %p.qh.bits\n%p.q8.offset.base = add i64 %q8.half.offset, {q8_scale}\n%p.q8.offset = add i64 %p.q8.offset.base, %word.offset\n%p.q8.ptr = getelementptr i8, ptr addrspace(3) %q8.block, i64 %p.q8.offset\n%p.q8 = load i32, ptr addrspace(3) %p.q8.ptr, align 4\n%p.dot = call i32 @recipe.dot4.su(i32 %p.codes, i32 %p.q8)\n%p.sum = call i32 @recipe.dot4.su(i32 16843009, i32 %p.q8)\n%p.dot.scaled = mul i32 %scale, %p.dot\n%p.sum.scaled = mul i32 %scale, %p.sum\n%p.dot.wide = sext i32 %p.dot.scaled to i64\n%p.dot.high = shl i64 %p.dot.wide, 32\n%p.sum.wide = zext i32 %p.sum.scaled to i64\n%p.ints = or i64 %p.dot.high, %p.sum.wide\nret i64 %p.ints\n}}\n", q8_scale = q8_scale_bytes(state))
}
/// One 16-value Q6_K slice. Q6 scales are already 16 values wide, so the
/// slice index names the scale directly; the two adjacent slices share one
/// Q8_1 activation block.
fn amd_q6_slice_helper(state: &str, full: bool) -> String {
	if !full {
		return format!("define internal {state} @recipe.q6k.slice(ptr addrspace(1) %weights, i64 %offset, ptr addrspace(3) %q8, i32 %slice) #1 {{ entry: call void @llvm.trap() unreachable }}\n");
	}
	let mut ir = String::new();
	ir.push_str(&format!("define internal {state} @recipe.q6k.slice(ptr addrspace(1) %weights, i64 %offset, ptr addrspace(3) %q8, i32 %slice) #1 {{ entry:\n"));
	ir.push_str("%block = getelementptr i8, ptr addrspace(1) %weights, i64 %offset\n%d.ptr = getelementptr i8, ptr addrspace(1) %block, i64 208\n%d.bits = load half, ptr addrspace(1) %d.ptr, align 2\n%d = call ");
	ir.push_str(state);
	ir.push_str(" @recipe.state.from.f16(half %d.bits)\n%chunk = udiv i32 %slice, 8\n%group = udiv i32 %slice, 2\n%local = urem i32 %group, 4\n%half = and i32 %slice, 1\n%chunk.wide = zext i32 %chunk to i64\n%local.wide = zext i32 %local to i64\n%half.wide = zext i32 %half to i64\n%low.group = and i32 %local, 1\n%low.group.wide = zext i32 %low.group to i64\n%ql.extra = mul i64 %low.group.wide, 32\n%ql.base.part = mul i64 %chunk.wide, 64\n%ql.base = add i64 %ql.base.part, %ql.extra\n%qh.base.part = mul i64 %chunk.wide, 32\n%qh.base = add i64 %qh.base.part, 128\n%ql.shift.group = udiv i32 %local, 2\n%ql.shift = mul i32 %ql.shift.group, 4\n%qh.shift = mul i32 %local, 2\n%q8.group = zext i32 %group to i64\n");
	ir.push_str(&format!("%q8.offset = mul i64 %q8.group, {q8_record}\n%q8.block = getelementptr i8, ptr addrspace(3) %q8, i64 %q8.offset\n%q8.d.state = load {state}, ptr addrspace(3) %q8.block, align {q8_align}\n", q8_record = q8_record(state), q8_align = q8_scale_bytes(state)));
	ir.push_str("%scale.offset = add i32 %slice, 192\n%scale.offset.wide = zext i32 %scale.offset to i64\n%scale.ptr = getelementptr i8, ptr addrspace(1) %block, i64 %scale.offset.wide\n%scale.byte = load i8, ptr addrspace(1) %scale.ptr, align 1\n%scale = sext i8 %scale.byte to i32\n%scale.state = call ");
	ir.push_str(state);
	ir.push_str(" @recipe.state.from.s32(i32 %scale)\n%half.offset = mul i64 %half.wide, 16\n%half.ql.base = add i64 %ql.base, %half.offset\n%half.qh.base = add i64 %qh.base, %half.offset\n%q8.half.offset = mul i64 %half.wide, 16\n");
	let mut dot_sum = "%dot.zero".to_owned();
	let mut q8_sum = "%q8.zero".to_owned();
	ir.push_str("%dot.zero = add i32 0, 0\n%q8.zero = add i32 0, 0\n");
	for word in 0..4 {
		let q_offset = word * 4;
		let q8_offset = q8_scale_bytes(state) + word * 4;
		ir.push_str(&format!(
			"%w{word}.ql.offset = add i64 %half.ql.base, {q_offset}\n%w{word}.ql.ptr = getelementptr i8, ptr addrspace(1) %block, i64 %w{word}.ql.offset\n%w{word}.ql = load i32, ptr addrspace(1) %w{word}.ql.ptr, align 2\n%w{word}.ql.shifted = lshr i32 %w{word}.ql, %ql.shift\n%w{word}.ql.codes = and i32 %w{word}.ql.shifted, 252645135\n%w{word}.qh.offset = add i64 %half.qh.base, {q_offset}\n%w{word}.qh.ptr = getelementptr i8, ptr addrspace(1) %block, i64 %w{word}.qh.offset\n%w{word}.qh = load i32, ptr addrspace(1) %w{word}.qh.ptr, align 2\n%w{word}.qh.shifted = lshr i32 %w{word}.qh, %qh.shift\n%w{word}.qh.codes = and i32 %w{word}.qh.shifted, 50529027\n%w{word}.qh.bits = shl i32 %w{word}.qh.codes, 4\n%w{word}.codes = or i32 %w{word}.ql.codes, %w{word}.qh.bits\n%w{word}.q8.offset = add i64 %q8.half.offset, {q8_offset}\n%w{word}.q8.ptr = getelementptr i8, ptr addrspace(3) %q8.block, i64 %w{word}.q8.offset\n%w{word}.q8 = load i32, ptr addrspace(3) %w{word}.q8.ptr, align 4\n%w{word}.dot.raw = call i32 @recipe.dot4.su(i32 %w{word}.codes, i32 %w{word}.q8)\n%w{word}.sum.raw = call i32 @recipe.dot4.su(i32 16843009, i32 %w{word}.q8)\n",
			q_offset = q_offset,
			q8_offset = q8_offset,
		));
		let next_dot = format!("%w{word}.dot.sum");
		let next_q8 = format!("%w{word}.q8.sum");
		ir.push_str(&format!("{next_dot} = add i32 {dot_sum}, %w{word}.dot.raw\n{next_q8} = add i32 {q8_sum}, %w{word}.sum.raw\n", next_dot = next_dot, next_q8 = next_q8));
		dot_sum = next_dot;
		q8_sum = next_q8;
	}
	ir.push_str(&format!("%dot.offset = mul i32 {q8_sum}, 32\n%dot.signed = sub i32 {dot_sum}, %dot.offset\n%dot.value = call {state} @recipe.state.from.s32(i32 %dot.signed)\n%scaled = call {state} @recipe.state.mul({state} %scale.state, {state} %dot.value)\n%value = call {state} @recipe.state.mul({state} %q8.d.state, {state} %scaled)\n%result = call {state} @recipe.state.mul({state} %d, {state} %value)\nret {state} %result\n}}\n", state = state, dot_sum = dot_sum, q8_sum = q8_sum));
	ir
}
/// The exact block dots: one 16-value slice of a stored block against the
/// activations as they are, staged quad-interleaved in the local store in the
/// model type. Each code multiplies the activation in the state exactly, the
/// products add in the state, and the block's step scales the sum once, so
/// nothing about the activation is quantized: the only quantization is the
/// one the load kernel did. Written in the template's placeholders, they
/// serve every backend; a 32-lane wave takes the int8 helpers above instead.
fn block_dot_helpers() -> String {
	let mut ir = String::new();
	ir.push_str("define internal RECIPE_STATE @recipe.block32.fp32(i32 %kind, ptr addrspace(1) %weights, i64 %offset, ptr addrspace(3) %tile, i32 %column, i32 %pitch) #1 {\ncheck:\n%valid = icmp eq i32 %kind, 4\nbr i1 %valid, label %entry, label %invalid\ninvalid:\ncall void @llvm.trap()\nunreachable\nentry:\n%block = getelementptr i8, ptr addrspace(1) %weights, i64 %offset\n%d.bits = load half, ptr addrspace(1) %block, align 2\n%d = call RECIPE_STATE @recipe.state.from.f16(half %d.bits)\n%weight.codes = getelementptr i8, ptr addrspace(1) %block, i64 2\n%base = mul i32 %column, 32\n%zero = call RECIPE_STATE @recipe.state.from.u1(i1 false)\nbr label %loop\nloop:\n%i = phi i32 [ 0, %entry ], [ %next, %step ]\n%sum = phi RECIPE_STATE [ %zero, %entry ], [ %added, %step ]\n%more = icmp ult i32 %i, 32\nbr i1 %more, label %step, label %done\nstep:\n%c = add i32 %base, %i\n%within = and i32 %c, 15\n%quad = lshr i32 %within, 2\n%lane = and i32 %c, 3\n%group = lshr i32 %c, 4\n%row = mul i32 %quad, %pitch\n%group.offset = mul i32 %group, 4\n%row.group = add i32 %row, %group.offset\n%slot = add i32 %row.group, %lane\n%ap = getelementptr double, ptr addrspace(3) %tile, i32 %slot\n%a = load double, ptr addrspace(3) %ap, align 8\n%value = call RECIPE_STATE @recipe.decode(double %a)\n%wp = getelementptr i8, ptr addrspace(1) %weight.codes, i32 %i\n%w = load i8, ptr addrspace(1) %wp, align 1\n%wi = sext i8 %w to i32\n%weight = call RECIPE_STATE @recipe.state.from.s32(i32 %wi)\n%product = call RECIPE_STATE @recipe.state.mul(RECIPE_STATE %weight, RECIPE_STATE %value)\n%added = call RECIPE_STATE @recipe.state.add(RECIPE_STATE %sum, RECIPE_STATE %product)\n%next = add i32 %i, 1\nbr label %loop\ndone:\n%result = call RECIPE_STATE @recipe.state.mul(RECIPE_STATE %d, RECIPE_STATE %sum)\nret RECIPE_STATE %result\n}\n");
	ir.push_str("define internal RECIPE_STATE @recipe.block32.i16(i32 %kind, ptr addrspace(1) %weights, i64 %offset, ptr addrspace(3) %activation, i32 %slice) #1 {\ncheck:\n%valid = icmp eq i32 %kind, 4\nbr i1 %valid, label %entry, label %invalid\ninvalid:\ncall void @llvm.trap()\nunreachable\nentry:\n%block = getelementptr i8, ptr addrspace(1) %weights, i64 %offset\n%d.bits = load half, ptr addrspace(1) %block, align 2\n%d = call RECIPE_STATE @recipe.state.from.f16(half %d.bits)\n%s = load RECIPE_STATE, ptr addrspace(3) %activation, align RECIPE_STATE_ALIGN\n%codes = getelementptr i8, ptr addrspace(3) %activation, i64 RECIPE_STATE_ALIGN\n%weight.codes = getelementptr i8, ptr addrspace(1) %block, i64 2\nbr label %loop\nloop:\n%i = phi i32 [ 0, %entry ], [ %next, %step ]\n%sum = phi i32 [ 0, %entry ], [ %added, %step ]\n%more = icmp ult i32 %i, 32\nbr i1 %more, label %step, label %done\nstep:\n%wp = getelementptr i8, ptr addrspace(1) %weight.codes, i32 %i\n%w = load i8, ptr addrspace(1) %wp, align 1\n%ap = getelementptr i16, ptr addrspace(3) %codes, i32 %i\n%a = load i16, ptr addrspace(3) %ap, align 2\n%wi = sext i8 %w to i32\n%ai = sext i16 %a to i32\n%product = mul i32 %wi, %ai\n%added = add i32 %sum, %product\n%next = add i32 %i, 1\nbr label %loop\ndone:\n%integer = call RECIPE_STATE @recipe.state.from.s32(i32 %sum)\n%scaled = call RECIPE_STATE @recipe.state.mul(RECIPE_STATE %d, RECIPE_STATE %integer)\n%result = call RECIPE_STATE @recipe.state.mul(RECIPE_STATE %scaled, RECIPE_STATE %s)\nret RECIPE_STATE %result\n}\n");
	ir.push_str(&format!("@recipe_block32_iq4_levels = private unnamed_addr constant [16 x i8] [{}]\ndeclare i32 @llvm.fshr.i32(i32, i32, i32)\n", IQ4_LEVELS.iter().map(|level| format!("i8 {level}")).collect::<Vec<_>>().join(", ")));
	// The activations of one slice: sixteen model values, one per channel, at
	// the caller's stride, decoded into the state.
	let activations = |ir: &mut String| {
		// The column is staged quad-interleaved: channel c sits at
		// ((c % 16) / 4) * pitch + (c / 16) * 4 + c % 4, so a lane reads each
		// quad of its slice as one vector and the lanes of a wave, which take
		// adjacent columns, read adjacent vectors.
		ir.push_str("%column.quad = mul i32 %column, 4\n");
		for quad in 0..4 {
			ir.push_str(&format!("%xq{quad}.row = mul i32 %pitch, {quad}\n%xq{quad}.slot = add i32 %xq{quad}.row, %column.quad\n%xq{quad}.ptr = getelementptr inbounds double, ptr addrspace(3) %tile, i32 %xq{quad}.slot\n%xq{quad} = load <4 x double>, ptr addrspace(3) %xq{quad}.ptr, align 4\n"));
			for lane in 0..4 {
				let i = quad * 4 + lane;
				ir.push_str(&format!("%x{i}.model = extractelement <4 x double> %xq{quad}, i32 {lane}\n%x{i} = call RECIPE_STATE @recipe.decode(double %x{i}.model)\n"));
			}
		}
	};
	// Sixteen bytes from `base` in the block as four words; byte i is
	// %<name>i.raw. A block whose stride keeps `base` sixteen-aligned (Q4_K,
	// 144 bytes) reads them as one vector; the others are two-aligned.
	let words = |ir: &mut String, base: &str, name: &str, aligned: bool| {
		if aligned {
			ir.push_str(&format!("%{name}w.ptr = getelementptr i8, ptr addrspace(1) %block, i64 {base}\n%{name}w = load <4 x i32>, ptr addrspace(1) %{name}w.ptr, align 16\n"));
		}
		if !aligned {
			// A two-aligned slice: the two sixteen-byte lines that cover it, read
			// aligned, and each word funnel-shifted out of the pair (the weight
			// arena carries sixteen bytes of slack for the line past its end).
			ir.push_str(&format!("%{name}w.ptr = getelementptr i8, ptr addrspace(1) %block, i64 {base}\n%{name}w.addr = ptrtoint ptr addrspace(1) %{name}w.ptr to i64\n%{name}w.low = and i64 %{name}w.addr, 15\n%{name}w.line.addr = sub i64 %{name}w.addr, %{name}w.low\n%{name}w.line = inttoptr i64 %{name}w.line.addr to ptr addrspace(1)\n%{name}w.lo = load <4 x i32>, ptr addrspace(1) %{name}w.line, align 16\n%{name}w.next = getelementptr i8, ptr addrspace(1) %{name}w.line, i64 16\n%{name}w.hi = load <4 x i32>, ptr addrspace(1) %{name}w.next, align 16\n%{name}w.q = lshr i64 %{name}w.low, 2\n%{name}w.q32 = trunc i64 %{name}w.q to i32\n%{name}w.r64 = and i64 %{name}w.low, 3\n%{name}w.r32 = trunc i64 %{name}w.r64 to i32\n%{name}w.r = shl i32 %{name}w.r32, 3\n"));
			for word in 0..8 {
				let (vector, lane) = if word < 4 { ("lo", word) } else { ("hi", word - 4) };
				ir.push_str(&format!("%{name}in{word} = extractelement <4 x i32> %{name}w.{vector}, i32 {lane}\n"));
			}
			for q in 0..4 {
				ir.push_str(&format!("%{name}w.is{q} = icmp eq i32 %{name}w.q32, {q}\n"));
			}
			for word in 0..4 {
				// in[word + q] and in[word + q + 1] for the dynamic q in 0..4.
				for (part, extra) in [("a", 0), ("b", 1)] {
					let pick = |q: usize| format!("%{name}in{}", word + q + extra);
					ir.push_str(&format!(
						"%{name}w{word}.{part}.23 = select i1 %{name}w.is2, i32 {}, i32 {}\n%{name}w{word}.{part}.123 = select i1 %{name}w.is1, i32 {}, i32 %{name}w{word}.{part}.23\n%{name}w{word}.{part} = select i1 %{name}w.is0, i32 {}, i32 %{name}w{word}.{part}.123\n",
						pick(2), pick(3), pick(1), pick(0)
					));
				}
				ir.push_str(&format!("%{name}w{word} = call i32 @llvm.fshr.i32(i32 %{name}w{word}.b, i32 %{name}w{word}.a, i32 %{name}w.r)\n"));
			}
		}
		for word in 0..4 {
			if aligned {
				ir.push_str(&format!("%{name}w{word} = extractelement <4 x i32> %{name}w, i32 {word}\n"));
			}
			for byte in 0..4 {
				let i = word * 4 + byte;
				ir.push_str(&format!("%{name}{i}.byte.shift = lshr i32 %{name}w{word}, {}\n%{name}{i}.raw = and i32 %{name}{i}.byte.shift, 255\n", byte * 8));
			}
		}
	};
	// The running sums: code times activation, and the activation alone.
	// Four independent chains, one per quad, so the sums do not wait on each
	// other; they join at the end as %acc16 and %xsum16.
	let sums = |ir: &mut String, code: &dyn Fn(usize) -> String| {
		for quad in 0..4 {
			ir.push_str(&format!("%acc{quad}.0 = call RECIPE_STATE @recipe.state.from.u1(i1 false)\n%xsum{quad}.0 = call RECIPE_STATE @recipe.state.from.u1(i1 false)\n"));
		}
		for i in 0..16 {
			let (quad, step) = (i % 4, i / 4);
			ir.push_str(&format!("{}%code{i}.state = call RECIPE_STATE @recipe.state.from.s32(i32 %code{i})\n%acc{quad}.{} = call RECIPE_STATE @recipe.state.madd(RECIPE_STATE %acc{quad}.{step}, RECIPE_STATE %code{i}.state, RECIPE_STATE %x{i})\n%xsum{quad}.{} = call RECIPE_STATE @recipe.state.add(RECIPE_STATE %xsum{quad}.{step}, RECIPE_STATE %x{i})\n", code(i), step + 1, step + 1));
		}
		ir.push_str("%acc01 = call RECIPE_STATE @recipe.state.add(RECIPE_STATE %acc0.4, RECIPE_STATE %acc1.4)\n%acc23 = call RECIPE_STATE @recipe.state.add(RECIPE_STATE %acc2.4, RECIPE_STATE %acc3.4)\n%acc16 = call RECIPE_STATE @recipe.state.add(RECIPE_STATE %acc01, RECIPE_STATE %acc23)\n%xsum01 = call RECIPE_STATE @recipe.state.add(RECIPE_STATE %xsum0.4, RECIPE_STATE %xsum1.4)\n%xsum23 = call RECIPE_STATE @recipe.state.add(RECIPE_STATE %xsum2.4, RECIPE_STATE %xsum3.4)\n%xsum16 = call RECIPE_STATE @recipe.state.add(RECIPE_STATE %xsum01, RECIPE_STATE %xsum23)\n");
	};
	// Q4_K: 256 values in 144 bytes, d and dmin as fp16, eight 6-bit scale and
	// minimum pairs, then 128 nibble bytes; a slice is half of one 32-group.
	ir.push_str("define internal RECIPE_STATE @recipe.q4k.exact(ptr addrspace(1) %weights, i64 %offset, ptr addrspace(3) %tile, i32 %column, i32 %pitch, i32 %slice) #1 {\nentry:\n%block = getelementptr i8, ptr addrspace(1) %weights, i64 %offset\n%d.bits = load half, ptr addrspace(1) %block, align 2\n%d = call RECIPE_STATE @recipe.state.from.f16(half %d.bits)\n%dmin.ptr = getelementptr i8, ptr addrspace(1) %block, i64 2\n%dmin.bits = load half, ptr addrspace(1) %dmin.ptr, align 2\n%dmin = call RECIPE_STATE @recipe.state.from.f16(half %dmin.bits)\n%group = udiv i32 %slice, 2\n%group.wide = zext i32 %group to i64\n%half = and i32 %slice, 1\n%group.low = icmp ult i32 %group, 4\n%group.plus = add i32 %group, 4\n%group.minus = sub i32 %group, 4\n%scale.index = select i1 %group.low, i32 %group, i32 %group.plus\n%other.index = select i1 %group.low, i32 %group.plus, i32 %group.minus\n%scale.index.wide = zext i32 %scale.index to i64\n%other.index.wide = zext i32 %other.index to i64\n%scale.offset = add i64 4, %scale.index.wide\n%other.offset = add i64 4, %other.index.wide\n%scale.ptr = getelementptr i8, ptr addrspace(1) %block, i64 %scale.offset\n%scale.byte = load i8, ptr addrspace(1) %scale.ptr, align 1\n%other.ptr = getelementptr i8, ptr addrspace(1) %block, i64 %other.offset\n%other.byte = load i8, ptr addrspace(1) %other.ptr, align 1\n%scale.raw = zext i8 %scale.byte to i32\n%other.raw = zext i8 %other.byte to i32\n%scale.low = and i32 %scale.raw, 63\n%minimum.low = and i32 %other.raw, 63\n%scale.high.low = and i32 %scale.raw, 15\n%minimum.high.low = lshr i32 %scale.raw, 4\n%high.bits = and i32 %other.raw, 192\n%high = lshr i32 %high.bits, 2\n%scale.high = or i32 %scale.high.low, %high\n%minimum.high.offset = add i64 4, %group.wide\n%minimum.high.ptr = getelementptr i8, ptr addrspace(1) %block, i64 %minimum.high.offset\n%minimum.high.byte = load i8, ptr addrspace(1) %minimum.high.ptr, align 1\n%minimum.high.raw = zext i8 %minimum.high.byte to i32\n%minimum.high.bits = and i32 %minimum.high.raw, 192\n%minimum.high.top = lshr i32 %minimum.high.bits, 2\n%minimum.high = or i32 %minimum.high.low, %minimum.high.top\n%minimum = select i1 %group.low, i32 %minimum.low, i32 %minimum.high\n%scale.code = select i1 %group.low, i32 %scale.low, i32 %scale.high\n%scale.value = call RECIPE_STATE @recipe.state.from.u32(i32 %scale.code)\n%minimum.value = call RECIPE_STATE @recipe.state.from.u32(i32 %minimum)\n%group.d = call RECIPE_STATE @recipe.state.mul(RECIPE_STATE %d, RECIPE_STATE %scale.value)\n%group.dmin = call RECIPE_STATE @recipe.state.mul(RECIPE_STATE %dmin, RECIPE_STATE %minimum.value)\n%pair = udiv i32 %group, 2\n%pair.wide = zext i32 %pair to i64\n%q4.base.part = mul i64 %pair.wide, 32\n%q4.base = add i64 %q4.base.part, 16\n%group.shift = and i32 %group, 1\n%q4.shift = mul i32 %group.shift, 4\n%half.wide = zext i32 %half to i64\n%q4.half.offset = mul i64 %half.wide, 16\n%q4.base.half = add i64 %q4.base, %q4.half.offset\n");
	activations(&mut ir);
	words(&mut ir, "%q4.base.half", "q", true);
	sums(&mut ir, &|i| format!("%q{i}.shifted = lshr i32 %q{i}.raw, %q4.shift\n%code{i} = and i32 %q{i}.shifted, 15\n"));
	ir.push_str("%dot.scaled = call RECIPE_STATE @recipe.state.mul(RECIPE_STATE %group.d, RECIPE_STATE %acc16)\n%minimum.scaled = call RECIPE_STATE @recipe.state.mul(RECIPE_STATE %group.dmin, RECIPE_STATE %xsum16)\n%result = call RECIPE_STATE @recipe.state.sub(RECIPE_STATE %dot.scaled, RECIPE_STATE %minimum.scaled)\nret RECIPE_STATE %result\n}\n");
	// Q6_K: 256 values in 210 bytes, 128 low-nibble bytes, 64 high-pair bytes,
	// sixteen int8 scales one per 16 values, then d as fp16.
	ir.push_str("define internal RECIPE_STATE @recipe.q6k.exact(ptr addrspace(1) %weights, i64 %offset, ptr addrspace(3) %tile, i32 %column, i32 %pitch, i32 %slice) #1 {\nentry:\n%block = getelementptr i8, ptr addrspace(1) %weights, i64 %offset\n%d.ptr = getelementptr i8, ptr addrspace(1) %block, i64 208\n%d.bits = load half, ptr addrspace(1) %d.ptr, align 2\n%d = call RECIPE_STATE @recipe.state.from.f16(half %d.bits)\n%chunk = udiv i32 %slice, 8\n%group = udiv i32 %slice, 2\n%local = urem i32 %group, 4\n%half = and i32 %slice, 1\n%chunk.wide = zext i32 %chunk to i64\n%half.wide = zext i32 %half to i64\n%low.group = and i32 %local, 1\n%low.group.wide = zext i32 %low.group to i64\n%ql.extra = mul i64 %low.group.wide, 32\n%ql.base.part = mul i64 %chunk.wide, 64\n%ql.base = add i64 %ql.base.part, %ql.extra\n%qh.base.part = mul i64 %chunk.wide, 32\n%qh.base = add i64 %qh.base.part, 128\n%ql.shift.group = udiv i32 %local, 2\n%ql.shift = mul i32 %ql.shift.group, 4\n%qh.shift = mul i32 %local, 2\n%scale.offset = add i32 %slice, 192\n%scale.offset.wide = zext i32 %scale.offset to i64\n%scale.ptr = getelementptr i8, ptr addrspace(1) %block, i64 %scale.offset.wide\n%scale.byte = load i8, ptr addrspace(1) %scale.ptr, align 1\n%scale = sext i8 %scale.byte to i32\n%scale.state = call RECIPE_STATE @recipe.state.from.s32(i32 %scale)\n%half.offset = mul i64 %half.wide, 16\n%half.ql.base = add i64 %ql.base, %half.offset\n%half.qh.base = add i64 %qh.base, %half.offset\n");
	activations(&mut ir);
	words(&mut ir, "%half.ql.base", "ql", false);
	words(&mut ir, "%half.qh.base", "qh", false);
	sums(&mut ir, &|i| format!("%ql{i}.shifted = lshr i32 %ql{i}.raw, %ql.shift\n%ql{i}.code = and i32 %ql{i}.shifted, 15\n%qh{i}.shifted = lshr i32 %qh{i}.raw, %qh.shift\n%qh{i}.code = and i32 %qh{i}.shifted, 3\n%qh{i}.bits = shl i32 %qh{i}.code, 4\n%q{i}.joined = or i32 %ql{i}.code, %qh{i}.bits\n%code{i} = sub i32 %q{i}.joined, 32\n"));
	ir.push_str("%scaled = call RECIPE_STATE @recipe.state.mul(RECIPE_STATE %scale.state, RECIPE_STATE %acc16)\n%result = call RECIPE_STATE @recipe.state.mul(RECIPE_STATE %d, RECIPE_STATE %scaled)\nret RECIPE_STATE %result\n}\n");
	// The 32-value blocks: IQ4_NL (kind 1), Q4_0 (2), Q4_1 (3), Q8_0 (4): d as
	// fp16, Q4_1 a minimum after it, then the codes. Slice 0 takes the low
	// nibbles (or the first sixteen bytes), slice 1 the high ones.
	ir.push_str("define internal RECIPE_STATE @recipe.block32.exact(i32 %kind, ptr addrspace(1) %weights, i64 %offset, ptr addrspace(3) %tile, i32 %column, i32 %pitch, i32 %slice) #1 {\nentry:\n%block = getelementptr i8, ptr addrspace(1) %weights, i64 %offset\n%d.bits = load half, ptr addrspace(1) %block, align 2\n%d = call RECIPE_STATE @recipe.state.from.f16(half %d.bits)\n%is.iq4 = icmp eq i32 %kind, 1\n%is.q40 = icmp eq i32 %kind, 2\n%is.q41 = icmp eq i32 %kind, 3\n%is.q80 = icmp eq i32 %kind, 4\n%nibble.shift = mul i32 %slice, 4\n%half.wide = zext i32 %slice to i64\n%byte.half = mul i64 %half.wide, 16\n%data.q41 = select i1 %is.q41, i64 4, i64 2\n%data.base = select i1 %is.q80, i64 %byte.half, i64 0\n%data = add i64 %data.q41, %data.base\n%m.ptr = getelementptr i8, ptr addrspace(1) %block, i64 2\n%m.bits = load half, ptr addrspace(1) %m.ptr, align 2\n%m.loaded = call RECIPE_STATE @recipe.state.from.f16(half %m.bits)\n%zero = call RECIPE_STATE @recipe.state.from.u1(i1 false)\n%m = select i1 %is.q41, RECIPE_STATE %m.loaded, RECIPE_STATE %zero\n");
	activations(&mut ir);
	words(&mut ir, "%data", "b", false);
	sums(&mut ir, &|i| format!("%b{i}.shifted = lshr i32 %b{i}.raw, %nibble.shift\n%b{i}.nibble = and i32 %b{i}.shifted, 15\n%b{i}.nibble.wide = zext i32 %b{i}.nibble to i64\n%b{i}.level.ptr = getelementptr inbounds [16 x i8], ptr @recipe_block32_iq4_levels, i64 0, i64 %b{i}.nibble.wide\n%b{i}.level.byte = load i8, ptr %b{i}.level.ptr, align 1\n%b{i}.level = sext i8 %b{i}.level.byte to i32\n%b{i}.byte = trunc i32 %b{i}.raw to i8\n%b{i}.signed = sext i8 %b{i}.byte to i32\n%b{i}.q40 = sub i32 %b{i}.nibble, 8\n%b{i}.four = select i1 %is.q40, i32 %b{i}.q40, i32 %b{i}.nibble\n%b{i}.nibble.or.level = select i1 %is.iq4, i32 %b{i}.level, i32 %b{i}.four\n%code{i} = select i1 %is.q80, i32 %b{i}.signed, i32 %b{i}.nibble.or.level\n"));
	ir.push_str("%dot.scaled = call RECIPE_STATE @recipe.state.mul(RECIPE_STATE %d, RECIPE_STATE %acc16)\n%minimum.scaled = call RECIPE_STATE @recipe.state.mul(RECIPE_STATE %m, RECIPE_STATE %xsum16)\n%result = call RECIPE_STATE @recipe.state.add(RECIPE_STATE %dot.scaled, RECIPE_STATE %minimum.scaled)\nret RECIPE_STATE %result\n}\n");
	ir
}
fn parallel_ir(ir: String, width: &str, grid_barrier: &str) -> String {
	let mut ir = ir.replace("call i32 @llvm.amdgcn.workitem.id.x()", "call i32 @global_id()").replace("call void @llvm.amdgcn.s.barrier()", "call void @grid_barrier(i32 %threads)");
	let target = ir.find("target triple").and_then(|start| ir[start..].find('\n').map(|end| start + end + 1)).expect("kernel target triple is absent");
	ir.insert_str(target, &format!("{}\n", PARALLEL.replace("declare i32 @recipe.workgroup.size.x()", width).replace("@RECIPE_GRID_BARRIER@", grid_barrier)));
	ir.replace("recipe.local.id.x", "llvm.amdgcn.workitem.id.x").replace("recipe.group.id.x", "llvm.amdgcn.workgroup.id.x").replace("recipe.local.barrier", "llvm.amdgcn.s.barrier")
}
fn word(text: String, from: &str, to: &str) -> String {
	let (mut output, mut rest) = (String::with_capacity(text.len()), text.as_str());
	while let Some(index) = rest.find(from) {
		let end = index + from.len();
		let identifier = |value: char| value.is_ascii_alphanumeric() || value == '_' || value == '.';
		let bounded = rest[..index].chars().next_back().is_none_or(|value| !identifier(value)) && rest[end..].chars().next().is_none_or(|value| !identifier(value));
		output.push_str(&rest[..index]);
		output.push_str(if bounded { to } else { from });
		rest = &rest[end..];
	}
	output.push_str(rest);
	output
}
fn numeric_region(ir: &str) -> BuildResult<(usize, usize)> {
	let start = ir.find("; NUMERIC BEGIN").ok_or_else(|| io::Error::other("numeric operation block is absent"))?;
	let end = ir[start..].find("; NUMERIC END").map(|offset| start + offset + "; NUMERIC END".len()).ok_or_else(|| io::Error::other("numeric operation block is incomplete"))?;
	Ok((start, end))
}
/// The five transcendental entry points. They are defined by `shared_math`
/// rather than resolved against OCML, CUDA libdevice, or the host library, so
/// every backend evaluates the same coefficients in the same order.
const MATH_NAMES: [&str; 5] = ["recipe.math.exp", "recipe.math.tanh", "recipe.math.cos", "recipe.math.sin", "recipe.math.log"];

fn constant(value: f64) -> String {
	format!("0x{:016X}", value.to_bits())
}
fn math_literal(arithmetic: &str, value: f64) -> String {
	if arithmetic == "double" { constant(value) } else { constant(f64::from(value as f32)) }
}

/// Horner evaluation of `sum(coefficients[i] * variable^i)` as a chain of one
/// multiply and one add per term, innermost coefficient first.
fn horner(prefix: &str, variable: &str, coefficients: &[f64]) -> (String, String) {
	horner_typed(prefix, variable, coefficients, "double")
}

fn horner_typed(prefix: &str, variable: &str, coefficients: &[f64], arithmetic: &str) -> (String, String) {
	let mut ir = String::new();
	let intrinsic = if arithmetic == "double" { "f64" } else { "f32" };
	let mut current = math_literal(arithmetic, coefficients[coefficients.len() - 1]);
	for (step, coefficient) in coefficients.iter().rev().skip(1).enumerate() {
		ir.push_str(&format!(
			"%{prefix}.{step} = call {arithmetic} @llvm.fma.{intrinsic}({arithmetic} {current}, {arithmetic} {variable}, {arithmetic} {})\n",
			math_literal(arithmetic, *coefficient)
		));
		current = format!("%{prefix}.{step}");
	}
	(ir, current)
}

fn exponential_math(arithmetic: &str, name: &str, bias: i32, maximum: i32, shift: u8, high: f64, low: f64, terms: u32) -> String {
	let intrinsic = if arithmetic == "double" { "f64" } else { "f32" };
	let integer = if arithmetic == "double" { "i64" } else { "i32" };
	let stored = if arithmetic == "double" { "%stored = zext i32 %clamped to i64\n" } else { "%stored = add i32 %clamped, 0\n" };
	let infinity = math_literal(arithmetic, f64::INFINITY);
	let (polynomial, value) = horner_typed("exp.poly", "%r", &reciprocal_factorials(1, 1, terms), arithmetic);
	format!(
		"define internal {arithmetic} @{name}.pow2(i32 %k) #1 {{\nentry:\n%biased = add i32 %k, {bias}\n%low = icmp slt i32 %biased, 0\n%floor = select i1 %low, i32 0, i32 %biased\n%high = icmp sgt i32 %floor, {maximum}\n%clamped = select i1 %high, i32 {maximum}, i32 %floor\n{stored}%bits = shl {integer} %stored, {shift}\n%result = bitcast {integer} %bits to {arithmetic}\nret {arithmetic} %result\n}}\ndefine internal {arithmetic} @{name}.scale({arithmetic} %value, i32 %k) #1 {{\nentry:\n%half = ashr i32 %k, 1\n%rest = sub i32 %k, %half\n%first = call {arithmetic} @{name}.pow2(i32 %half)\n%second = call {arithmetic} @{name}.pow2(i32 %rest)\n%scaled = fmul {arithmetic} %value, %first\n%result = fmul {arithmetic} %scaled, %second\nret {arithmetic} %result\n}}\ndefine internal {arithmetic} @{name}({arithmetic} %x) #1 {{\nentry:\n%unordered = fcmp uno {arithmetic} %x, %x\nbr i1 %unordered, label %quiet, label %high.check\nquiet:\nret {arithmetic} %x\nhigh.check:\n%high = fcmp ogt {arithmetic} %x, {}\nbr i1 %high, label %overflow, label %low.check\noverflow:\nret {arithmetic} {infinity}\nlow.check:\n%low = fcmp olt {arithmetic} %x, {}\nbr i1 %low, label %underflow, label %reduce\nunderflow:\nret {arithmetic} 0.0\nreduce:\n%scaled = fmul {arithmetic} %x, {}\n%shifted = fadd {arithmetic} %scaled, {}\n%kf = call {arithmetic} @llvm.floor.{intrinsic}({arithmetic} %shifted)\n%k = fptosi {arithmetic} %kf to i32\n%upper = fmul {arithmetic} %kf, {}\n%partial = fsub {arithmetic} %x, %upper\n%lower = fmul {arithmetic} %kf, {}\n%r = fsub {arithmetic} %partial, %lower\n{polynomial}%body = fmul {arithmetic} %r, {value}\n%expanded = fadd {arithmetic} {}, %body\n%result = call {arithmetic} @{name}.scale({arithmetic} %expanded, i32 %k)\nret {arithmetic} %result\n}}\n",
		math_literal(arithmetic, high),
		math_literal(arithmetic, low),
		math_literal(arithmetic, std::f64::consts::LOG2_E),
		math_literal(arithmetic, 0.5),
		math_literal(arithmetic, f64::from_bits(0x3FE62E42FEE00000)),
		math_literal(arithmetic, 1.90821492927058770002e-10),
		math_literal(arithmetic, 1.0)
	)
}

/// Reciprocal factorials `1/(first!)`, `1/((first + step)!)`, ... up to `last`,
/// each the correctly rounded double of an exact ratio because every factorial
/// through 22! is itself exact in double.
fn reciprocal_factorials(first: u32, step: u32, last: u32) -> Vec<f64> {
	let (mut factorial, mut values) = (1.0_f64, Vec::new());
	for term in 1..=last {
		factorial *= f64::from(term);
		if term >= first && (term - first) % step == 0 {
			values.push(1.0 / factorial);
		}
	}
	values
}

/// The same terms with the alternating signs of a sine or cosine series, which
/// starts negative at the leading term of the polynomial in `r * r`.
fn alternating_factorials(first: u32, last: u32) -> Vec<f64> {
	reciprocal_factorials(first, 2, last).into_iter().enumerate().map(|(term, value)| if term % 2 == 0 { -value } else { value }).collect()
}

/// Deterministic implementations of the five transcendentals, evaluated in
/// double regardless of the arithmetic type. A backend library would be free to
/// choose its own range reduction, coefficients, and operation order, and two
/// backends that make different choices cannot produce the same bytes. Every
/// step below is an IEEE-754 operation with a single correctly rounded result,
/// so the sequence is fixed by the program.
///
/// Trigonometric argument reduction is the classic three-term Cody-Waite split,
/// which loses accuracy once the argument passes roughly 2^20. It loses the same
/// accuracy everywhere, which is what the byte-identity contract asks for.
fn shared_math(arithmetic: &str) -> String {
	let mut block = String::new();
	if arithmetic != "double" {
		block.push_str("declare double @llvm.floor.f64(double) declare double @llvm.fabs.f64(double) declare double @llvm.fma.f64(double, double, double)\n");
	}
	let infinity = constant(f64::INFINITY);
	let negative_infinity = constant(f64::NEG_INFINITY);
	let quiet = constant(f64::NAN);
	// Two half-exponents keep every intermediate normal, so no scale step rounds
	// through the subnormal range on the way to a normal answer.
	block.push_str(&exponential_math("double", "recipe.math.exp.wide", 1023, 2046, 52, 709.782712893383973096, -745.133219101941108420, 13));
	if arithmetic != "double" {
		block.push_str(&exponential_math(arithmetic, "recipe.math.exp.narrow", 127, 254, 23, 88.72283905206835, -103.972084045410, 8));
	}
	let (expm1, expm1_value) = horner("expm1.poly", "%x", &reciprocal_factorials(1, 1, 16));
	block.push_str(&format!("define internal double @recipe.math.expm1(double %x) #1 {{\nentry:\n%absolute = call double @llvm.fabs.f64(double %x)\n%small = fcmp olt double %absolute, {}\nbr i1 %small, label %series, label %general\nseries:\n{expm1}%result = fmul double %x, {expm1_value}\nret double %result\ngeneral:\n%value = call double @recipe.math.exp.wide(double %x)\n%shifted = fsub double %value, 1.0\nret double %shifted\n}}\n", constant(0.35)));
	// tanh(x) = u / (u + 2) for u = e^(2x) - 1. Neither the numerator nor the
	// denominator cancels, so small arguments keep their significance without a
	// separate polynomial branch.
	block.push_str(&format!("define internal double @recipe.math.tanh.wide(double %x) #1 {{\nentry:\n%unordered = fcmp uno double %x, %x\nbr i1 %unordered, label %quiet, label %range\nquiet:\nret double %x\nrange:\n%absolute = call double @llvm.fabs.f64(double %x)\n%saturated = fcmp oge double %absolute, {}\nbr i1 %saturated, label %unit, label %compute\nunit:\n%negative = fcmp olt double %x, 0.0\n%signed = select i1 %negative, double -1.0, double 1.0\nret double %signed\ncompute:\n%doubled = fmul double %x, 2.0\n%u = call double @recipe.math.expm1(double %doubled)\n%denominator = fadd double %u, 2.0\n%result = fdiv double %u, %denominator\nret double %result\n}}\n", constant(20.0)));
	let logarithm_terms = (0..12).map(|term| 1.0 / f64::from(2 * term + 1)).collect::<Vec<_>>();
	let (logarithm, logarithm_value) = horner("log.poly", "%z", &logarithm_terms);
	block.push_str(&format!("define internal double @recipe.math.log.wide(double %x) #1 {{\nentry:\n%unordered = fcmp uno double %x, %x\nbr i1 %unordered, label %quiet, label %sign.check\nquiet:\nret double %x\nsign.check:\n%negative = fcmp olt double %x, 0.0\nbr i1 %negative, label %invalid, label %zero.check\ninvalid:\nret double {quiet}\nzero.check:\n%zero = fcmp oeq double %x, 0.0\nbr i1 %zero, label %pole, label %infinite.check\npole:\nret double {negative_infinity}\ninfinite.check:\n%infinite = fcmp oeq double %x, {infinity}\nbr i1 %infinite, label %unbounded, label %normalize\nunbounded:\nret double {infinity}\nnormalize:\n%raw = bitcast double %x to i64\n%subnormal = icmp ult i64 %raw, 4503599627370496\n%boosted = fmul double %x, {}\n%source = select i1 %subnormal, double %boosted, double %x\n%correction = select i1 %subnormal, i32 -54, i32 0\n%bits = bitcast double %source to i64\n%field = lshr i64 %bits, 52\n%narrow = trunc i64 %field to i32\n%unbiased = sub i32 %narrow, 1023\n%exponent = add i32 %unbiased, %correction\n%fraction = and i64 %bits, 4503599627370495\n%unit = or i64 %fraction, 4607182418800017408\n%m = bitcast i64 %unit to double\n%large = fcmp ogt double %m, {}\n%halved = fmul double %m, 0.5\n%mantissa = select i1 %large, double %halved, double %m\n%bump = select i1 %large, i32 1, i32 0\n%e = add i32 %exponent, %bump\n%ef = sitofp i32 %e to double\n%numerator = fsub double %mantissa, 1.0\n%denominator = fadd double %mantissa, 1.0\n%s = fdiv double %numerator, %denominator\n%z = fmul double %s, %s\n{logarithm}%series = fmul double %s, {logarithm_value}\n%twice = fmul double %series, 2.0\n%upper = fmul double %ef, {}\n%lower = fmul double %ef, {}\n%tail = fadd double %twice, %lower\n%result = fadd double %upper, %tail\nret double %result\n}}\n",
		constant(f64::from_bits(0x4350000000000000)),
		constant(std::f64::consts::SQRT_2),
		constant(f64::from_bits(0x3FE62E42FEE00000)),
		constant(1.90821492927058770002e-10)));
	let (sine, sine_value) = horner("sin.poly", "%z", &alternating_factorials(3, 19));
	let (cosine, cosine_value) = horner("cos.poly", "%z", &alternating_factorials(2, 18));
	block.push_str(&format!("define internal double @recipe.math.trig(double %x, i32 %offset) #1 {{\nentry:\n%unordered = fcmp uno double %x, %x\n%absolute = call double @llvm.fabs.f64(double %x)\n%infinite = fcmp oeq double %absolute, {infinity}\n%invalid = or i1 %unordered, %infinite\nbr i1 %invalid, label %undefined, label %reduce\nundefined:\nret double {quiet}\nreduce:\n%scaled = fmul double %x, {}\n%shifted = fadd double %scaled, 0.5\n%kf = call double @llvm.floor.f64(double %shifted)\n%first = fmul double %kf, {}\n%partial = fsub double %x, %first\n%second = fmul double %kf, {}\n%closer = fsub double %partial, %second\n%third = fmul double %kf, {}\n%r = fsub double %closer, %third\n%quarter = fmul double %kf, 0.25\n%whole = call double @llvm.floor.f64(double %quarter)\n%rounds = fmul double %whole, 4.0\n%residue = fsub double %kf, %rounds\n%k = fptosi double %residue to i32\n%shift = add i32 %k, %offset\n%quadrant = and i32 %shift, 3\n%z = fmul double %r, %r\n{sine}%sin.body = fmul double %z, {sine_value}\n%sin.scaled = fmul double %r, %sin.body\n%sin = fadd double %r, %sin.scaled\n{cosine}%cos.body = fmul double %z, {cosine_value}\n%cos = fadd double 1.0, %cos.body\n%parity = and i32 %quadrant, 1\n%cosine = icmp eq i32 %parity, 1\n%magnitude = select i1 %cosine, double %cos, double %sin\n%upper = icmp uge i32 %quadrant, 2\n%negated = fneg double %magnitude\n%result = select i1 %upper, double %negated, double %magnitude\nret double %result\n}}\n",
		constant(std::f64::consts::FRAC_2_PI),
		constant(f64::from_bits(0x3FF921FB54400000)),
		constant(f64::from_bits(0x3DD0B4611A600000)),
		constant(f64::from_bits(0x3BA3198A2E000000))));
	block.push_str("define internal double @recipe.math.sin.wide(double %x) #1 { entry: %result = call double @recipe.math.trig(double %x, i32 0) ret double %result }\ndefine internal double @recipe.math.cos.wide(double %x) #1 { entry: %result = call double @recipe.math.trig(double %x, i32 1) ret double %result }\n");
	for name in MATH_NAMES {
		let wide = format!("{name}.wide");
		if arithmetic == "double" {
			block.push_str(&format!("define internal double @{name}(double %value) #1 {{ entry: %result = call double @{wide}(double %value) ret double %result }}\n"));
		} else if name == "recipe.math.exp" {
			block.push_str(&format!(
				"define internal {arithmetic} @{name}({arithmetic} %value) #1 {{ entry: %result = call {arithmetic} @recipe.math.exp.narrow({arithmetic} %value) ret {arithmetic} %result }}\n"
			));
		} else {
			// Evaluating in double and rounding once is both deterministic and at
			// least as accurate as a native narrow evaluation would be.
			block.push_str(&format!("define internal {arithmetic} @{name}({arithmetic} %value) #1 {{ entry: %wide = fpext {arithmetic} %value to double %computed = call double @{wide}(double %wide) %result = fptrunc double %computed to {arithmetic} ret {arithmetic} %result }}\n"));
		}
	}
	block
}
fn native_codec(ty: &str, rounded: bool) -> String {
	let round = if rounded {
		"define internal float @recipe.round(float %value) #1 { entry: %bits = bitcast float %value to i32 %absolute = and i32 %bits, 2147483647 %special = icmp uge i32 %absolute, 2139095040 %shifted = lshr i32 %bits, 13 %least = and i32 %shifted, 1 %bias = add i32 4095, %least %biased = add i32 %bits, %bias %masked = and i32 %biased, -8192 %encoded = select i1 %special, i32 %bits, i32 %masked %result = bitcast i32 %encoded to float ret float %result }\n"
	} else {
		""
	};
	let conversion = if rounded { format!("%result = call {ty} @recipe.round({ty} %value)") } else { format!("ret {ty} %value") };
	let returned = if rounded { format!("ret {ty} %result") } else { String::new() };
	format!(
		"{round}define internal {ty} @recipe.decode({ty} %value) #1 {{ entry: {conversion} {returned} }}\ndefine internal {ty} @recipe.encode({ty} %value) #1 {{ entry: {conversion} {returned} }}\n"
	)
}

fn numeric_operations(prefix: &str, value: &str, arithmetic: &str, encoded: bool, vector: Option<bool>) -> String {
	let intrinsic = if arithmetic == "double" { "f64" } else { "f32" };
	let math = MATH_NAMES;
	let mut block = String::new();
	for (name, operation) in [("add", "fadd"), ("sub", "fsub"), ("mul", "fmul"), ("div", "fdiv")] {
		if encoded {
			block.push_str(&format!("define internal {value} @{prefix}.{name}({value} %left, {value} %right) #1 {{ entry: %left.wide = call {arithmetic} @recipe.decode({value} %left) %right.wide = call {arithmetic} @recipe.decode({value} %right) %wide = {operation} {arithmetic} %left.wide, %right.wide %result = call {value} @recipe.encode({arithmetic} %wide) ret {value} %result }}\n"))
		} else {
			block.push_str(&format!("define internal {value} @{prefix}.{name}({value} %left, {value} %right) #1 {{ entry: %result = {operation} {value} %left, %right ret {value} %result }}\n"))
		}
	}
	if encoded {
		block.push_str(&format!("define internal {value} @{prefix}.madd({value} %sum, {value} %left, {value} %right) #1 {{ entry: %sum.wide = call {arithmetic} @recipe.decode({value} %sum) %left.wide = call {arithmetic} @recipe.decode({value} %left) %right.wide = call {arithmetic} @recipe.decode({value} %right) %wide = call {arithmetic} @llvm.fma.{intrinsic}({arithmetic} %left.wide, {arithmetic} %right.wide, {arithmetic} %sum.wide) %result = call {value} @recipe.encode({arithmetic} %wide) ret {value} %result }}\n"));
	} else {
		block.push_str(&format!("define internal {value} @{prefix}.madd({value} %sum, {value} %left, {value} %right) #1 {{ entry: %result = call {value} @llvm.fma.{intrinsic}({value} %left, {value} %right, {value} %sum) ret {value} %result }}\n"));
	}
	if let Some(declare) = vector {
		if let Some(intrinsic) = match value {
			"half" => Some("f16"),
			"float" => Some("f32"),
			"double" => Some("f64"),
			_ => None,
		} {
			// The state family reuses the model family's intrinsic when both name the
			// same type, so the declaration is emitted once.
			if declare {
				block.push_str(&format!(
					"declare <RECIPE_REGISTER_M x {value}> @llvm.fma.vRECIPE_REGISTER_M{intrinsic}(<RECIPE_REGISTER_M x {value}>, <RECIPE_REGISTER_M x {value}>, <RECIPE_REGISTER_M x {value}>)\n"
				));
			}
			block.push_str(&format!("define internal <RECIPE_REGISTER_M x {value}> @{prefix}.madd.vector(<RECIPE_REGISTER_M x {value}> %sum, <RECIPE_REGISTER_M x {value}> %left, <RECIPE_REGISTER_M x {value}> %right) #1 {{\nentry:\n%result = call <RECIPE_REGISTER_M x {value}> @llvm.fma.vRECIPE_REGISTER_M{intrinsic}(<RECIPE_REGISTER_M x {value}> %left, <RECIPE_REGISTER_M x {value}> %right, <RECIPE_REGISTER_M x {value}> %sum)\nret <RECIPE_REGISTER_M x {value}> %result\n}}\n"));
		} else {
			block.push_str(&format!("define internal <RECIPE_REGISTER_M x {value}> @{prefix}.madd.vector(<RECIPE_REGISTER_M x {value}> %sum, <RECIPE_REGISTER_M x {value}> %left, <RECIPE_REGISTER_M x {value}> %right) #1 {{\nentry:\nbr label %loop\nloop:\n%p = phi i32 [ 0, %entry ], [ %p.next, %step ]\n%result = phi <RECIPE_REGISTER_M x {value}> [ poison, %entry ], [ %next, %step ]\n%more = icmp ult i32 %p, RECIPE_REGISTER_M\nbr i1 %more, label %step, label %done\nstep:\n%sum.value = extractelement <RECIPE_REGISTER_M x {value}> %sum, i32 %p\n%left.value = extractelement <RECIPE_REGISTER_M x {value}> %left, i32 %p\n%right.value = extractelement <RECIPE_REGISTER_M x {value}> %right, i32 %p\n%value = call {value} @{prefix}.madd({value} %sum.value, {value} %left.value, {value} %right.value)\n%next = insertelement <RECIPE_REGISTER_M x {value}> %result, {value} %value, i32 %p\n%p.next = add i32 %p, 1\nbr label %loop\ndone:\nret <RECIPE_REGISTER_M x {value}> %result\n}}\n"));
		}
	}
	if encoded {
		block.push_str(&format!("define internal {value} @{prefix}.neg({value} %value) #1 {{ entry: %wide = call {arithmetic} @recipe.decode({value} %value) %negative = fneg {arithmetic} %wide %result = call {value} @recipe.encode({arithmetic} %negative) ret {value} %result }}\n"));
	} else {
		block.push_str(&format!("define internal {value} @{prefix}.neg({value} %value) #1 {{ entry: %result = fneg {value} %value ret {value} %result }}\n"));
	}
	for predicate in ["oeq", "oge", "ogt", "ole", "olt", "one", "ord"] {
		if encoded {
			block.push_str(&format!("define internal i1 @{prefix}.{predicate}({value} %left, {value} %right) #1 {{ entry: %left.wide = call {arithmetic} @recipe.decode({value} %left) %right.wide = call {arithmetic} @recipe.decode({value} %right) %result = fcmp {predicate} {arithmetic} %left.wide, %right.wide ret i1 %result }}\n"))
		} else {
			block.push_str(&format!("define internal i1 @{prefix}.{predicate}({value} %left, {value} %right) #1 {{ entry: %result = fcmp {predicate} {value} %left, %right ret i1 %result }}\n"))
		}
	}
	for (name, operation) in [("from.u1", "uitofp i1"), ("from.u32", "uitofp i32"), ("from.s32", "sitofp i32")] {
		let source = if name == "from.u1" { "i1" } else { "i32" };
		if encoded {
			block.push_str(&format!("define internal {value} @{prefix}.{name}({source} %value) #1 {{ entry: %wide = {operation} %value to {arithmetic} %result = call {value} @recipe.encode({arithmetic} %wide) ret {value} %result }}\n"))
		} else {
			block.push_str(&format!("define internal {value} @{prefix}.{name}({source} %value) #1 {{ entry: %result = {operation} %value to {value} ret {value} %result }}\n"))
		}
	}
	for (name, operation) in [("to.u32", "fptoui"), ("to.s32", "fptosi")] {
		if encoded {
			block.push_str(&format!(
				"define internal i32 @{prefix}.{name}({value} %value) #1 {{ entry: %wide = call {arithmetic} @recipe.decode({value} %value) %result = {operation} {arithmetic} %wide to i32 ret i32 %result }}\n"
			))
		} else {
			block.push_str(&format!("define internal i32 @{prefix}.{name}({value} %value) #1 {{ entry: %result = {operation} {value} %value to i32 ret i32 %result }}\n"))
		}
	}
	let from_f32 = if arithmetic == "double" { format!("%wide = fpext float %value to double") } else { format!("%wide = fadd float %value, 0.0") };
	let from_f16 = format!("%wide = fpext half %value to {arithmetic}");
	let to_f16 = format!("%result = fptrunc {arithmetic} %wide to half");
	for (name, source, conversion) in [("from.f32", "float", from_f32), ("from.f16", "half", from_f16)] {
		if encoded {
			block.push_str(&format!(
				"define internal {value} @{prefix}.{name}({source} %value) #1 {{ entry: {conversion} %result = call {value} @recipe.encode({arithmetic} %wide) ret {value} %result }}\n"
			))
		} else {
			block.push_str(&format!("define internal {value} @{prefix}.{name}({source} %value) #1 {{ entry: {conversion} ret {value} %wide }}\n"))
		}
	}
	if encoded {
		block.push_str(&format!("define internal half @{prefix}.to.f16({value} %value) #1 {{ entry: %wide = call {arithmetic} @recipe.decode({value} %value) {to_f16} ret half %result }}\n"));
	} else {
		block.push_str(&format!("define internal half @{prefix}.to.f16({value} %value) #1 {{ entry: %wide = fadd {value} %value, 0.0 {to_f16} ret half %result }}\n"));
	}
	let to_f32 = if arithmetic == "double" { "%result = fptrunc double %wide to float" } else { "%result = fadd float %wide, 0.0" };
	if encoded {
		block.push_str(&format!("define internal float @{prefix}.to.f32({value} %value) #1 {{ entry: %wide = call {arithmetic} @recipe.decode({value} %value) {to_f32} ret float %result }}\n"));
	} else {
		block.push_str(&format!("define internal float @{prefix}.to.f32({value} %value) #1 {{ entry: %wide = fadd {value} %value, 0.0 {to_f32} ret float %result }}\n"));
	}
	for (name, symbol) in [
		("abs", format!("llvm.fabs.{intrinsic}")),
		("floor", format!("llvm.floor.{intrinsic}")),
		("roundeven", format!("llvm.roundeven.{intrinsic}")),
		("sqrt", format!("llvm.sqrt.{intrinsic}")),
		("exp", math[0].to_owned()),
		("tanh", math[1].to_owned()),
		("cos", math[2].to_owned()),
		("sin", math[3].to_owned()),
		("log", math[4].to_owned()),
	] {
		if encoded {
			block.push_str(&format!("define internal {value} @{prefix}.{name}({value} %value) #1 {{ entry: %wide = call {arithmetic} @recipe.decode({value} %value) %computed = call {arithmetic} @{symbol}({arithmetic} %wide) %result = call {value} @recipe.encode({arithmetic} %computed) ret {value} %result }}\n"))
		} else {
			block.push_str(&format!("define internal {value} @{prefix}.{name}({value} %value) #1 {{ entry: %result = call {value} @{symbol}({value} %value) ret {value} %result }}\n"))
		}
	}
	block.push_str(&format!("define internal {value} @{prefix}.sigmoid({value} %value) #1 {{ entry: %negative = call {value} @{prefix}.neg({value} %value) %exponential = call {value} @{prefix}.exp({value} %negative) %one = call {value} @{prefix}.from.u1(i1 true) %denominator = call {value} @{prefix}.add({value} %exponential, {value} %one) %result = call {value} @{prefix}.div({value} %one, {value} %denominator) ret {value} %result }}\n"));
	block
}

fn numeric_program(value: &str, arithmetic: &str, codec: &str) -> String {
	let intrinsic = if arithmetic == "double" { "f64" } else { "f32" };
	let mut block = if codec.starts_with("; NUMERIC BEGIN") {
		format!("{codec}\n")
	} else {
		format!(
			"; NUMERIC BEGIN\ndeclare {arithmetic} @llvm.sqrt.{intrinsic}({arithmetic}) declare {arithmetic} @llvm.fabs.{intrinsic}({arithmetic}) declare {arithmetic} @llvm.floor.{intrinsic}({arithmetic}) declare {arithmetic} @llvm.roundeven.{intrinsic}({arithmetic})\n{codec}\n"
		)
	};
	block.push_str(&format!("\ndeclare {arithmetic} @llvm.fma.{intrinsic}({arithmetic}, {arithmetic}, {arithmetic})\n"));
	block.push_str(&shared_math(arithmetic));
	block.push_str(&numeric_operations("recipe", value, arithmetic, true, Some(true)));
	// No floating-point atomic is emitted. Every reduction names its own owner and
	// a fixed order, so a read-modify-write race has nowhere left to happen.
	if !codec.contains("@recipe.set.format") {
		block.push_str("define internal void @recipe.set.format(i32 %exp, i32 %man) #1 { entry: ret void }\n")
	}
	block.push_str(&numeric_operations("recipe.state", arithmetic, arithmetic, false, Some(value != arithmetic)));
	block.push_str(&format!("define internal {arithmetic} @recipe.state.from.model({value} %value) #1 {{ entry: %result = call {arithmetic} @recipe.decode({value} %value) ret {arithmetic} %result }}\ndefine internal {value} @recipe.model.from.state({arithmetic} %value) #1 {{ entry: %result = call {value} @recipe.encode({arithmetic} %value) ret {value} %result }}\n; NUMERIC END"));
	block
}

/// A float-state codec lifted to a double state: the model value decodes
/// through the float decoder and widens, and a double result narrows to float
/// before the float encoder stores it. The store rounds through float, so a
/// tie that double would round differently is the one place an acc64 block
/// differs from a block whose whole arithmetic is double.
/// A double rounded once to a narrow float of `exp` exponent bits and `man`
/// mantissa bits, as the LLVM type `llvm` (an integer of the format's width,
/// or half / float for the native ones): round to nearest even from the
/// double's own bits, a subnormal result kept, NaN quiet, and past the largest
/// finite value the largest finite value when `saturate`, else infinity.
fn double_encoder(name: &str, llvm: &str, exp: u32, man: u32, saturate: bool) -> String {
	let bias = (1i64 << (exp - 1)) - 1;
	let finite_e4m3 = llvm == "i8" && exp == 4 && man == 3;
	let top = (1i64 << exp) - i64::from(!finite_e4m3);
	let width = exp + man + 1;
	let integer = format!("i{width}");
	let quiet = if finite_e4m3 { 127 } else { (top << man) | (1i64 << (man - 1)) };
	let infinity = if finite_e4m3 { 127 } else { top << man };
	let largest = if finite_e4m3 { 126 } else { (top - 1) << man | ((1i64 << man) - 1) };
	let overflow = if saturate || finite_e4m3 { largest } else { infinity };
	let sign_shift = 63 - (width as i64 - 1);
	let to_llvm = if llvm == integer { "%result = add {integer} %packed, 0".replace("{integer}", &integer) } else { format!("%result = bitcast {integer} %packed to {llvm}") };
	format!(
		"define internal {llvm} @{name}(double %value) #1 {{
entry:
%bits = bitcast double %value to i64
%sign.wide = lshr i64 %bits, {sign_shift}
%sign = and i64 %sign.wide, {sign_bit}
%absolute = and i64 %bits, 9223372036854775807
%exponent.field = lshr i64 %absolute, 52
%mantissa = and i64 %absolute, 4503599627370495
%nan = icmp ugt i64 %absolute, 9218868437227405312
br i1 %nan, label %quiet, label %finite.check
quiet:
%quiet.bits = or i64 %sign, {quiet}
br label %pack
finite.check:
%unbiased = sub i64 %exponent.field, 1023
%target = add i64 %unbiased, {bias}
%too.large = icmp sge i64 %target, {top}
br i1 %too.large, label %over, label %range
over:
%over.bits = or i64 %sign, {overflow}
br label %pack
range:
%normal = icmp sge i64 %target, 1
br i1 %normal, label %round.normal, label %round.small
round.normal:
%keep = lshr i64 %mantissa, {drop}
%rest = and i64 %mantissa, {rest_mask}
%rest.above = icmp ugt i64 %rest, {half}
%rest.tie = icmp eq i64 %rest, {half}
%keep.odd = trunc i64 %keep to i1
%tie.up = and i1 %rest.tie, %keep.odd
%up = or i1 %rest.above, %tie.up
%up.wide = zext i1 %up to i64
%rounded = add i64 %keep, %up.wide
%exponent.bits = shl i64 %target, {man}
%normal.bits.raw = add i64 %exponent.bits, %rounded
%normal.over = icmp sge i64 %normal.bits.raw, {infinity}
%normal.bits.kept = select i1 %normal.over, i64 {overflow}, i64 %normal.bits.raw
%normal.bits = or i64 %sign, %normal.bits.kept
br label %pack
round.small:
%full = or i64 %mantissa, 4503599627370496
%below = sub i64 1, %target
%shift.raw = add i64 %below, {drop}
%shift.far = icmp ugt i64 %shift.raw, 62
%shift = select i1 %shift.far, i64 62, i64 %shift.raw
%small.keep = lshr i64 %full, %shift
%shift.less = sub i64 %shift, 1
%small.half = shl i64 1, %shift.less
%small.mask = sub i64 %small.half, 1
%small.rest.mask = or i64 %small.mask, %small.half
%small.rest = and i64 %full, %small.rest.mask
%small.above = icmp ugt i64 %small.rest, %small.half
%small.tie = icmp eq i64 %small.rest, %small.half
%small.odd = trunc i64 %small.keep to i1
%small.tie.up = and i1 %small.tie, %small.odd
%small.up = or i1 %small.above, %small.tie.up
%small.up.wide = zext i1 %small.up to i64
%small.rounded = add i64 %small.keep, %small.up.wide
%small.bits = or i64 %sign, %small.rounded
br label %pack
pack:
%packed.wide = phi i64 [ %quiet.bits, %quiet ], [ %over.bits, %over ], [ %normal.bits, %round.normal ], [ %small.bits, %round.small ]
%packed = trunc i64 %packed.wide to {integer}
{to_llvm}
ret {llvm} %result
}}
",
		sign_bit = 1i64 << (width - 1),
		drop = 52 - man,
		rest_mask = (1i64 << (52 - man)) - 1,
		half = 1i64 << (52 - man - 1),
	)
}
/// An integer codec's double side: round to nearest even, clamp, NaN to zero.
fn int_double_encoder(name: &str, format: IntFormat) -> String {
	let minimum = -(1i64 << (format.bits - 1));
	let maximum = (1i64 << (format.bits - 1)) - 1;
	let mask = (1u64 << format.bits) - 1;
	format!("define internal i8 @{name}(double %value) #1 {{ entry: %nan = fcmp uno double %value, %value %rounded = call double @llvm.roundeven.f64(double %value) %below = fcmp olt double %rounded, {minimum}.0 %above = fcmp ogt double %rounded, {maximum}.0 %lowered = select i1 %below, double {minimum}.0, double %rounded %clamped = select i1 %above, double {maximum}.0, double %lowered %finite = select i1 %nan, double 0.0, double %clamped %wide = fptosi double %finite to i32 %masked = and i32 %wide, {mask} %result = trunc i32 %masked to i8 ret i8 %result }}
")
}
/// The double side of a model codec: what a double state rounds to on the
/// way into the model type. A float model truncates once; every narrower
/// model rounds once from the double's own bits.
fn double_side(llvm: &str, value: &str) -> String {
	match value {
		"float" => "define internal float @recipe.encode(double %value) #1 { entry: %result = fptrunc double %value to float ret float %result }
".to_owned(),
		"half" => double_encoder("recipe.encode", "half", 5, 10, true),
		"i16" => double_encoder("recipe.encode", "i16", 8, 7, false),
		"i8" if llvm == "fp8" => double_encoder("recipe.encode", "i8", 4, 3, true),
		"i8" if llvm == "fp8e5m2" => fp8_encoder("recipe.encode", FloatFormat::FP8_E5M2),
		"i8" if llvm == "int8" => int_double_encoder("recipe.encode", IntFormat::INT8),
		"i8" if llvm == "int4" => int_double_encoder("recipe.encode", IntFormat::INT4),
		_ => panic!("no double side for the {llvm} codec of {value}"),
	}
}
fn widen_codec_as(codec: &str, value: &str, kind: &str) -> String {
	let narrow = codec.replace("@recipe.decode(", "@recipe.decode.narrow(").replace("@recipe.encode(", "@recipe.encode.narrow(");
	if kind != "tf32" {
		return format!("{narrow}
define internal double @recipe.decode({value} %value) #1 {{ entry: %narrow = call float @recipe.decode.narrow({value} %value) %result = fpext float %narrow to double ret double %result }}
{}", double_side(kind, value));
	}
	format!(
		"{narrow}\ndefine internal double @recipe.decode({value} %value) #1 {{ entry: %narrow = call float @recipe.decode.narrow({value} %value) %result = fpext float %narrow to double ret double %result }}\ndefine internal {value} @recipe.encode(double %value) #1 {{ entry: %narrow = fptrunc double %value to float %result = call {value} @recipe.encode.narrow(float %narrow) ret {value} %result }}\n"
	)
}
/// The suffix of the state-widened sibling of a float-state template.
const ACC64: &str = "-acc64";
fn state_align(state: &str) -> String {
	if state == "double" { "8".to_owned() } else { "4".to_owned() }
}
fn native_ir(ir: String, suffix: &str, llvm: &str, format: FloatFormat, state: &str) -> BuildResult<String> {
	let (start, end) = numeric_region(&ir)?;
	let bits = format.storage.bits();
	let codec = native_codec(llvm, format == FloatFormat::TF32);
	let codec = if state == llvm { codec } else { widen_codec_as(&codec, llvm, if format == FloatFormat::TF32 { "tf32" } else { "float" }) };
	let numeric = numeric_program(llvm, state, &codec);
	let mut kernel = format!("{}@RECIPE_NUMERIC@{}", &ir[..start], &ir[end..]);
	kernel = word(kernel, "double", llvm).replace("@contraction_tile", &format!("@contraction_tile{suffix}")).replace("align 8", &format!("align {}", bits / 8));
	// With the state at the model type the widening accumulator folds away;
	// an acc64 sibling keeps a double state over the same model type.
	let state_align = if state == llvm { (bits / 8).to_string() } else { state_align(state) };
	kernel = kernel.replace("RECIPE_MODEL_BYTES", &(bits / 8).to_string()).replace("RECIPE_STATE_ALIGN", &state_align).replace("RECIPE_STATE", state);
	if bits < 64 {
		let literal = |value: f64| match llvm {
			"half" => format!("0xH{:04X}", format.pack(value)),
			"bfloat" => format!("0xR{:04X}", format.pack(value)),
			_ => format!("0x{:016X}", format.unpack(format.pack(value)).to_bits()),
		};
		kernel = kernel
			.replace(&format!("{llvm} 0.1"), &format!("{llvm} {}", literal(0.1)))
			.replace("0x3CB0000000000000", &literal(f64::from_bits(0x3CB0000000000000)))
			.replace("0x3FEFFFFFFFFFFFFE", &literal(f64::from_bits(0x3FEFFFFFFFFFFFFE)))
	}
	Ok(kernel.replace("@RECIPE_NUMERIC@", &numeric))
}
fn fp8_encoder(name: &str, format: FloatFormat) -> String {
	let mut ir = double_encoder(name, "i8", format.arithmetic.exp.into(), format.arithmetic.man.into(), true);
	if format == FloatFormat::FP8_E5M2 {
		// Preserve infinities, but saturate finite overflow consistently with the host.
		ir = ir.replace("%over.bits = or i64 %sign, 123", "%input.infinity = icmp eq i64 %absolute, 9218868437227405312\n%over.magnitude = select i1 %input.infinity, i64 124, i64 123\n%over.bits = or i64 %sign, %over.magnitude");
	}
	ir
}
fn fp8_codec(format: FloatFormat) -> String {
	let (man, exp) = (format.arithmetic.man, format.arithmetic.exp);
	let bias = (1u32 << (exp - 1)) - 1;
	let special = if format == FloatFormat::FP8 {
		"%special = icmp eq i32 %magnitude, 127\n%special.bits = or i32 %float.sign, 2143289344".to_owned()
	} else {
		"%special = icmp uge i32 %magnitude, 124\n%special.base = or i32 %float.sign, 2139095040\n%special.bits = or i32 %special.base, %float.mantissa".to_owned()
	};
	let subnormal = f64::from(2.0_f32.powi(1 - bias as i32 - man as i32)).to_bits();
	format!("define internal float @recipe.decode(i8 %value) #3 {{
entry:
%wide = zext i8 %value to i32
%magnitude = and i32 %wide, 127
%sign = and i32 %wide, 128
%float.sign = shl i32 %sign, 24
%exponent = lshr i32 %magnitude, {man}
%mantissa = and i32 %wide, {mask}
%float.mantissa = shl i32 %mantissa, {shift}
%zero.exponent = icmp eq i32 %exponent, 0
br i1 %zero.exponent, label %subnormal, label %normal
subnormal:
%mantissa.float = uitofp i32 %mantissa to float
%scaled = fmul float %mantissa.float, 0x{subnormal:016X}
%sub.bits = bitcast float %scaled to i32
%sub.signed = or i32 %sub.bits, %float.sign
%sub.value = bitcast i32 %sub.signed to float
ret float %sub.value
normal:
%biased = add i32 %exponent, {offset}
%exponent.bits = shl i32 %biased, 23
%normal.base = or i32 %float.sign, %exponent.bits
%normal.bits = or i32 %normal.base, %float.mantissa
{special}
%bits = select i1 %special, i32 %special.bits, i32 %normal.bits
%result = bitcast i32 %bits to float
ret float %result
}}
{}
define internal i8 @recipe.encode(float %value) #3 {{ entry:
%wide = fpext float %value to double
%result = call i8 @recipe.fp8.encode(double %wide)
ret i8 %result
}}
", fp8_encoder("recipe.fp8.encode", format), mask = (1u32 << man) - 1, shift = 23 - man, offset = 127 - bias)
}
fn bf16_codec() -> &'static str {
	r#"define internal float @recipe.decode(i16 %value) #1 { entry: %wide = zext i16 %value to i32 %bits = shl i32 %wide, 16 %result = bitcast i32 %bits to float ret float %result }
define internal i16 @recipe.encode(float %value) #1 { entry: %bits = bitcast float %value to i32 %absolute = and i32 %bits, 2147483647 %special = icmp uge i32 %absolute, 2139095040 %upper = lshr i32 %bits, 16 %mantissa = and i32 %absolute, 8388607 %nan = icmp ne i32 %mantissa, 0 %quiet = or i32 %upper, 64 %special.bits = select i1 %nan, i32 %quiet, i32 %upper %lower = and i32 %bits, 65535 %above = icmp ugt i32 %lower, 32768 %tie = icmp eq i32 %lower, 32768 %odd.bit = and i32 %upper, 1 %odd = icmp ne i32 %odd.bit, 0 %tie.odd = and i1 %tie, %odd %round = or i1 %above, %tie.odd %increment = zext i1 %round to i32 %rounded = add i32 %upper, %increment %encoded = select i1 %special, i32 %special.bits, i32 %rounded %result = trunc i32 %encoded to i16 ret i16 %result }"#
}
fn encoded_ir(ir: String, suffix: &str, bytes: usize, codec: &str, pack: impl Fn(f64) -> u64, state: &str, kind: &str) -> BuildResult<String> {
	let (start, end) = numeric_region(&ir)?;
	let llvm = match bytes {
		1 => "i8",
		2 => "i16",
		4 => "i32",
		_ => "i64",
	};
	let codec = if state == "double" { widen_codec_as(codec, llvm, kind) } else { codec.to_owned() };
	let numeric = numeric_program(llvm, state, &codec);
	let mut kernel = word(format!("{}@RECIPE_NUMERIC@{}", &ir[..start], &ir[end..]), "double", llvm)
		.replace("@contraction_tile", &format!("@contraction_tile{suffix}"))
		.replace("align 8", &format!("align {bytes}"));
	kernel = kernel.replace("RECIPE_MODEL_BYTES", &bytes.to_string()).replace("RECIPE_STATE_ALIGN", &state_align(state)).replace("RECIPE_STATE", state);
	for (source, value) in [("-2.0", -2.0), ("-1.0", -1.0), ("0.0", 0.0), ("0.1", 0.1), ("0.5", 0.5), ("1.0", 1.0), ("2.0", 2.0)] {
		kernel = word(kernel, source, &pack(value).to_string())
	}
	for bits in [0x3CB0000000000000, 0x3FEFFFFFFFFFFFFE, 0xFFF0000000000000, 0x7FF8000000000000] {
		kernel = kernel.replace(&format!("0x{bits:016X}"), &format!("{}", pack(f64::from_bits(bits))))
	}
	Ok(kernel.replace("@RECIPE_NUMERIC@", &numeric))
}
fn half_ir(ir: String, suffix: &str, state: &str) -> BuildResult<String> {
	let (start, end) = numeric_region(&ir)?;
	// Saturate to the half range before rounding, the way the integer codec clamps
	// to its own extremes. A plain truncation encodes every larger result as an
	// infinity, so one overflowing activation makes the whole model nonfinite.
	let codec = "define internal float @recipe.decode(half %value) #1 { entry: %result = fpext half %value to float ret float %result }\ndefine internal half @recipe.encode(float %value) #1 { entry: %below = fcmp olt float %value, -65504.0 %above = fcmp ogt float %value, 65504.0 %lowered = select i1 %below, float -65504.0, float %value %clamped = select i1 %above, float 65504.0, float %lowered %result = fptrunc float %clamped to half ret half %result }";
	let codec = if state == "double" { widen_codec_as(codec, "half", "half") } else { codec.to_owned() };
	let numeric = numeric_program("half", state, &codec);
	let mut kernel = word(format!("{}@RECIPE_NUMERIC@{}", &ir[..start], &ir[end..]), "double", "half").replace("@contraction_tile", &format!("@contraction_tile{suffix}")).replace("align 8", "align 2");
	kernel = kernel.replace("RECIPE_MODEL_BYTES", "2").replace("RECIPE_STATE_ALIGN", &state_align(state)).replace("RECIPE_STATE", state);
	for (source, value) in [("-2.0", -2.0), ("-1.0", -1.0), ("0.0", 0.0), ("0.1", 0.1), ("0.5", 0.5), ("1.0", 1.0), ("2.0", 2.0)] {
		kernel = word(kernel, source, &format!("0xH{:04X}", FloatFormat::FP16.pack(value)))
	}
	for bits in [0x3CB0000000000000, 0x3FEFFFFFFFFFFFFE, 0xFFF0000000000000, 0x7FF8000000000000] {
		kernel = kernel.replace(&format!("0x{bits:016X}"), &format!("0xH{:04X}", FloatFormat::FP16.pack(f64::from_bits(bits))))
	}
	Ok(kernel.replace("@RECIPE_NUMERIC@", &numeric))
}
fn int_codec(format: IntFormat) -> String {
	let (bits, mask) = (format.bits, (1u16 << format.bits) - 1);
	let shift = 32 - bits;
	let minimum = -(1i16 << (bits - 1));
	let maximum = (1i16 << (bits - 1)) - 1;
	format!(
		"define internal float @recipe.decode(i8 %value) #1 {{ entry: %wide = zext i8 %value to i32 %masked = and i32 %wide, {mask} %shifted = shl i32 %masked, {shift} %signed = ashr i32 %shifted, {shift} %result = sitofp i32 %signed to float ret float %result }}\ndefine internal i8 @recipe.encode(float %value) #1 {{ entry: %nan = fcmp uno float %value, %value %rounded = call float @llvm.roundeven.f32(float %value) %below = fcmp olt float %rounded, {minimum}.0 %above = fcmp ogt float %rounded, {maximum}.0 %lowered = select i1 %below, float {minimum}.0, float %rounded %clamped = select i1 %above, float {maximum}.0, float %lowered %finite = select i1 %nan, float 0.0, float %clamped %integer = fptosi float %finite to i32 %masked = and i32 %integer, {mask} %result = trunc i32 %masked to i8 ret i8 %result }}"
	)
}
fn setting<'a>(manifest: &'a str, key: &str) -> BuildResult<&'a str> {
	let prefix = format!("{key} = ");
	manifest.lines().find_map(|line| line.trim().strip_prefix(&prefix)).ok_or_else(|| io::Error::other(format!("{key} must be configured")).into())
}
fn number<'a>(manifest: &'a str, key: &str) -> BuildResult<&'a str> {
	let value = setting(manifest, key)?;
	value.parse::<f64>().map_err(|error| io::Error::other(format!("{key} must be numeric: {error}")))?;
	Ok(value)
}
fn text<'a>(manifest: &'a str, key: &str) -> BuildResult<&'a str> {
	setting(manifest, key)?.strip_prefix('"').and_then(|value| value.strip_suffix('"')).ok_or_else(|| io::Error::other(format!("{key} must be quoted")).into())
}
fn configured_entry<'a>(manifest: &'a str, key: &str, os: &str) -> BuildResult<Option<&'a str>> {
	let entries = setting(manifest, key)?.trim().strip_prefix('{').and_then(|value| value.strip_suffix('}')).ok_or_else(|| io::Error::other(format!("{key} must be a platform table")))?;
	let Some((_, entry)) = entries.split_once(&format!(" {os} = \"")) else { return Ok(None) };
	entry.split_once('"').map(|(value, _)| Some(value)).ok_or_else(|| io::Error::other(format!("{key} entry for {os} must be quoted")).into())
}
fn configured(manifest: &str, key: &str, os: &str) -> BuildResult<Option<String>> {
	let Some(value) = configured_entry(manifest, key, os)? else { return Ok(None) };
	let Some(reference) = value.strip_prefix('$') else { return Ok(Some(value.to_owned())) };
	let (name, inside) = reference.split_once('/').unwrap_or((reference, ""));
	Ok(env::var_os(name).map(PathBuf::from).map(|root| if inside.is_empty() { root } else { root.join(inside) }.to_string_lossy().into_owned()))
}
/// The default config and matching precision and storage tables, each encoded
/// as `name:key=value,...` joined by `;`.
fn precision_profiles(manifest: &str) -> BuildResult<(String, String, String)> {
	let (mut section, mut default, mut profiles) = (None::<String>, None::<String>, Vec::<(String, Vec<String>)>::new());
	let mut storage = Vec::<(String, Vec<String>)>::new();
	for line in manifest.lines() {
		let line = line.split('#').next().unwrap_or_default().trim();
		if let Some(name) = line.strip_prefix('[').and_then(|rest| rest.strip_suffix(']')) {
			let name = name.trim().to_owned();
			if let Some(profile) = name.strip_prefix("precision.") {
				profiles.push((profile.to_owned(), Vec::new()));
			}
			if let Some(profile) = name.strip_prefix("storage.") {
				storage.push((profile.to_owned(), Vec::new()));
			}
			section = Some(name);
			continue;
		}
		let Some((key, value)) = line.split_once('=') else { continue };
		let (key, value) = (key.trim(), value.trim().trim_matches('"'));
		match section.as_deref() {
			Some("precision") if key == "default-config" => default = Some(value.to_owned()),
			Some(name) if name.starts_with("precision.") => profiles.last_mut().expect("a precision table is open").1.push(format!("{key}={value}")),
			Some(name) if name.starts_with("storage.") => storage.last_mut().expect("a storage table is open").1.push(format!("{key}={value}")),
			_ => {}
		}
	}
	let default = default.ok_or_else(|| io::Error::other("[precision] names no default-config"))?;
	if !profiles.iter().any(|(name, _)| *name == default) {
		return Err(io::Error::other(format!("default-config {default} names no [precision.{default}] table")).into());
	}
	for (name, _) in &profiles {
		if !storage.iter().any(|(candidate, _)| candidate == name) {
			return Err(io::Error::other(format!("[precision.{name}] has no matching [storage.{name}] table")).into());
		}
	}
	for (name, _) in &storage {
		if !profiles.iter().any(|(candidate, _)| candidate == name) {
			return Err(io::Error::other(format!("[storage.{name}] has no matching [precision.{name}] table")).into());
		}
	}
	let encode = |tables: &[(String, Vec<String>)]| tables.iter().map(|(name, entries)| format!("{name}:{}", entries.join(","))).collect::<Vec<_>>().join(";");
	Ok((default, encode(&profiles), encode(&storage)))
}
fn native_configuration(manifest: &str, os: &str) -> u64 {
	let mut hash = 14695981039346656037_u64;
	let mut update = |value: &str| {
		for byte in (value.len() as u64).to_le_bytes().into_iter().chain(value.bytes()) {
			hash = (hash ^ u64::from(byte)).wrapping_mul(1099511628211)
		}
	};
	update(manifest);
	update(os);
	let marker = format!("{os} = \"$");
	let mut variables = Vec::new();
	for line in manifest.lines() {
		let Some((_, reference)) = line.split_once(&marker) else { continue };
		let name = reference.split(['/', '"']).next().unwrap_or_default();
		if variables.contains(&name) {
			continue;
		}
		variables.push(name);
		println!("cargo:rerun-if-env-changed={name}");
		update(name);
		match env::var_os(name) {
			Some(value) => {
				update("present");
				update(&value.to_string_lossy());
			}
			None => update("absent"),
		}
	}
	hash
}
fn platform(manifest: &str, key: &str, os: &str) -> BuildResult<String> {
	configured(manifest, key, os)?.ok_or_else(|| io::Error::other(format!("{key} is not configured for {os}")).into())
}
struct NvidiaToolkit {
	device_library: PathBuf,
	assemblers: Vec<PathBuf>,
	required: bool,
}
fn nvidia_toolkit(manifest: &str, os: &str) -> BuildResult<Option<NvidiaToolkit>> {
	let Some(entry) = configured_entry(manifest, "nvidia-toolkit", os)? else { return Ok(None) };
	let Some(root) = configured(manifest, "nvidia-toolkit", os)?.map(PathBuf::from) else { return Ok(None) };
	Ok(Some(NvidiaToolkit { device_library: root.join(text(manifest, "nvidia-device-library")?), assemblers: text(manifest, "nvidia-assembler")?.split(';').map(|path| root.join(path)).collect(), required: entry.starts_with('$') }))
}
const CPU_REPLACEMENTS: &[(&str, &str)] = &[
	(
		"@contraction_tile = external addrspace(3) global [0 x double], align 16",
		"@contraction_tile = internal thread_local global [RECIPE_CONTRACTION_CPU_SHARED_VALUES x RECIPE_STATE] zeroinitializer, align 16",
	),
	(" addrspace(3)", ""),
	("call i32 @llvm.amdgcn.workitem.id.x()", "call i32 @recipe.cpu.thread.id()"),
	("call i32 @recipe.local.id.x()", "add i32 0, 0"),
	("call i32 @recipe.group.id.x()", "call i32 @recipe.cpu.thread.id()"),
	("call i32 @recipe.workgroup.size.x()", "add i32 1, 0"),
	("call void @llvm.amdgcn.s.barrier()", ""),
	("call void @recipe.local.barrier()", ""),
	("call void @grid_barrier(i32 %threads)", "call void @recipe.cpu.barrier()"),
	("declare i32 @llvm.amdgcn.workitem.id.x()", ""),
	("declare void @llvm.amdgcn.s.barrier()", ""),
	("declare i64 @__ockl_steadyctr_u64()", ""),
	("attributes #0 = { nounwind \"amdgpu-flat-work-group-size\"=\"RECIPE_WORKGROUP_SIZE,RECIPE_WORKGROUP_SIZE\" }", "attributes #0 = { nounwind }"),
];
const CPU_PARALLEL: &str = r#"@recipe.cpu.thread = internal thread_local global i32 0, align 4
@recipe.cpu.barrier.context = internal thread_local global ptr null, align 8
@recipe.cpu.barrier.wait = internal thread_local global ptr null, align 8
@recipe.cpu.clock.read = internal thread_local global ptr null, align 8
define RECIPE_CPU_ENTRY_LINKAGE void @recipe_model_thread(i32 %thread, ptr %context, ptr %wait, ptr %clock) #0 { entry: store i32 %thread, ptr @recipe.cpu.thread, align 4 store ptr %context, ptr @recipe.cpu.barrier.context, align 8 store ptr %wait, ptr @recipe.cpu.barrier.wait, align 8 store ptr %clock, ptr @recipe.cpu.clock.read, align 8 ret void }
define internal i32 @recipe.cpu.thread.id() #1 { entry: %thread = load i32, ptr @recipe.cpu.thread, align 4 ret i32 %thread }
define internal void @recipe.cpu.barrier() #1 { entry: %context = load ptr, ptr @recipe.cpu.barrier.context, align 8 %wait = load ptr, ptr @recipe.cpu.barrier.wait, align 8 call void %wait(ptr %context) ret void }
define internal i64 @recipe.cpu.clock() #1 { entry: %read = load ptr, ptr @recipe.cpu.clock.read, align 8 %now = call i64 %read() ret i64 %now }"#;
/// Contraction shape. Reverse K partitions use `split_span`, capped at
/// `partitions`, for a fixed summation order across devices.
#[derive(Clone, Copy)]
struct Schedule {
	swizzle_m: u32,
	partitions: u32,
	split_span: u32,
	matrix_split_span: u32,
	local_chunks: u32,
}
/// The key-value cache codec of one template: the cache element type and the
/// conversions the attention bodies call. `model` is the template's model
/// type, `arithmetic` its state, `kv` the cache type.
fn kv_codec(model: &str, arithmetic: &str, kv: &str, fp8: Option<FloatFormat>) -> String {
	let widen = |name: &str, from: &str| if arithmetic == "double" { format!("%{name} = fpext float %{from} to double\n") } else { format!("%{name} = fadd float %{from}, 0.0\n") };
	let narrow = |name: &str, from: &str| if arithmetic == "double" { format!("%{name} = fptrunc double %{from} to float\n") } else { format!("%{name} = fadd float %{from}, 0.0\n") };
	let to_float = |name: &str, from: &str| match kv {
		"i8" => format!("%{name} = call float @recipe.kv.storage.decode(i8 %{from})\n"),
		"half" => format!("%{name} = fpext half %{from} to float\n"),
		"i16" => format!("%{name}.wide = zext i16 %{from} to i32\n%{name}.bits = shl i32 %{name}.wide, 16\n%{name} = bitcast i32 %{name}.bits to float\n"),
		_ => format!("%{name} = fadd float %{from}, 0.0\n"),
	};
	let from_float = |name: &str, from: &str| match kv {
		"i8" => format!("%{name} = call i8 @recipe.kv.storage.encode(float %{from})\n"),
		"half" => format!("%{name}.below = fcmp olt float %{from}, -65504.0\n%{name}.above = fcmp ogt float %{from}, 65504.0\n%{name}.lowered = select i1 %{name}.below, float -65504.0, float %{from}\n%{name}.clamped = select i1 %{name}.above, float 65504.0, float %{name}.lowered\n%{name} = fptrunc float %{name}.clamped to half\n"),
		"i16" => format!("%{name}.bits = bitcast float %{from} to i32\n%{name}.low = lshr i32 %{name}.bits, 16\n%{name}.odd = and i32 %{name}.low, 1\n%{name}.bias = add i32 %{name}.odd, 32767\n%{name}.rounded = add i32 %{name}.bits, %{name}.bias\n%{name}.high = lshr i32 %{name}.rounded, 16\n%{name} = trunc i32 %{name}.high to i16\n"),
		_ => format!("%{name} = fadd float %{from}, 0.0\n"),
	};
	let from_state = |name: &str, from: &str| {
		if fp8.is_some() && arithmetic == "double" {
			format!("%{name} = call i8 @recipe.kv.storage.fp8.encode(double %{from})\n")
		} else { narrow("narrowed", from) + &from_float(name, "narrowed") }
	};
	// The cache in the model's own type: the bytes pass through untouched.
	if kv == model && fp8.is_none() {
		return format!("define internal {kv} @recipe.kv.encode({model} %value) #1 {{\nentry:\nret {kv} %value\n}}\ndefine internal {model} @recipe.kv.decode({kv} %value) #1 {{\nentry:\nret {model} %value\n}}\ndefine internal float @recipe.kv.to.f32({kv} %value) #1 {{\nentry:\n%state = call {arithmetic} @recipe.decode({model} %value)\n{}ret float %result\n}}\ndefine internal {kv} @recipe.kv.from.f16(half %value) #1 {{\nentry:\n%wide = fpext half %value to float\n{}%result = call {model} @recipe.encode({arithmetic} %state)\nret {kv} %result\n}}\ndefine internal {arithmetic} @recipe.kv.to.state({kv} %value) #1 {{\nentry:\n%result = call {arithmetic} @recipe.decode({model} %value)\nret {arithmetic} %result\n}}\ndefine internal {kv} @recipe.kv.from.state({arithmetic} %value) #1 {{\nentry:\n%result = call {model} @recipe.encode({arithmetic} %value)\nret {kv} %result\n}}\n", narrow("result", "state"), widen("state", "wide"));
	}
	let mut ir = fp8.map(|format| fp8_codec(format).replace("@recipe.", "@recipe.kv.storage.")).unwrap_or_default();
	ir.push_str(&format!("define internal {kv} @recipe.kv.encode({model} %value) #1 {{\nentry:\n%state = call {arithmetic} @recipe.decode({model} %value)\n{}ret {kv} %result\n}}\n", from_state("result", "state")));
	ir.push_str(&format!("define internal {model} @recipe.kv.decode({kv} %value) #1 {{\nentry:\n{}{}%result = call {model} @recipe.encode({arithmetic} %state)\nret {model} %result\n}}\n", to_float("wide", "value"), widen("state", "wide")));
	ir.push_str(&format!("define internal float @recipe.kv.to.f32({kv} %value) #1 {{\nentry:\n{}ret float %result\n}}\n", to_float("result", "value")));
	ir.push_str(&format!("define internal {kv} @recipe.kv.from.f16(half %value) #1 {{\nentry:\n%wide = fpext half %value to float\n{}ret {kv} %result\n}}\n", from_float("result", "wide")));
	ir.push_str(&format!("define internal {arithmetic} @recipe.kv.to.state({kv} %value) #1 {{\nentry:\n{}{}ret {arithmetic} %result\n}}\n", to_float("wide", "value"), widen("result", "wide")));
	ir.push_str(&format!("define internal {kv} @recipe.kv.from.state({arithmetic} %value) #1 {{\nentry:\n{}ret {kv} %result\n}}\n", from_state("result", "value")));
	ir
}
/// Every template source: one per model precision with the cache in the model
/// type, and one more per explicit cache format. FP8 formats remain distinct
/// from integer formats even though both use an i8 storage element.
fn precision_sources(ir: String, schedule: Schedule) -> BuildResult<Vec<(String, String)>> {
	let mut sources = Vec::new();
	for (suffix, contents, model, arithmetic, bytes) in precision_bases(ir, schedule)? {
		let cache = |kv: &str, kv_bytes: usize, fp8| contents.replace("RECIPE_KV_ALIGN", &kv_bytes.to_string()).replace("RECIPE_KV", kv) + "\n" + &kv_codec(model, arithmetic, kv, fp8);
		sources.push((suffix.clone(), cache(model, bytes, None)));
		for (name, kv, kv_bytes) in [("f16", "half", 2), ("bf16", "i16", 2), ("f32", "float", 4)] {
			if kv == model && !(name == "f32" && suffix.starts_with("-tf32")) {
				continue;
			}
			sources.push((format!("{suffix}-kv{name}"), cache(kv, kv_bytes, None)));
		}
		for (name, format) in [("f8", FloatFormat::FP8), ("f8e5m2", FloatFormat::FP8_E5M2)] {
			sources.push((format!("{suffix}-kv{name}"), cache("i8", 1, Some(format))));
		}
	}
	Ok(sources)
}
/// Every template base: (source key, contents, model type, state type, model
/// bytes). The fp64 and custom-float bases compute in double; every other base
/// computes in float and has an `-acc64` sibling that keeps the same model type
/// under a double state, selected by `acc = "fp64"` in the precision table.
fn precision_bases(ir: String, schedule: Schedule) -> BuildResult<Vec<(String, String, &'static str, &'static str, usize)>> {
	let ir = ir
		.replace("RECIPE_CONTRACTION_SWIZZLE_M", &schedule.swizzle_m.to_string())
		.replace("RECIPE_CONTRACTION_K_PARTITIONS", &schedule.partitions.to_string())
		.replace("RECIPE_CONTRACTION_MATRIX_SPLIT_SPAN", &schedule.matrix_split_span.to_string())
		.replace("RECIPE_CONTRACTION_SPLIT_SPAN", &schedule.split_span.to_string())
		.replace("RECIPE_CONTRACTION_LOCAL_CHUNKS", &schedule.local_chunks.to_string());
	let mut bases = vec![("".to_owned(), native_ir(ir.clone(), "", "double", FloatFormat::FP64, "double")?, "double", "double", 8)];
	for state in ["float", "double"] {
		let acc = if state == "double" { ACC64 } else { "" };
		// Symbol suffixes spell the key with underscores: a hyphen is not part of
		// a symbol name to the variant linker.
		let tile = |key: &str| format!("_{}{}", key.trim_start_matches('-'), acc.replace('-', "_"));
		bases.push((format!("-f32{acc}"), native_ir(ir.clone(), &tile("-f32"), "float", FloatFormat::FP32, state)?, "float", state, 4));
		bases.push((format!("-f16{acc}"), half_ir(ir.clone(), &tile("-f16"), state)?, "half", state, 2));
		for (key, kind, format) in [("-f8", "fp8", FloatFormat::FP8), ("-f8e5m2", "fp8e5m2", FloatFormat::FP8_E5M2)] {
			bases.push((format!("{key}{acc}"), encoded_ir(ir.clone(), &tile(key), format.bytes(), &fp8_codec(format), |value| format.pack(value), state, kind)?, "i8", state, 1));
		}
		bases.push((format!("-bf16{acc}"), encoded_ir(ir.clone(), &tile("-bf16"), FloatFormat::BF16.bytes(), bf16_codec(), |value| FloatFormat::BF16.pack(value), state, "bf16")?, "i16", state, 2));
		bases.push((format!("-tf32{acc}"), native_ir(ir.clone(), &tile("-tf32"), "float", FloatFormat::TF32, state)?, "float", state, 4));
		bases.push((format!("-int8{acc}"), encoded_ir(ir.clone(), &tile("-int8"), IntFormat::INT8.bytes(), &int_codec(IntFormat::INT8), |value| IntFormat::INT8.pack(value), state, "int8")?, "i8", state, 1));
		bases.push((format!("-int4{acc}"), encoded_ir(ir.clone(), &tile("-int4"), IntFormat::INT4.bytes(), &int_codec(IntFormat::INT4), |value| IntFormat::INT4.pack(value), state, "int4")?, "i8", state, 1));
	}
	Ok(bases)
}
/// The state type a template base computes in: double for the fp64 and
/// custom-float bases and for every `-acc64` sibling, float otherwise.
fn template_state(base: &str) -> &'static str {
	if base.is_empty() || base.ends_with(ACC64) { "double" } else { "float" }
}
fn wmma_source(source: &str) -> String {
	source.lines().filter(|line| !line.starts_with("; RECIPE_WMMA ")).collect::<Vec<_>>().join("\n")
}
fn wmma_method(source: &str, key: &str) -> BuildResult<(String, String)> {
	let marker = format!("{key} ");
	let catalog = source.lines().find_map(|line| line.strip_prefix("; RECIPE_WMMA ")).ok_or_else(|| io::Error::other("WMMA methods are absent"))?;
	let method = catalog.split(" || ").find_map(|method| method.strip_prefix(&marker)).ok_or_else(|| io::Error::other(format!("WMMA method {key} is absent")))?;
	let (kind, body) = method.split_once(' ').ok_or_else(|| io::Error::other(format!("WMMA method {key} has no body")))?;
	Ok((kind.to_owned(), body.replace("\\n", "\n")))
}
fn compose_wmma(ir: String, source: &str, key: &str) -> BuildResult<String> {
	let (kind, body) = wmma_method(source, key)?;
	if kind == "call" {
		return Ok(ir.replace("@recipe.wmma(", &body));
	}
	if kind != "definition" {
		return Err(io::Error::other(format!("WMMA method {key} has an invalid kind")).into());
	}
	let declaration = ir.lines().find(|line| line.starts_with("declare ") && line.contains("@recipe.wmma(")).ok_or_else(|| io::Error::other("specialized WMMA declaration is absent"))?.to_owned();
	Ok(ir.replace(&declaration, &body))
}
fn compose_contraction(mut ir: String, matrix: bool) -> String {
	for (operation, vector, native) in [
		("@contraction_product_accumulate(", "@contraction_vector_accumulate(", "@contraction_matrix_accumulate("),
		("@contraction_a_index(", "@contraction_vector_a_index(", "@contraction_matrix_a_index("),
		("@contraction_b_index(", "@contraction_vector_b_index(", "@contraction_matrix_b_index("),
		("@contraction_output_m(", "@contraction_vector_output_m(", "@contraction_matrix_output_m("),
		("@contraction_output_n(", "@contraction_vector_output_n(", "@contraction_matrix_output_n("),
		("@contraction_store_lane(", "@contraction_vector_store_lane(", "@contraction_matrix_store_lane("),
	] {
		ir = ir.replace(operation, if matrix { native } else { vector })
	}
	ir
}
/// The backward passes take the vector product with one operand staged in the
/// arithmetic type: `_bs` reads B (the delta) as RECIPE_STATE after a model A and
/// `_as` reads A (the delta) as RECIPE_STATE before a model B. Both are the vector
/// kernel's own text with the fragment loads and the widening swapped, so the
/// chunking, the owner and the fold order are the forward kernel's exactly.
fn backward_accumulate_variants(ir: &str) -> BuildResult<String> {
	let start = ir.find("define internal void @contraction_vector_accumulate(").ok_or("contraction_vector_accumulate is missing")?;
	let tail = "\nexit:\nret void\n}\n";
	let end = start + ir[start..].find(tail).ok_or("contraction_vector_accumulate has no end")? + tail.len();
	let kernel = &ir[start..end];
	let swap = |text: String, from: &str, to: &str| -> BuildResult<String> {
		if !text.contains(from) {
			return Err(format!("backward accumulate: {from} is missing").into());
		}
		Ok(text.replace(from, to))
	};
	let b_state = kernel
		.replace("@contraction_vector_accumulate(", "@contraction_vector_accumulate_bs(")
		.replace("@contraction_a_fragment(", "@contraction_a_fragment_vector(")
		.replace("@contraction_b_fragment(", "@contraction_b_fragment_state(")
		.replace("<RECIPE_REGISTER_N x double>", "<RECIPE_REGISTER_N x RECIPE_STATE>");
	let b_state = swap(b_state, "%local.b = extractelement <RECIPE_REGISTER_N x RECIPE_STATE> %local.b.fragment, i32 %local.b.index\n%local.b.wide = call RECIPE_STATE @recipe.decode(double %local.b)\n", "%local.b.wide = extractelement <RECIPE_REGISTER_N x RECIPE_STATE> %local.b.fragment, i32 %local.b.index\n")?;
	let b_state = swap(b_state, "%b = extractelement <RECIPE_REGISTER_N x RECIPE_STATE> %b.fragment, i32 %register.n\n%b.wide = call RECIPE_STATE @recipe.decode(double %b)\n", "%b.wide = extractelement <RECIPE_REGISTER_N x RECIPE_STATE> %b.fragment, i32 %register.n\n")?;
	let a_state = kernel
		.replace("@contraction_vector_accumulate(", "@contraction_vector_accumulate_as(")
		.replace("@contraction_a_fragment(", "@contraction_a_fragment_state(")
		.replace("@contraction_b_fragment(", "@contraction_b_fragment_after_state(")
		.replace("<RECIPE_REGISTER_M x double>", "<RECIPE_REGISTER_M x RECIPE_STATE>");
	let a_state = swap(a_state, "%local.a.wide = call <RECIPE_REGISTER_M x RECIPE_STATE> @contraction_widen_m(<RECIPE_REGISTER_M x RECIPE_STATE> %local.a.fragment)\n", "%local.a.wide = select i1 true, <RECIPE_REGISTER_M x RECIPE_STATE> %local.a.fragment, <RECIPE_REGISTER_M x RECIPE_STATE> %local.a.fragment\n")?;
	let a_state = swap(a_state, "%a.wide = call <RECIPE_REGISTER_M x RECIPE_STATE> @contraction_widen_m(<RECIPE_REGISTER_M x RECIPE_STATE> %a.fragment)\n", "%a.wide = select i1 true, <RECIPE_REGISTER_M x RECIPE_STATE> %a.fragment, <RECIPE_REGISTER_M x RECIPE_STATE> %a.fragment\n")?;
	Ok(format!("{}{b_state}{a_state}{}", &ir[..end], &ir[end..]))
}
fn compile_amd(manifest: &str, out: &PathBuf, os: &str, schedule: Schedule) -> BuildResult<()> {
	let source = backward_accumulate_variants(&fs::read_to_string("amd-nv-cpu.ll")?)?;
	let ir = parallel_ir(wmma_source(&source), AMD_WIDTH, AMD_GRID_BARRIER)
		.replace("; RECIPE_BLOCK_HELPERS", &block_dot_helpers())
		.replace("call void @llvm.amdgcn.s.barrier()", "call void @recipe.workgroup.barrier()")
		.replace("; RECIPE_WAVE_HELPERS", &format!("{AMD_WORKGROUP_BARRIER}\n; RECIPE_WAVE_HELPERS"));
	let mut values = Vec::new();
	for (suffix, contents) in precision_sources(ir, schedule)? {
		let base = suffix.split("-kv").next().unwrap_or_default();
		let state = template_state(base);
		let helpers = if state == "double" { AMD_WAVE_HELPERS_DOUBLE } else { AMD_WAVE_HELPERS };
		let dot = if int_state(state) { AMD_DOT4_HELPERS } else { "" };
		let ints = int_partial_helpers(state);
		let helpers = format!("{}\n{}{}{}{}{}{}", helpers, dot, amd_q4_slice_helper(state, int_state(state)), amd_q6_slice_helper(state, int_state(state)), amd_block32_slice_helper(state, int_state(state)), ints, rope_math_helpers(state, false));
		let contents = with_glibc_declares(contents.replace("; RECIPE_WAVE_HELPERS", &helpers));
		let path = out.join(format!("recipe-amd{suffix}.ll"));
		fs::write(&path, compose_contraction(contents.clone(), false))?;
		values.push(format!("{}={}", if suffix.is_empty() { "default" } else { suffix.as_str() }, path.display()));
		if ["-f16", "-bf16", "-int8", "-int4"].contains(&suffix.as_str()) {
			for architecture in ["gfx11", "gfx12"] {
				let template = format!("{architecture}{suffix}");
				let method = if template == "gfx12-int4" { "gfx12-int8" } else { &template };
				let path = out.join(format!("recipe-amd-{template}.ll"));
				fs::write(&path, compose_wmma(compose_contraction(contents.clone(), true), &source, method)?)?;
				values.push(format!("{template}={}", path.display()));
			}
		}
	}
	println!("cargo:rustc-env=RECIPE_AMD_IR={}", values.join("\x3b"));
	for (key, environment) in [
		("hsa-compiler", "RECIPE_HSA_COMPILER"),
		("hsa-runtime", "RECIPE_HSA_RUNTIME"),
		("hsa-device-library", "RECIPE_HSA_DEVICE_LIBRARY"),
		("hsa-clock-library", "RECIPE_HSA_CLOCK_LIBRARY"),
		("hsa-abi-library", "RECIPE_HSA_ABI_LIBRARY"),
		("hsa-finite-library", "RECIPE_HSA_FINITE_LIBRARY"),
		("hsa-math-library", "RECIPE_HSA_MATH_LIBRARY"),
		("hsa-device-library-directory", "RECIPE_HSA_DEVICE_LIBRARY_DIRECTORY"),
	] {
		println!("cargo:rustc-env={environment}={}", platform(manifest, key, os)?);
	}
	Ok(())
}
fn compile_nvidia(manifest: &str, out: &PathBuf, os: &str, schedule: Schedule) -> BuildResult<()> {
	let ir = wmma_source(&backward_accumulate_variants(&fs::read_to_string("amd-nv-cpu.ll")?)?).replace("; RECIPE_BLOCK_HELPERS", &block_dot_helpers());
	let ir = parallel_ir(ir, "declare i32 @recipe.workgroup.size.x()", NVIDIA_GRID_BARRIER)
		.replace("amdgcn-amd-amdhsa", "nvptx64-nvidia-cuda")
		.replace("llvm.amdgcn.workitem.id.x", "llvm.nvvm.read.ptx.sreg.tid.x")
		.replace("llvm.amdgcn.workgroup.id.x", "llvm.nvvm.read.ptx.sreg.ctaid.x")
		.replace("recipe.workgroup.size.x", "llvm.nvvm.read.ptx.sreg.ntid.x")
		.replace("llvm.amdgcn.s.barrier", "llvm.nvvm.barrier0")
		.replace("attributes #0 = { nounwind \"amdgpu-flat-work-group-size\"=\"RECIPE_WORKGROUP_SIZE,RECIPE_WORKGROUP_SIZE\" }", "attributes #0 = { nounwind }")
		.replace(", addrspace(5)", "")
		.replace(" addrspace(5)", "");
	let mut values = Vec::new();
	for (suffix, contents) in precision_sources(ir, schedule)? {
		let base = suffix.split("-kv").next().unwrap_or_default();
		let contents = with_glibc_declares(contents.replace("; RECIPE_WAVE_HELPERS", &nvidia_wave_helpers(template_state(base))));
		let path = out.join(format!("recipe-nvidia{suffix}.ll"));
		fs::write(&path, compose_contraction(contents, false))?;
		values.push(format!("{}={}", if suffix.is_empty() { "default" } else { suffix.as_str() }, path.display()));
	}
	println!("cargo:rustc-env=RECIPE_NV_IR={}", values.join("\x3b"));
	println!("cargo:rustc-env=RECIPE_NV_COMPILER={}", platform(manifest, "nvidia-compiler", os)?);
	println!("cargo:rustc-env=RECIPE_NV_CODEGEN={}", platform(manifest, "nvidia-codegen", os)?);
	println!("cargo:rustc-env=RECIPE_NV_RUNTIME={}", platform(manifest, "nvidia-runtime", os)?);
	let toolkit = nvidia_toolkit(manifest, os)?.ok_or_else(|| io::Error::other(format!("nvidia-toolkit is not configured for {os}")))?;
	println!("cargo:rustc-env=RECIPE_NV_DEVICE_LIBRARY={}", toolkit.device_library.display());
	println!("cargo:rustc-env=RECIPE_NV_ASSEMBLER={}", toolkit.assemblers.iter().map(|path| path.display().to_string()).collect::<Vec<_>>().join("\x3b"));
	println!("cargo:rustc-env=RECIPE_NV_PTX_VERSION=+{}", text(manifest, "nvidia-ptx")?);
	Ok(())
}
fn compile_cpu(manifest: &str, out: &PathBuf, os: &str, schedule: Schedule) -> BuildResult<()> {
	let target = env::var("TARGET")?;
	let mut ir = wmma_source(&backward_accumulate_variants(&fs::read_to_string("amd-nv-cpu.ll")?)?).replace("amdgcn-amd-amdhsa", &target).replace("; RECIPE_WAVE_HELPERS", IDENTITY_WAVE_HELPERS).replace("; RECIPE_BLOCK_HELPERS", &block_dot_helpers());
	for (pattern, replacement) in CPU_REPLACEMENTS {
		ir = ir.replace(pattern, replacement);
	}
	ir.push_str(&CPU_PARALLEL.replace("RECIPE_CPU_ENTRY_LINKAGE", &platform(manifest, "cpu-entry-linkage", os)?));
	let clang = platform(manifest, "cpu-compiler", os)?;
	for (key, tool) in [("cpu-compiler", &clang), ("cpu-linker", &platform(manifest, "cpu-linker", os)?)] {
		let path = Path::new(tool);
		if !path.is_absolute() || !path.exists() {
			return Err(io::Error::other(format!("{key} {tool:?} is not an absolute existing path")).into());
		}
	}
	let mut values = Vec::new();
	for (suffix, contents) in precision_sources(ir, schedule)? {
		let base = suffix.split("-kv").next().unwrap_or_default();
		let contents = (with_glibc_declares(contents + "\n" + &cpu_int8_helpers(template_state(base))))
			.replace(" addrspace(1)", "")
			.replace(" addrspace(3)", "")
			.replace(", addrspace(5)", "")
			.replace(" addrspace(5)", "")
			.replace("RECIPE_CONTRACTION_CPU_SHARED_VALUES", number(manifest, "contraction-cpu-shared-values")?);
		let path = out.join(format!("recipe-cpu{suffix}.ll"));
		fs::write(&path, compose_contraction(contents, false))?;
		values.push(format!("{}={}", if suffix.is_empty() { "default" } else { suffix.as_str() }, path.display()));
	}
	println!("cargo:rustc-env=RECIPE_CPU_IR={}", values.join("\x3b"));
	println!("cargo:rustc-env=RECIPE_CPU_COMPILER={clang}");
	println!("cargo:rustc-env=RECIPE_CPU_TARGET={target}");
	for (key, environment) in [
		("null-device", "RECIPE_NULL_DEVICE"),
		("cpu-linker", "RECIPE_CPU_LINKER"),
		("cpu-linker-driver", "RECIPE_CPU_LINKER_DRIVER"),
		("cpu-library-flags", "RECIPE_CPU_LIBRARY_FLAGS"),
		("cpu-link-flags", "RECIPE_CPU_LINK_FLAGS"),
		("cpu-entry-linkage", "RECIPE_CPU_ENTRY_LINKAGE"),
		("cpu-module-suffix", "RECIPE_CPU_MODULE_SUFFIX"),
	] {
		println!("cargo:rustc-env={environment}={}", platform(manifest, key, os)?);
	}
	Ok(())
}
fn main() -> BuildResult<()> {
	let manifest = fs::read_to_string("Cargo.toml")?;
	let mtp = manifest.split_once("[package.metadata.mtp]").ok_or_else(|| io::Error::other("[package.metadata.mtp] must be configured"))?.1;
	let mtp = mtp.split("\n[").next().unwrap_or(mtp);
	let tokens = setting(mtp, "tokens")?.parse::<u32>().ok().filter(|tokens| *tokens > 0)
		.ok_or_else(|| io::Error::other("mtp.tokens must be a positive integer"))?;
	let probs = setting(mtp, "probs")?.parse::<f64>().ok().filter(|probs| probs.is_finite() && (0.0..=1.0).contains(probs))
		.ok_or_else(|| io::Error::other("mtp.probs must be a finite probability in 0..=1"))?;
	println!("cargo:rustc-env=RECIPE_MTP_TOKENS={tokens}");
	println!("cargo:rustc-env=RECIPE_MTP_PROBS={probs}");
	let positive = |key: &str| -> BuildResult<u32> {
		setting(&manifest, key)?.parse::<u32>().ok().filter(|value| *value != 0).ok_or_else(|| io::Error::other(format!("{key} must be a positive integer")).into())
	};
	let schedule = Schedule {
		swizzle_m: positive("contraction-swizzle-m-tiles")?,
		partitions: positive("contraction-k-partitions")?,
		split_span: positive("contraction-split-span")?,
		matrix_split_span: positive("contraction-matrix-split-span")?,
		local_chunks: positive("contraction-local-chunks")?,
	};
	for (key, environment) in [
		("epochs", "RECIPE_TRAIN_EPOCHS"),
		("learning-rate", "RECIPE_TRAIN_LEARNING_RATE"),
		("initial-weight", "RECIPE_TRAIN_INITIAL_WEIGHT"),
		("adamw-beta1", "RECIPE_ADAMW_BETA1"),
		("adamw-beta2", "RECIPE_ADAMW_BETA2"),
		("adamw-epsilon", "RECIPE_ADAMW_EPSILON"),
		("adamw-weight-decay", "RECIPE_ADAMW_WEIGHT_DECAY"),
		("kmeans-iterations", "RECIPE_KMEANS_ITERATIONS"),
		("svm-iterations", "RECIPE_SVM_ITERATIONS"),
		("svm-learning-rate", "RECIPE_SVM_LEARNING_RATE"),
		("svm-regularization", "RECIPE_SVM_REGULARIZATION"),
		("svm-epsilon", "RECIPE_SVM_EPSILON"),
		("tree-depth", "RECIPE_TREE_DEPTH"),
		("tree-min-rows", "RECIPE_TREE_MIN_ROWS"),
		("forest-feature-fraction", "RECIPE_FOREST_FEATURE_FRACTION"),
		("bayes-prior-precision", "RECIPE_BAYES_PRIOR_PRECISION"),
		("bayes-noise-variance", "RECIPE_BAYES_NOISE_VARIANCE"),
		("bayes-variance-epsilon", "RECIPE_BAYES_VARIANCE_EPSILON"),
		("boost-iterations", "RECIPE_BOOST_ITERATIONS"),
		("boost-learning-rate", "RECIPE_BOOST_LEARNING_RATE"),
		("catboost-ordered-prior", "RECIPE_CATBOOST_ORDERED_PRIOR"),
		("catboost-border-count", "RECIPE_CATBOOST_BORDER_COUNT"),
		("xgboost-l2-regularization", "RECIPE_XGBOOST_L2_REGULARIZATION"),
		("xgboost-minimum-gain", "RECIPE_XGBOOST_MINIMUM_GAIN"),
		("lightgbm-histogram-bins", "RECIPE_LIGHTGBM_HISTOGRAM_BINS"),
		("lightgbm-leaves", "RECIPE_LIGHTGBM_LEAVES"),
		("quantization-block-weights", "RECIPE_QUANTIZATION_BLOCK_WEIGHTS"),
		("surrogate-epochs", "RECIPE_SURROGATE_EPOCHS"),
		("surrogate-rate", "RECIPE_SURROGATE_RATE"),
		("surrogate-width", "RECIPE_SURROGATE_WIDTH"),
		("schedule-candidates", "RECIPE_SCHEDULE_CANDIDATES"),
		("schedule-measurements", "RECIPE_SCHEDULE_MEASUREMENTS"),
		("schedule-budget", "RECIPE_SCHEDULE_BUDGET"),
		("schedule-warmups", "RECIPE_SCHEDULE_WARMUPS"),
		("schedule-minimum-improvement", "RECIPE_SCHEDULE_MINIMUM_IMPROVEMENT"),
		("random-seed", "RECIPE_RANDOM_SEED"),
		("progress-refresh-hz", "RECIPE_PROGRESS_REFRESH_HZ"),
		("normalization-epsilon", "RECIPE_NORMALIZATION_EPSILON"),
		("categorical-ratio", "RECIPE_CATEGORICAL_RATIO"),
		("leak-slope", "RECIPE_LEAK_SLOPE"),
		("prelu-slope", "RECIPE_PRELU_SLOPE"),
		("elu-alpha", "RECIPE_ELU_ALPHA"),
		("selu-alpha", "RECIPE_SELU_ALPHA"),
		("selu-scale", "RECIPE_SELU_SCALE"),
		("gelu-scale", "RECIPE_GELU_SCALE"),
		("gelu-cubic", "RECIPE_GELU_CUBIC"),
		("huber-threshold", "RECIPE_HUBER_THRESHOLD"),
		("output-tolerance", "RECIPE_OUTPUT_TOLERANCE"),
		("gradient-tolerance", "RECIPE_GRADIENT_TOLERANCE"),
		("backend-tolerance", "RECIPE_BACKEND_TOLERANCE"),
		("contraction-cpu-shared-values", "RECIPE_CONTRACTION_CPU_SHARED_VALUES"),
		("contraction-register-m", "RECIPE_CONTRACTION_REGISTER_M"),
		("contraction-register-n", "RECIPE_CONTRACTION_REGISTER_N"),
		("contraction-fragment-k", "RECIPE_CONTRACTION_FRAGMENT_K"),
		("contraction-k-partitions", "RECIPE_CONTRACTION_K_PARTITIONS"),
		("contraction-split-span", "RECIPE_CONTRACTION_SPLIT_SPAN"),
		("contraction-matrix-split-span", "RECIPE_CONTRACTION_MATRIX_SPLIT_SPAN"),
		("contraction-chunk-k", "RECIPE_CONTRACTION_CHUNK_K"),
		("contraction-resident-waves-per-workgroup", "RECIPE_CONTRACTION_RESIDENT_WAVES_PER_WORKGROUP"),
		("lookup-readers", "RECIPE_LOOKUP_READERS"),
		("contraction-matrix-max-waves-per-workgroup", "RECIPE_CONTRACTION_MATRIX_MAX_WAVES_PER_WORKGROUP"),
		("attention-query-tile", "RECIPE_ATTENTION_QUERY_TILE"),
		("delta-chunk", "RECIPE_DELTA_CHUNK"),
		("draft-positions", "RECIPE_DRAFT_POSITIONS"),
		("topology-probe-bytes", "RECIPE_TOPOLOGY_PROBE_BYTES"),
		("tensor-split-region-bytes", "RECIPE_TENSOR_SPLIT_REGION_BYTES"),
		("placement-launch-reserve-bytes", "RECIPE_PLACEMENT_LAUNCH_RESERVE_BYTES"),
		("nvidia-step-registers", "RECIPE_NVIDIA_STEP_REGISTERS"),
		("lane-tuning", "RECIPE_LANE_TUNING"),
		("lane-tuning-window", "RECIPE_LANE_TUNING_WINDOW"),
		("lane-tuning-temperature", "RECIPE_LANE_TUNING_TEMPERATURE"),
		("compile-memory-per-ir-byte", "RECIPE_COMPILE_MEMORY_PER_IR_BYTE"),
		("cpu-worker-threads", "RECIPE_CPU_WORKER_THREADS"),
	] {
		println!("cargo:rustc-env={environment}={}", number(&manifest, key)?);
	}
<<<<<<< HEAD
	let (default_config, profiles, storage) = precision_profiles(&manifest)?;
=======
	// Devices whose memory above a bound must not be used: `node:device = bytes`.
	let usable = setting(&manifest, "device-usable-bytes")?.trim().strip_prefix('{').and_then(|value| value.strip_suffix('}')).ok_or_else(|| io::Error::other("device-usable-bytes must be a table"))?;
	let usable = usable.split(',').map(str::trim).filter(|entry| !entry.is_empty()).map(|entry| {
		let (device, bytes) = entry.split_once('=').ok_or_else(|| io::Error::other(format!("device-usable-bytes entry {entry} must be \"node:device\" = bytes")))?;
		let (device, bytes) = (device.trim().trim_matches('"'), bytes.trim());
		bytes.parse::<u64>().map_err(|error| io::Error::other(format!("device-usable-bytes for {device} must be a byte count: {error}")))?;
		Ok(format!("{device}={bytes}"))
	}).collect::<BuildResult<Vec<_>>>()?.join(";");
	println!("cargo:rustc-env=RECIPE_DEVICE_USABLE_BYTES={usable}");
	let (default_config, profiles) = precision_profiles(&manifest)?;
>>>>>>> 73cf82209379471c3cdaefd6275bbd2f5a70ce13
	println!("cargo:rustc-env=RECIPE_DEFAULT_CONFIG={default_config}");
	println!("cargo:rustc-env=RECIPE_PRECISION_PROFILES={profiles}");
	println!("cargo:rustc-env=RECIPE_STORAGE_PROFILES={storage}");
	let placement = setting(&manifest, "multi-device")?;
	println!(
		"cargo:rustc-env=RECIPE_MULTI_DEVICE={}",
		match placement {
			"false" | "true" => placement,
			"\"auto\"" => "auto",
			value => return Err(io::Error::other(format!("multi-device must be false, true, or \"auto\", not {value}")).into()),
		}
	);
	// How a model placed on several devices divides: by layers, every layer over
	// every device (a tensor split), or a tensor split whenever every die reaches
	// the first peer to peer (auto).
	let split = setting(&manifest, "device-split")?.trim_matches('"');
	if !matches!(split, "layer" | "tensor" | "auto") {
		return Err(io::Error::other(format!("device-split must be \"layer\", \"tensor\", or \"auto\", not {split}")).into());
	}
	println!("cargo:rustc-env=RECIPE_DEVICE_SPLIT={split}");
	let out = PathBuf::from(env::var_os("OUT_DIR").ok_or_else(|| io::Error::other("OUT_DIR must be configured"))?);
	println!("cargo::rustc-check-cfg=cfg(amd)");
	println!("cargo::rustc-check-cfg=cfg(nvidia)");
	let os = env::var("CARGO_CFG_TARGET_OS")?;
	println!("cargo:rustc-env=RECIPE_NATIVE_CONFIGURATION={:016x}", native_configuration(&manifest, &os));
	let installed = |key: &str| -> BuildResult<bool> { Ok(configured(&manifest, key, &os)?.is_some_and(|path| Path::new(&path).exists())) };
	compile_cpu(&manifest, &out, &os, schedule)?;
	// GPU driver stubs and library search paths are host-arch: cross-compiled builds are CPU-only.
	let native = env::var("TARGET")? == env::var("HOST")?;
	let amd = native && installed("hsa-compiler")? && installed("hsa-device-library")?;
	let toolkit = nvidia_toolkit(&manifest, &os)?;
	if let Some(toolkit) = &toolkit
		&& toolkit.required
		&& !toolkit.device_library.exists()
	{
		return Err(io::Error::other(format!("nvidia-toolkit is installed but its device library {} is absent", toolkit.device_library.display())).into());
	}
	let nvidia = native && installed("nvidia-compiler")? && toolkit.as_ref().is_some_and(|toolkit| toolkit.device_library.exists());
	if amd {
		println!("cargo:rustc-cfg=amd");
		compile_amd(&manifest, &out, &os, schedule)?;
	}
	if nvidia {
		println!("cargo:rustc-cfg=nvidia");
		compile_nvidia(&manifest, &out, &os, schedule)?;
	}
	println!("cargo:rerun-if-changed=Cargo.toml");
	println!("cargo:rerun-if-changed=build.rs");
	println!("cargo:rerun-if-changed=amd-nv-cpu.ll");
	Ok(())
}
