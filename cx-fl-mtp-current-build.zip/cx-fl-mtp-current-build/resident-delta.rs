use recipe::*;
fn model() -> Model {
	recipe.model().e(1e-5).embed(9,32)
		.res([recipe.model().delta(1,3).fp(32).into()])
		.res([recipe.model().glu(32,Activation::Silu).into()]).norm(rms).layer(9)
}
fn weights(placed:&MtpPlaced)->usize { placed.memory().iter().map(|part|part.weights).sum() }
fn main() {
	let data=recipe.data("/home/nate/codex/cx-fl-mtp-current-build/fixtures-delta/target.gguf");
	let model=model();
	for head in ["accept","reject"] {
		let mut placed=recipe.infer().mtp(format!("/home/nate/codex/cx-fl-mtp-current-build/fixtures-delta/{head}.gguf")).place_mtp(&model,&data,64,&[]).unwrap();
		let original_weights=weights(&placed);
		let mut baseline=recipe.infer().mtp(format!("/home/nate/codex/cx-fl-mtp-current-build/fixtures-delta/{head}.gguf")).place_mtp(&model,&data,64,&[]).unwrap();
		for drafts in 0..=4 {
			placed.clear(); let mut sampler=recipe.sampler().temperature(0.0);
			let prompt=[0,1,0,1,0,1];
			let generation=placed.decode(&prompt,&mut sampler,&[8],16,drafts,false,|_|Ok(())).unwrap();
			assert_eq!(&generation.ids[prompt.len()..],&[0;16]);
			baseline.clear(); let mut plain=recipe.sampler().temperature(0.0);
			let reference=baseline.decode(&prompt,&mut plain,&[8],16,0,false,|_|Ok(())).unwrap();
			assert_eq!(generation.ids,reference.ids);
			let error=generation.logits.iter().zip(&reference.logits).map(|(a,b)|(a-b).abs()/b.abs().max(1.0)).fold(0.0,f64::max);
			assert!(error<0.001,"delta prefix logits error {error}");
			println!("delta reference normalized_max_error {error}");
			assert_eq!(generation.mtp.drafted,generation.mtp.accepted+generation.mtp.rejected);
			if head=="reject" { assert_eq!(generation.mtp.accepted,0); }
			assert_eq!(weights(&placed),original_weights);
			println!("case {head} drafts {drafts} accepted {} rejected {} steps {} tokens_per_step {:.3} weights {}",generation.mtp.accepted,generation.mtp.rejected,generation.mtp.verifications,generation.mtp.tokens_per_step(),original_weights);
		}
		placed.clear(); let mut sampler=recipe.sampler().temperature(0.0);
		let prompt=[2,0,0,1,2];
		let first=placed.decode(&prompt,&mut sampler,&[8],16,4,true,|_|Ok(())).unwrap();
		assert_eq!(&first.ids[prompt.len()..],&[0;16]);
		baseline.clear(); let mut plain=recipe.sampler().temperature(0.0);
		let plain_first=baseline.decode(&prompt,&mut plain,&[8],16,0,false,|_|Ok(())).unwrap();
		assert_eq!(first.ids,plain_first.ids);
		assert!(first.logits.iter().zip(&plain_first.logits).all(|(a,b)|(a-b).abs()<0.001));
		assert!(first.mtp.lookup_accepted>0);
 assert!(first.mtp.lookup_drafted>first.mtp.lookup_accepted);
		let mut continued=first.ids.clone(); continued.push(1);
		let second=placed.decode(&continued,&mut sampler,&[8],8,2,true,|_|Ok(())).unwrap();
		let plain_second=baseline.decode(&continued,&mut plain,&[8],8,0,false,|_|Ok(())).unwrap();
		assert_eq!(second.ids,plain_second.ids);
		assert!(second.logits.iter().zip(&plain_second.logits).all(|(a,b)|(a-b).abs()<0.001));
		assert!(second.cached>prompt.len());
 assert_eq!(&second.ids[continued.len()..],&[0;8]); assert_eq!(weights(&placed),original_weights);
		println!("case {head} lookup drafted {} accepted {} partial_rejected {} cached {} weights {}",first.mtp.lookup_drafted,first.mtp.lookup_accepted,first.mtp.lookup_drafted-first.mtp.lookup_accepted,second.cached,original_weights);
	}
}
