use std::{fs, path::Path};
enum Value { Text(String), Int(u32), Float(f32), Texts(Vec<String>), Ints(Vec<u32>) }
fn string(bytes: &mut Vec<u8>, text: &str) { bytes.extend((text.len() as u64).to_le_bytes()); bytes.extend(text.as_bytes()); }
fn value(bytes: &mut Vec<u8>, item: &Value) {
	match item {
		Value::Text(text) => { bytes.extend(8u32.to_le_bytes()); string(bytes, text); }
		Value::Int(n) => { bytes.extend(4u32.to_le_bytes()); bytes.extend(n.to_le_bytes()); }
		Value::Float(n) => { bytes.extend(6u32.to_le_bytes()); bytes.extend(n.to_le_bytes()); }
		Value::Texts(items) => { bytes.extend(9u32.to_le_bytes()); bytes.extend(8u32.to_le_bytes()); bytes.extend((items.len() as u64).to_le_bytes()); for text in items { string(bytes, text); } }
		Value::Ints(items) => { bytes.extend(9u32.to_le_bytes()); bytes.extend(4u32.to_le_bytes()); bytes.extend((items.len() as u64).to_le_bytes()); for n in items { bytes.extend(n.to_le_bytes()); } }
	}
}
struct Tensor { name: String, shape: Vec<u64>, values: Vec<f32> }
fn tensor(name: &str, shape: &[u64], values: Vec<f32>) -> Tensor { assert_eq!(shape.iter().product::<u64>() as usize, values.len()); Tensor { name: name.into(), shape: shape.into(), values } }
fn write(path: &Path, metadata: &[(String, Value)], tensors: &[Tensor]) {
	let mut bytes = b"GGUF".to_vec(); bytes.extend(3u32.to_le_bytes()); bytes.extend((tensors.len() as u64).to_le_bytes()); bytes.extend((metadata.len() as u64).to_le_bytes());
	for (key, item) in metadata { string(&mut bytes, key); value(&mut bytes, item); }
	let mut data = Vec::new();
	for item in tensors {
		string(&mut bytes, &item.name); bytes.extend((item.shape.len() as u32).to_le_bytes()); for dim in &item.shape { bytes.extend(dim.to_le_bytes()); } bytes.extend(0u32.to_le_bytes()); bytes.extend((data.len() as u64).to_le_bytes());
		for n in &item.values { data.extend(n.to_le_bytes()); } data.resize(data.len().next_multiple_of(32), 0);
	}
	bytes.resize(bytes.len().next_multiple_of(32), 0); bytes.extend(data); fs::write(path, bytes).unwrap();
}
fn metadata(blocks: u32) -> Vec<(String, Value)> {
	let mut items = vec![("general.architecture".into(), Value::Text("qwen35".into())), ("tokenizer.ggml.model".into(), Value::Text("gpt2".into())), ("tokenizer.ggml.pre".into(), Value::Text("gpt-2".into())), ("tokenizer.ggml.tokens".into(), Value::Texts(["a","b","c","d","e","f","g","h","<eos>"].map(String::from).into())), ("tokenizer.ggml.token_type".into(), Value::Ints(vec![1,1,1,1,1,1,1,1,3])), ("tokenizer.ggml.merges".into(), Value::Texts(vec![])), ("tokenizer.ggml.eos_token_id".into(), Value::Int(8))];
	for (key, n) in [("block_count",blocks),("embedding_length",32),("attention.head_count",1),("attention.head_count_kv",1),("feed_forward_length",32),("context_length",64)] { items.push((format!("qwen35.{key}"), Value::Int(n))); }
	items.push(("qwen35.attention.layer_norm_rms_epsilon".into(), Value::Float(1e-5))); items
}
fn main() {
	const W: usize = 32;
	let dir = Path::new("/home/nate/codex/cx-fl-mtp-current-build/fixtures-delta"); fs::create_dir_all(dir).unwrap();
	let mut embedding=vec![0.0;9*W]; let mut output=vec![0.0;9*W];
	for id in 0..9 { embedding[id*W]=1.0; output[id*W]=if id==0 {10.0} else if id==1 {-10.0} else {0.0}; }
	let mut target=vec![tensor("token_embd.weight", &[W as u64,9], embedding.clone()), tensor("output_norm.weight", &[W as u64], vec![1.0;W]), tensor("output.weight", &[W as u64,9], output.clone())];
	target.push(tensor("blk.0.attn_norm.weight", &[W as u64], vec![1.0;W]));
	target.push(tensor("blk.0.ffn_norm.weight", &[W as u64], vec![1.0;W]));
	for suffix in ["ffn_gate.weight","ffn_up.weight","ffn_down.weight"] { target.push(tensor(&format!("blk.0.{suffix}"), &[W as u64,W as u64], vec![0.0;W*W])); }
	let mut qkv=vec![0.0;3*W*W]; for c in 0..3*W { qkv[c*W+c%W]=0.2+(c%7) as f32*0.01; }
	let mut out=vec![0.0;W*W]; for c in 0..W {out[c*W+c]=0.03;}
	let mut taps=vec![0.0;3*W*3]; for c in 0..3*W {taps[c*3+2]=1.0;taps[c*3+1]=0.2;}
	for suffix in ["ssm_alpha.weight","ssm_beta.weight"] {target.push(tensor(&format!("blk.0.{suffix}"),&[W as u64,1],vec![0.01;W]));}
	target.push(tensor("blk.0.attn_qkv.weight",&[W as u64,3*W as u64],qkv));
	target.push(tensor("blk.0.ssm_conv1d.weight",&[3,3*W as u64],taps));
	target.push(tensor("blk.0.ssm_a",&[1],vec![-1.0]));
	target.push(tensor("blk.0.ssm_norm.weight",&[W as u64],vec![1.0;W]));
	target.push(tensor("blk.0.attn_gate.weight",&[W as u64,W as u64],vec![0.01;W*W]));
	target.push(tensor("blk.0.ssm_out.weight",&[W as u64,W as u64],out));
	
let mut meta=metadata(1);
	for (key,n) in [("full_attention_interval",2),("ssm.conv_kernel",3),("ssm.state_size",32),("ssm.group_count",1),("ssm.time_step_rank",1),("ssm.inner_size",32)] {meta.push((format!("qwen35.{key}"),Value::Int(n)));}
	write(&dir.join("target.gguf"), &meta, &target);

	for (name, sign) in [("accept",1.0),("reject",-1.0)] {
		let mut meta=metadata(2); meta.push(("qwen35.nextn_predict_layers".into(), Value::Int(1)));
		let mut projection=vec![0.0;2*W*W]; for c in 0..W { projection[c*2*W+W+c]=sign; }
		let mut tensors=vec![tensor("token_embd.weight", &[W as u64,9], embedding.clone()), tensor("output.weight", &[W as u64,9], output.clone()), tensor("output_norm.weight", &[W as u64], vec![1.0;W]), tensor("blk.1.nextn.enorm.weight", &[W as u64], vec![1.0;W]), tensor("blk.1.nextn.hnorm.weight", &[W as u64], vec![1.0;W]), tensor("blk.1.nextn.eh_proj.weight", &[2*W as u64,W as u64], projection), tensor("blk.1.nextn.shared_head_norm.weight", &[W as u64], vec![1.0;W]), tensor("blk.1.attn_norm.weight", &[W as u64], vec![1.0;W]), tensor("blk.1.ffn_norm.weight", &[W as u64], vec![1.0;W])];
		for suffix in ["attn_q.weight","attn_k.weight","attn_v.weight","attn_output.weight","ffn_gate.weight","ffn_up.weight","ffn_down.weight"] { tensors.push(tensor(&format!("blk.1.{suffix}"), &[W as u64,W as u64], vec![0.0;W*W])); }
		write(&dir.join(format!("{name}.gguf")), &meta, &tensors);
	}
	fs::write(dir.join("prompt.txt"), "ababab").unwrap();
}
