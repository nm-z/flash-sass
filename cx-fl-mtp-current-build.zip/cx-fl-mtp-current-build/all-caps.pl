use strict;use warnings;local$/;
for my$row (['plain','/home/nate/codex/cx-fl-mtp-edit/resident-run.rs'],['indexed','/home/nate/codex/cx-fl-mtp-edit/resident-indexed.rs'],['moe','/home/nate/codex/cx-fl-mtp-edit/resident-moe.rs'],['q8','/home/nate/codex/cx-fl-mtp-current-build/resident-q8.rs'],['delta','/home/nate/codex/cx-fl-mtp-current-build/resident-delta.rs']) {
	my($name,$p)=@$row;open my$f,'<',$p or die$!;my$s=<$f>;close$f;
	$s =~ s/(\t\tplaced.clear\(\); let mut sampler=recipe.sampler\(\).temperature\(0.0\);\n\t\tlet prompt=\[2,0,0,1,2\];)/\t\tfor cap in 0..=4 {\n$1/ or die "lookup loop $name";
	$s =~ s/,16,4,true,/,16,cap,true,/ or die "first $name";
	$s =~ s/,8,2,true,/,8,cap,true,/ or die "second $name";
	$s =~ s/assert!\(first.mtp.lookup_accepted>0\);/if cap>0 {assert!(first.mtp.lookup_accepted>0);}/;
	$s =~ s/assert!\(first.mtp.lookup_drafted>first.mtp.lookup_accepted\);/if cap>0 {assert!(first.mtp.lookup_drafted>first.mtp.lookup_accepted);}/;
	$s =~ s/(println!\("case \{head\} lookup [^\n]+\n)/\t\tprintln!("lookup\/cached cap {cap}");\n$1\t\t}\n/ or die "close $name";
	open$f,'>',"/home/nate/codex/cx-fl-mtp-current-build/all-caps-$name.rs";print $f $s;close$f;
}
