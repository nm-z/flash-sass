use strict;use warnings;open my$f,'<','/home/nate/codex/cx-fl-mtp-edit/fixture.rs';local$/;my$s=<$f>;close$f;
$s =~ s{cx-fl-mtp-build/fixtures}{cx-fl-mtp-current-build/fixtures-q8}g;
$s =~ s/(let mut items = vec!\[)/$1("tokenizer.chat_template".into(), Value::Text("ababab".into())),/;
$s =~ s/bytes.extend\(0u32.to_le_bytes\(\)\); bytes.extend\(\(data.len\(\) as u64\)/bytes.extend((if item.name=="output.weight" {8u32} else {0u32}).to_le_bytes()); bytes.extend((data.len() as u64)/;
$s =~ s/for n in \&item.values \{ data.extend\(n.to_le_bytes\(\)\); \}/if item.name=="output.weight" {for block in item.values.chunks_exact(32) {data.extend(0x3c00u16.to_le_bytes()); for n in block {data.push(*n as i8 as u8);}}} else {for n in \&item.values { data.extend(n.to_le_bytes()); }}/;
open$f,'>','/home/nate/codex/cx-fl-mtp-current-build/fixture-q8.rs';print $f $s;close$f;
open$f,'<','/home/nate/codex/cx-fl-mtp-current-build/observed-refresh.rs';$s=<$f>;close$f;
$s =~ s{cx-fl-mtp-build/fixtures}{cx-fl-mtp-current-build/fixtures-q8}g;
open$f,'>','/home/nate/codex/cx-fl-mtp-current-build/observed-refresh.rs';print $f $s;close$f;
