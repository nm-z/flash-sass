use strict; use warnings;
my $p='/home/nate/work/cx-fl-mtp-current/recipe.rs'; open my $f,'<',$p;local$/;my$s=<$f>;close$f;
$s =~ s/\n Operation-local values do/ Operation-local values do/ or die "comment";
$s =~ s/\t+let copy = CudaCopy2d[^\n]+\n\t+self.status\(\(driver.copy_2d\)\(&copy\), "device copy"\)/\t\t\t\t\tself.status((driver.copy_device)(destination, source, bytes), "device copy")/ or die "copy";
$s =~ s/(struct Cuda \{\n)/$1\tcopy_device: unsafe extern "C" fn(u64, u64, usize) -> i32,\n/ or die "field";
$s =~ s/(\t+download: runtime.function\(b"cuMemcpyDtoH_v2\\0"\)\?,)/$1\n\t\t\t\tcopy_device: runtime.function(b"cuMemcpyDtoD_v2\\0")?,/ or die "loader";
$s =~ s/%forward.training = icmp ne i32 %training, 0/%forward.training = icmp eq i32 %training, 1/g;
open$f,'>',$p;print$f$s;close$f;
