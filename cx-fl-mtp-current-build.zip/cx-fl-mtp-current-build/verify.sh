#!/bin/bash
set -u
cd /home/nate/work/cx-fl-mtp-current
records=/home/nate/codex/cx-fl-mtp-current-build
CARGO_BUILD_JOBS=6 cargo build --release --lib --bin recipe > "$records/build-final.log" 2>&1
rc=$?
printf '%s\n' "$rc" > "$records/build-final.exit"
test "$rc" = 0 || exit "$rc"
for row in 'plain resident-run 64 llamacpp' 'indexed resident-indexed 66 recipe' 'moe resident-moe 64 recipe'; do
	read -r name source context profile <<< "$row"
	target/release/recipe run "/home/nate/codex/cx-fl-mtp-edit/$source.rs" --device cpu --ctx "$context" --cfg "$profile" > "$records/cpu-$name.log" 2>&1
	rc=$?
	printf '%s\n' "$rc" > "$records/cpu-$name.exit"
	test "$rc" = 0 || exit "$rc"
done
