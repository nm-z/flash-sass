use strict;use warnings;my$p='/home/nate/work/cx-fl-mtp-current/recipe.rs';open my$f,'<',$p or die$!;local$/;my$s=<$f>;close$f;
my$old='if let Some(execution) = expert_guard.as_mut() { execution.start(self.expert_first, self.expert_count, begin, end, capacity)?; }';
my$new=<<'CODE';
let expert_count = if mode == ForwardMode::StateOnly as i32 && expert_guard.as_ref().is_some_and(|execution|
			execution.layers.get(self.expert_first + self.expert_count.saturating_sub(1)).is_some_and(|layer| layer.node + 1 == self.nodes.len()))
		{ self.expert_count.saturating_sub(1) } else { self.expert_count };
		if let Some(execution) = expert_guard.as_mut() { execution.start(self.expert_first, expert_count, begin, end, capacity)?; }
CODE
my$i=index($s,$old);die 'start' if$i<0;substr($s,$i,length$old,$new);
$s =~ s/execution.finish\(self.expert_first,self.expert_count,begin,end,capacity\)/execution.finish(self.expert_first,expert_count,begin,end,capacity)/ or die 'finish';
open$f,'>',$p;print $f $s;close$f;
