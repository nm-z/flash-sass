use recipe::*;
fn model() -> Model {
	recipe.model().e(1e-5).embed(9,32)
		.res([recipe.model().attn(1).kv(1).head(32).rope(neox,32,10000.0).into()])
		.res([recipe.model().gguf_moe(4,2,32,Activation::Silu,Scoring::Softmax,true,false).fp(32).into()]).norm(rms).layer(9)
}
fn weights(placed:&MtpPlaced)->usize { placed.memory().iter().map(|part|part.weights).sum() }
fn main() {
	let data=recipe.data("/home/nate/codex/cx-fl-mtp-build/fixtures-moe/target.gguf");
	let model=model();
	for head in ["accept","reject"] {
		let mut placed=recipe.infer().mtp(format!("/home/nate/codex/cx-fl-mtp-build/fixtures-moe/{head}.gguf")).place_mtp(&model,&data,64,&[]).unwrap();
		let original_weights=weights(&placed);
		for drafts in 0..=4 {
			placed.clear(); let mut sampler=recipe.sampler().temperature(0.0);
			let prompt=[0,1,0,1,0,1];
			let generation=placed.decode(&prompt,&mut sampler,&[8],16,drafts,false,|_|Ok(())).unwrap();
			assert_eq!(&generation.ids[prompt.len()..],&[0;16]);
			assert_eq!(generation.mtp.drafted,generation.mtp.accepted+generation.mtp.rejected);
			if head=="reject" { assert_eq!(generation.mtp.accepted,0); }
			assert_eq!(weights(&placed),original_weights);
			println!("case {head} drafts {drafts} accepted {} rejected {} steps {} tokens_per_step {:.3} weights {}",generation.mtp.accepted,generation.mtp.rejected,generation.mtp.verifications,generation.mtp.tokens_per_step(),original_weights);
		}
		for cap in 0..=4 {
		placed.clear(); let mut sampler=recipe.sampler().temperature(0.0);
		let prompt=[2,0,0,1,2];
		let first=placed.decode(&prompt,&mut sampler,&[8],16,cap,true,|_|Ok(())).unwrap();
		assert_eq!(&first.ids[prompt.len()..],&[0;16]);
		if cap>0 {assert!(first.mtp.lookup_accepted>0);} if cap>0 {assert!(first.mtp.lookup_drafted>first.mtp.lookup_accepted);}
		let mut continued=first.ids.clone(); continued.push(1);
		let second=placed.decode(&continued,&mut sampler,&[8],8,cap,true,|_|Ok(())).unwrap();
		assert!(second.cached>prompt.len()); assert_eq!(&second.ids[continued.len()..],&[0;8]); assert_eq!(weights(&placed),original_weights);
				println!("lookup/cached cap {cap}");
println!("case {head} lookup drafted {} accepted {} partial_rejected {} cached {} weights {}",first.mtp.lookup_drafted,first.mtp.lookup_accepted,first.mtp.lookup_drafted-first.mtp.lookup_accepted,second.cached,original_weights);
		}
	}
}
