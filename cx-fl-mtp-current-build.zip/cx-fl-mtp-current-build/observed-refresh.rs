use recipe::*;
fn model() -> Model {
	recipe.model().e(1e-5).embed(9,32)
		.res([recipe.model().attn(1).kv(1).head(32).rope(neox,32,10000.0).into()])
		.res([recipe.model().glu(32,Activation::Silu).into()]).norm(rms).layer(9)
}
fn main() {
	let data=recipe.data("/home/nate/codex/cx-fl-mtp-current-build/fixtures-q8/target.gguf");
	let report=recipe.infer().mtp("/home/nate/codex/cx-fl-mtp-current-build/fixtures-q8/accept.gguf").tokens(16).run(&model(),&data);
	let operations=report.operations.iter().filter(|row|row.model=="mtp").collect::<Vec<_>>();
	let projection=operations.iter().map(|row|row.node).max().unwrap();
	let refresh=operations.iter().filter(|row|row.end-row.begin>1).collect::<Vec<_>>();
	assert!(!refresh.is_empty(),"no state-refresh operations observed");
	assert!(refresh.iter().all(|row|row.node!=projection),"refresh executed the vocabulary projection");
	assert!(operations.iter().any(|row|row.node==projection),"draft did not execute its vocabulary projection");
	assert!(operations.iter().filter(|row|row.node==projection).all(|row|row.end-row.begin==1));
	println!("state-only observed refresh_rows {} draft_projection_rows {} projection_node {}",refresh.len(),operations.iter().filter(|row|row.node==projection).count(),projection);
	for row in operations {println!("{} {}..{} {} positions {}",row.node,row.begin,row.end,row.operation,row.positions);}
}
