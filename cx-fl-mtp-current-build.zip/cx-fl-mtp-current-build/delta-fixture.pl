use strict;use warnings;
my$p='/home/nate/codex/cx-fl-mtp-edit/fixture.rs';open my$f,'<',$p;local$/;my$s=<$f>;close$f;
$s =~ s{cx-fl-mtp-build/fixtures}{cx-fl-mtp-current-build/fixtures-delta}g;
my$a=index($s,'for suffix in ["attn_q.weight"');my$b=index($s,'write(&dir.join("target.gguf")',$a);die 'target' if$a<0||$b<0;
substr($s,$a,$b-$a,<<'CODE');
for suffix in ["ffn_gate.weight","ffn_up.weight","ffn_down.weight"] { target.push(tensor(&format!("blk.0.{suffix}"), &[W as u64,W as u64], vec![0.0;W*W])); }
	let mut qkv=vec![0.0;3*W*W]; for c in 0..3*W { qkv[c*W+c%W]=0.2+(c%7) as f32*0.01; }
	let mut out=vec![0.0;W*W]; for c in 0..W {out[c*W+c]=0.03;}
	let mut taps=vec![0.0;3*W*3]; for c in 0..3*W {taps[c*3+2]=1.0;taps[c*3+1]=0.2;}
	for suffix in ["ssm_alpha.weight","ssm_beta.weight"] {target.push(tensor(&format!("blk.0.{suffix}"),&[W as u64,1],vec![0.01;W]));}
	target.push(tensor("blk.0.attn_qkv.weight",&[W as u64,3*W as u64],qkv));
	target.push(tensor("blk.0.ssm_conv1d.weight",&[3,3*W as u64],taps));
	target.push(tensor("blk.0.ssm_a",&[1],vec![-1.0]));
	target.push(tensor("blk.0.ssm_norm.weight",&[W as u64],vec![1.0;W]));
	target.push(tensor("blk.0.attn_gate.weight",&[W as u64,W as u64],vec![0.01;W*W]));
	target.push(tensor("blk.0.ssm_out.weight",&[W as u64,W as u64],out));
	
CODE
my$needle='write(&dir.join("target.gguf"), &metadata(1), &target);';
my$new=<<'CODE';
let mut meta=metadata(1);
	for (key,n) in [("full_attention_interval",2),("ssm.conv_kernel",3),("ssm.state_size",32),("ssm.group_count",1),("ssm.time_step_rank",1),("ssm.inner_size",32)] {meta.push((format!("qwen35.{key}"),Value::Int(n)));}
	write(&dir.join("target.gguf"), &meta, &target);
CODE
$a=index($s,$needle);die 'metadata' if$a<0;substr($s,$a,length($needle),$new);
open$f,'>','/home/nate/codex/cx-fl-mtp-current-build/fixture-delta.rs';print $f $s;close$f;
# Extend the public resident check with logits agreement to a zero-draft placement.
open$f,'<','/home/nate/codex/cx-fl-mtp-edit/resident-run.rs';$s=<$f>;close$f;
$s =~ s/recipe.model\(\).attn\(1\).kv\(1\).head\(32\).rope\(neox,32,10000.0\)/recipe.model().delta(1,3).fp(32)/;
$s =~ s{cx-fl-mtp-build/fixtures}{cx-fl-mtp-current-build/fixtures-delta}g;
$s =~ s/(let original_weights=weights\(&placed\);)/$1\n\t\tlet mut baseline=recipe.infer().mtp(format!("\/home\/nate\/codex\/cx-fl-mtp-current-build\/fixtures-delta\/{head}.gguf")).place_mtp(\&model,\&data,64,\&[]).unwrap();/;
$s =~ s/(assert_eq!\(\&generation.ids\[prompt.len\(\)..\],\&\[0;16\]\);)/$1\n\t\t\tbaseline.clear(); let mut plain=recipe.sampler().temperature(0.0);\n\t\t\tlet reference=baseline.decode(\&prompt,\&mut plain,\&[8],16,0,false,|_|Ok(())).unwrap();\n\t\t\tassert_eq!(generation.ids,reference.ids);\n\t\t\tlet error=generation.logits.iter().zip(\&reference.logits).map(|(a,b)|(a-b).abs()\/b.abs().max(1.0)).fold(0.0,f64::max);\n\t\t\tassert!(error<0.001,"delta prefix logits error {error}");\n\t\t\tprintln!("delta reference normalized_max_error {error}");/;
open$f,'>','/home/nate/codex/cx-fl-mtp-current-build/resident-delta.rs';print $f $s;close$f;
