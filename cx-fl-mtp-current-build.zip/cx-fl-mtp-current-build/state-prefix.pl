use strict; use warnings;
my $path='/home/nate/work/cx-fl-mtp-current/recipe.rs';
open my $f,'<',$path or die $!; local $/; my $s=<$f>; close $f;
sub change { my($from,$to)=@_; my $at=index($s,$from); die "missing: $from" if $at<0; substr($s,$at,length($from),$to); }
# Pass state-only through internal bodies. The public kernel ABI stays unchanged.
change('enum ForwardMode {'. "\n\tInference,\n\tTraining,", 'enum ForwardMode {'. "\n\tInference,\n\tTraining,\n\tStateOnly,");
change('self.placed.run_window(&self.samples, begin as u32, end as u32)?;', 'self.placed.run_state_window(&self.samples, begin as u32, end as u32)?;');
change('let single = matches!(mode, ForwardMode::Inference) && end - begin == 1;', 'let single = matches!(mode, ForwardMode::Inference | ForwardMode::StateOnly) && end - begin == 1;');
change('let mut body = String::new();'. "\n\t\tlet forward_args", 'let mut body = String::new();'. "\n\t\tlet forward_args");
# The existing primitive caller can skip the terminal projection uniformly.
change("\t\t\t// Keep position propagation in the caller.", <<'CODE');
			let state_projection = !reverse && !training && index + 1 == self.plans.len()
				&& plan.node.op == Primitive::Contraction && self.graph.nodes.iter().any(|node| node.retain_output);
			if state_projection { ir.push_str("br i1 %state.only, label %state.projection.done, label %state.projection.run\nstate.projection.run:\n"); }
			// Keep position propagation in the caller.
CODE
change("\t\t}\n\t\tOk(ir)\n\t}\n\n\tfn emit_expert_selection", "\t\t\tif state_projection { ir.push_str(\"br label %state.projection.done\\nstate.projection.done:\\n\"); }\n\t\t}\n\t\tOk(ir)\n\t}\n\n\tfn emit_expert_selection");
# Update only generated inference bodies/calls, including metrics calls.
$s =~ s/\@recipe_model_inference_chunk\(\{forward_args\}\)/\@recipe_model_inference_chunk({forward_args}, i1 %state.only)/g;
$s =~ s/\@recipe_model_inference_chunk\(\{chunk_args\}\)/\@recipe_model_inference_chunk({chunk_args}, i1 %state.only)/g;
$s =~ s/define internal void \@recipe_model_inference_forward_body\(\{forward_args\}\)/define internal void \@recipe_model_inference_forward_body({forward_args}, i1 %state.only)/g;
$s =~ s/call void \@recipe_model_inference_forward_body\(\{step_args\}\)/call void \@recipe_model_inference_forward_body({step_args}, i1 %state.only)/g;
$s =~ s/call void \@recipe_model_inference_forward_body\(\{forward_args\}\)/call void \@recipe_model_inference_forward_body({forward_args}, i1 %state.only)/g;
# Define the predicate in each entrypoint before its inference call.
$s =~ s/(define \{kernel\} void \@recipe_model_(?:step|forward)\(\{forward_entry_args\}\) #[04] \{\{\\nentry:\\n)/$1%state.only = icmp eq i32 %training, 2\\n/g;
change('i32 0, i32 {positions})\\nbr label %metrics.entry\\nmetrics.entry:', 'i32 0, i32 {positions}, i1 false)\\nbr label %metrics.entry\\nmetrics.entry:');
# Export retained hidden rows, but no stale vocabulary rows.
change("\t\t\tlet prefix = format!(\"request.{name}.export\");", "\t\t\tif name == \"output\" { ir.push_str(\"br i1 %state.only, label %request.output.skipped, label %request.output.run\\nrequest.output.run:\\n\"); }\n\t\t\tlet prefix = format!(\"request.{name}.export\");");
my $req=index($s,"\tfn emit_request_end"); my $reqend=index($s,"\n\tfn ",$req+10); my $part=substr($s,$req,$reqend-$req); $part =~ s/\t\t}\n\t\tir.push_str\(barrier\(backend\)\);/\t\t\tif name == "output" { ir.push_str("br label %request.output.skipped\\nrequest.output.skipped:\\n"); }\n\t\t}\n\t\tir.push_str(barrier(backend));/ or die "request end"; substr($s,$req,$reqend-$req,$part);
# Shared window preparation/dispatch, with no output download for refresh.
change("\tfn forward_window_with_tokens(&self, tapes: &[NativeTape], samples: &[f64], tokens: &[f64], token_begin: usize, begin: u32, end: u32, progress: Option<&InferenceLive>) -> Result<Vec<f64>> {", <<'CODE');
	fn run_state_window(&self, samples: &[f64], begin: u32, end: u32) -> Result<()> {
		let PlacedSource::Bound(input, _) = &self.source else { return Err(RecipeError::new("MTP state refresh requires a bound head")); };
		let ranges = self.tapes.first().ok_or_else(|| RecipeError::new("MTP head has no ranges"))?;
		require(ranges.len() == 1 && ranges[0].nodes.last().is_some_and(|node| node.op == Primitive::Contraction)
			&& ranges[0].nodes.iter().any(|node| node.retain_output), "MTP state refresh requires a retained hidden stream and vocabulary projection")?;
		require(begin <= end && end as usize <= input.length && samples.len() == input.channels * (end - begin) as usize, "MTP state refresh input window is invalid")?;
		self.forward_window_mode(ranges, samples, samples, 0, begin, end, None, ForwardMode::StateOnly)?;
		Ok(())
	}
	fn forward_window_with_tokens(&self, tapes: &[NativeTape], samples: &[f64], tokens: &[f64], token_begin: usize, begin: u32, end: u32, progress: Option<&InferenceLive>) -> Result<Vec<f64>> {
		self.forward_window_mode(tapes, samples, tokens, token_begin, begin, end, progress, ForwardMode::Inference)
	}
	fn forward_window_mode(&self, tapes: &[NativeTape], samples: &[f64], tokens: &[f64], token_begin: usize, begin: u32, end: u32, progress: Option<&InferenceLive>, mode: ForwardMode) -> Result<Vec<f64>> {
CODE
change('tape.forward_window_observed(tape.samples.pointer, begin, end, ForwardMode::Inference,', 'tape.forward_window_observed(tape.samples.pointer, begin, end, mode,');
change("\t\tlast.predictions()\n", "\t\tif matches!(mode, ForwardMode::StateOnly) { Ok(Vec::new()) } else { last.predictions() }\n");
# Typed device copy support from the prior checkpoint.
open $f,'<','/home/nate/codex/cx-fl-mtp-edit/device-commit.rs' or die $!; my $copy=<$f>; close $f;
change('impl Buffer {', $copy.'impl Buffer {');
change('const REMOTE_CLEAR: u8 = 9;', "const REMOTE_CLEAR: u8 = 9;\nconst REMOTE_DEVICE_COPY: u8 = 10;");
change("\t\t\tREMOTE_SYNCHRONIZE =>", <<'CODE');
			REMOTE_DEVICE_COPY => {
				let destination = wire.read_u64()?;
				let source = wire.read_u64()?;
				let bytes = wire.read_u64()? as usize;
				wire.status(&gpu.copy_device(destination, source, bytes))?;
			}
			REMOTE_SYNCHRONIZE =>
CODE
# Reuse selective indexer patches; bind delta copies to this root's circular slots.
open $f,'<','/home/nate/codex/cx-fl-mtp-edit/selective-prefix.rs' or die $!; my $commit=<$f>; close $f;
my $a=index($commit,"\t\t\tlet begin = tape.window_begin"); my $b=index($commit,"\n\t\t}\n", $a); die "delta replacement" if $a<0||$b<0;
substr($commit,$a,$b-$a,<<'CODE');
			for (index, node) in tape.nodes.iter().enumerate().filter(|(_, node)| node.op == Primitive::Delta) {
				let slots = integer_argument(node.argument[5], "delta checkpoint slots")? as usize;
				require(slots != 0, "MTP delta prefix has no checkpoint slots")?;
				let reached = tape.reached.load(Ordering::Acquire);
				require(end == 0 || (reached - end) < slots as u32, "MTP delta prefix checkpoint was overwritten")?;
				let (_, keys, heads, width) = delta_extent(node)?;
				let cells = checked_mul(keys as usize, width as usize, "MTP delta state cells")?;
				let bytes = checked_mul(cells, NativePrecision::new(node.precision, node.acc)?.state.bytes(), "MTP delta state bytes")?;
				let pairs = checked_mul(tape.rows as usize, heads as usize, "MTP delta state pairs")?;
				let live = checked_mul(pairs, bytes, "MTP delta live bytes")?;
				let base = tape.program.artifact.layout.contexts[index];
				let buffer = if tape.program.artifact.layout.contexts_in_values[index] { &tape.values } else { &tape.contexts };
				let extent = checked_mul(live, checked_add(slots, 1, "MTP delta slots")?, "MTP delta checkpoint extent")?;
				require(checked_add(base, extent, "MTP delta checkpoint end")? <= buffer.bytes, "MTP delta checkpoint exceeds its buffer")?;
				if end == 0 { clears.push((buffer, base, live)); continue; }
				let slot = (end as usize - 1) % slots;
				for pair in 0..pairs {
					let cell = checked_add(checked_mul(pair, slots, "MTP delta checkpoint pair")?, slot, "MTP delta checkpoint slot")?;
					let source = checked_add(checked_add(base, live, "MTP delta checkpoint region")?, checked_mul(cell, bytes, "MTP delta checkpoint offset")?, "MTP delta checkpoint address")?;
					let target = checked_add(base, checked_mul(pair, bytes, "MTP delta live offset")?, "MTP delta live address")?;
					copies.push((buffer, source, target, bytes));
				}
			}
CODE
$a=index($s,"\tfn commit_mtp_prefix("); $b=index($s,"\n\tfn take_operations",$a); die "commit" if $a<0||$b<0;
substr($s,$a,$b-$a,$commit);
# Remove the superseded full-image indexer rollback.
$a=index($s,"\tfn commit_index_prefix("); $b=index($s,"\n\t/// Applies a runtime contraction schedule",$a); die "old indexer" if $a<0||$b<0;
substr($s,$a,$b-$a,'');
open $f,'>',$path or die $!; print $f $s; close $f;
