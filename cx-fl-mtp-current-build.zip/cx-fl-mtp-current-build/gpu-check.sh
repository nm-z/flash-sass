#!/bin/bash
set -u
records=/home/nate/codex/cx-fl-mtp-current-build
cd /home/nate/work/cx-fl-mtp-current
test "$(cat "$records/build-final.exit")" = 0 || exit 1
export CUDA_VISIBLE_DEVICES=GPU-ccb8b3a3-f45d-8962-215b-c2b140e4bb28
for row in 'plain resident-run 64 llamacpp' 'indexed resident-indexed 66 recipe'; do
	read -r name source context profile <<< "$row"
	target/release/recipe run "/home/nate/codex/cx-fl-mtp-edit/$source.rs" --device nv0 --ctx "$context" --cfg "$profile" > "$records/gpu-$name.log" 2>&1
	rc=$?
	printf '%s\n' "$rc" > "$records/gpu-$name.exit"
	test "$rc" = 0 || exit "$rc"
done
