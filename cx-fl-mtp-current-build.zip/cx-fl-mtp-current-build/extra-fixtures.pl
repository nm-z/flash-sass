use strict;use warnings;local$/;open my$f,'<','/home/nate/codex/cx-fl-mtp-edit/resident-run.rs';my$s=<$f>;close$f;$s =~ s{cx-fl-mtp-build/fixtures}{cx-fl-mtp-current-build/fixtures-q8}g;open$f,'>','/home/nate/codex/cx-fl-mtp-current-build/resident-q8.rs';print $f $s;close$f;
open$f,'<','/home/nate/codex/cx-fl-mtp-current-build/resident-delta.rs';$s=<$f>;close$f;
my$n='assert!(first.mtp.lookup_accepted>0);';
my$r=<<'RUST';
baseline.clear(); let mut plain=recipe.sampler().temperature(0.0);
		let plain_first=baseline.decode(&prompt,&mut plain,&[8],16,0,false,|_|Ok(())).unwrap();
		assert_eq!(first.ids,plain_first.ids);
		assert!(first.logits.iter().zip(&plain_first.logits).all(|(a,b)|(a-b).abs()<0.001));
		assert!(first.mtp.lookup_accepted>0);
RUST
my$i=index($s,$n);die 'lookup' if$i<0;substr($s,$i,length$n,$r);
$n='assert!(second.cached>prompt.len());';
$r=<<'RUST';
let plain_second=baseline.decode(&continued,&mut plain,&[8],8,0,false,|_|Ok(())).unwrap();
		assert_eq!(second.ids,plain_second.ids);
		assert!(second.logits.iter().zip(&plain_second.logits).all(|(a,b)|(a-b).abs()<0.001));
		assert!(second.cached>prompt.len());
RUST
$i=index($s,$n);die 'cached' if$i<0;substr($s,$i,length$n,$r);
open$f,'>','/home/nate/codex/cx-fl-mtp-current-build/resident-delta.rs';print $f $s;close$f;
