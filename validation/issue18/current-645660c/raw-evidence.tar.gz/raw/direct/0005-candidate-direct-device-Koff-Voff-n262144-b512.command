/tmp/pr45-attention.qsog2y/candidate/kern/qsa_direct_test 262144 512 1 
