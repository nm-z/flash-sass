/tmp/pr45-attention.qsog2y/candidate/kern/qsa_direct_test 65000 512 4 
