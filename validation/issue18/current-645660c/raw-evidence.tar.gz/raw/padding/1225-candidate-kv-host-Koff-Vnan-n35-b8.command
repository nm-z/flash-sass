/tmp/pr45-attention.qsog2y/candidate/kern/qsa_test kv 35 8 
