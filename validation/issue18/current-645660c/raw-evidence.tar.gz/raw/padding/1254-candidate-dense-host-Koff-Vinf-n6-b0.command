/tmp/pr45-attention.qsog2y/candidate/kern/attn_test 6 0 
