/tmp/pr45-attention.qsog2y/candidate/kern/attn_test 255 0 
