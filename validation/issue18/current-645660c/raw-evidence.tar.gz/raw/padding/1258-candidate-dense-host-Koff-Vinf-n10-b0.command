/tmp/pr45-attention.qsog2y/candidate/kern/attn_test 10 0 
