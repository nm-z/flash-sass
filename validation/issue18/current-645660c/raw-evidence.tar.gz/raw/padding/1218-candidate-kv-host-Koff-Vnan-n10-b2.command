/tmp/pr45-attention.qsog2y/candidate/kern/qsa_test kv 10 2 
