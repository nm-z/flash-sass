reusecheck 96 64 16
