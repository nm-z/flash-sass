#!/usr/bin/env bash
set -euo pipefail
base=$1
gpu=$2
lock=$3
runner=$4
trap 'rc=$?; printf "%s\n" "$rc" > "$base/evidence/remaining.exit"' EXIT
for suite in direct controls timing; do
    bash "$runner" --run --suite "$suite" \
        --repo "$base/candidate" --parent "$base/control" \
        --out "$base/evidence/$suite" --gpu "$gpu" --lock "$lock" \
        > "$base/evidence/$suite-progress.log" 2>&1
    printf '%s PASS\n' "$suite"
done
