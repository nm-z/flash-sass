/tmp/pr45-attention.qsog2y/candidate/kern/qsa_direct_test 3100 512 4 
